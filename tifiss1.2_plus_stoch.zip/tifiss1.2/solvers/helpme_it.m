%HELPME_IT    iterative solvers interactive help
%   TIFISS scriptfile: DJS; 11 January 2016.
%Copyright (c) 2016 by D.J. Silvester, Qifeng Liao

fprintf(' \n');
fprintf('  To use a preconditioned Krylov subspace iterative method\n');
fprintf('  to solve the current discrete system, run the script file: \n');
fprintf('  it_solve\n');
fprintf(' \n');