4     % reference problem
2     % P1/P2
2e-4  % stopping tolerance
2     % marking strategy
0.5   % threshold parameter
1     % structured mesh
3     % grid parameter
1     % uniform grid

%% Data file for  L-domain isotropic diffusion adaptive run
