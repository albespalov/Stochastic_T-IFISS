1     % reference problem
5     % grid parameter
0     % refinement level
2     % P1/P2

%% Data file for square isotropic diffusion problem