1     % reference problem
2     % P1/P2
3e-4  % stopping tolerance
2     % marking strategy
0.5   % threshold parameter
3     % grid parameter

%% Data file for square isotropic diffusion adaptive run
