4     % reference problem
2     % circle obstruction 
0.02  % mesh size
0     % refinement level
2     % P1/P2 switch

%% Data file for punched ticket diffusion problem