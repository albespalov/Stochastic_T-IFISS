4     % reference problem
1     % P1/P2
1e-2  % stopping tolerance
1     % linear bubble functions
1     % estimator type (hierarchical)
2     % marking strategy
0.5   % threshold parameter
1     % structured mesh
3     % grid parameter
1     % grid stretch factor

%% Data file for L-domain isotropic diffusion adaptive run
