2     % MINRES
1e-6  % stopping tolerance
30    % maximum number of iterations
3     % AMG preconditioner
1     % plot grid sequence
1     % damped Jacobi smoother
19     % figure number
1     % color 

%% Data file for iterative solution of diffusion problem
