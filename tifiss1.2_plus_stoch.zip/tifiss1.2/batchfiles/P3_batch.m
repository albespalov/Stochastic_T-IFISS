3     % reference problem
0.1  % mesh size
1     % refinement level
2     % P1/P2 switch

%% Data file for circle diffusion problem