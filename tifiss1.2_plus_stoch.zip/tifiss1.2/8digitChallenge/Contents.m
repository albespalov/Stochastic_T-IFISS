% 8DIGITCHALLENGE
%
% Files
%   bc_ex8                  - nonzero boundary condition for 8-digit challenge problem
%   compute8digits          - adaptively solve 8-digit challenge problem
%   find_elem_given_point   - identifies an element that contains given point
%   Run8DigitChallenge_pc   - RUN8DIGITCHALLENGE  posed by L. N. Trefethen on NA-digest (Windows version)
%   Run8DigitChallenge_unix - RUN8DIGITCHALLENGE  posed by L. N. Trefethen on NA-digest (Unix version)
