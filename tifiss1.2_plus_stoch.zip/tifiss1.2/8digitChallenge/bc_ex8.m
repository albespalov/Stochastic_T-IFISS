function bc = specific_bc(xbd,ybd)
%BC_EX8   nonzero boundary condition for 8-digit challenge problem
%   bc = specific_bc(xbd,ybd);
%   input
%          xbd          x boundary coordinate vector
%          ybd          y boundary coordinate vector 
%   T-IFISS function: AB; 15 August 2019.
% Copyright (c) 2017 Alex Bespalov, Leonardo Rocchi

  bc = (1-xbd).^2;

end % end function
