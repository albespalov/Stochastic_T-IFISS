% TEST_PROBLEMS
%
% Files
%   adapt_diff_testproblem - sets up adaptive mesh test examples (Unix version)
%   adiff_ex6              - Variable diffusion operator 
%   adiff_ex7              - variable diffusion operator 
%   analytic_adiff         - analytic_adiff   analytic unit circle diffusion operator 
%   analytic_bc            - analytic_bc   Reference problem  boundary condition 
%   analytic_rhs           - analytic_rhs   analytic RHS forcing function
%   anisotropic_adiff      - anisotropic_adiff   anisotropic diffusion operator
%   bc_ex7                 - nonzero boundary condition for singular solution
%   circle_bc              - circle_bc   zero boundary condition on unit circle
%   diff_refproblem        - diff_refproblem_unix    sets up reference examples  (Unix version)
%   diff_testproblem       - diff_testproblem   sets up test examples  (Unix version)
%   gradcoeff_ex6          - Computes the gradient of the coefficients a(x,y)
%   gradcoeff_ex7          - computes the gradient of the coefficients a(x,y)
%   ref_adiff              - ref_adiff   reference variable diffusion operator 
%   rhs_ex6                - RHS forcing function
%   rhs_ex7                - RHS forcing function
%   unit_adiff             - unit_adiff   standard diffusion operator 
%   unit_rhs               - unit_rhs   unit RHS forcing function
%   zero_bc                - zero_bc   zero boundary condition 
%   zero_rhs               - zero_rhs   zero RHS forcing function
%   zeros_gradcoeff        - returns the zero gradient for constant coefficients
