function stoch_trunc_gauss_coeffx(N,L,sigma)
%STOCH_TRUNC_GAUSS_COEFFX generates coefficients in recurrence relation for truncated gaussian pdf
%
% stoch_trunc_gauss_coeffx(N,L,sigma)
%
% input:
%            N   maximum polynomial degree
%            L   integration interval parameter (I = (-L,L))
%        sigma   standard deviation
%
% output:
%         beta   approximations to coefficients in the recurrence relation
%                for orthogonal polynomials
%                (written and saved to the file "beta_truncated_gaussian.dat")
%
% NOTE: this version computes inner products via numerical integration;
%       for large N, the computation time for evaluating the integrals increases
%       in geometric progression.
%
% See also STOCH_TRUNC_GAUSS_COEFF
%
%   TIFISS function: AB; 19 January 2018
% Copyright (c) 2018 A. Bespalov, F. Xu

% Generate and save recurrence coefficients beta_n to a file
fun_p=@(x) exp(-x.^2./sigma./sigma./2)/sigma/sqrt(2*pi)/erf(L/sqrt(2)/sigma); % pdf
% initialise
beta=zeros(N,1);
beta(1)=1; % beta_0
fun_poly_1=@(x) 0; % P_{-1}
fun_poly_2=@(x) 1; % P_0
fun_ip=@(x) fun_p(x).*fun_poly_2(x).*fun_poly_2(x); % integrand
int=integral(fun_ip,-L,L);
% iteration
for k=2:N
    % apply the three-term recurrence relation
    fun_poly_temp=@(x) x.*fun_poly_2(x)-beta(k-1)*fun_poly_1(x);   
    fun_ip=@(x) fun_p(x).*fun_poly_temp(x).*fun_poly_temp(x);
    int_temp=integral(fun_ip,-L,L);
    fun_poly_1=fun_poly_2;
    fun_poly_2=fun_poly_temp;
    beta(k)=int_temp/int;
    int=int_temp;
end
% export
dlmwrite('beta_truncated_gaussian.dat',beta(2:end),'precision',32); % discard beta_0
end
