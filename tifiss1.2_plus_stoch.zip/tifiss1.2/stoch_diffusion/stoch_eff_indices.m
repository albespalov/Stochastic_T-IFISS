function [effindices] = stoch_eff_indices(errors,energies,refenergy,varargin)
%STOCH_EFF_INDICES computes the effectivity indices given a reference solution's energy norm
%
% [effindices] = stoch_eff_indices(errors,energies,refenergy,varargin)
%
% input: 
%            errors   vector of computed global errors
%          energies   vector of energies norms of the Galerkin solutions
%         refenergy   energy norm of the reference solution
%             iplot   (optional) plot switch for the effectivity indices 0/1
%
% output:
%        effindices   vector of effectivity indices
%
% The effectivity indices are calculated via the formula:
%   effindices = errors / sqrt(refenergy^2 - energies^2)
%
% See also STOCH_REFENERGY
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  if nargin == 4
      iplot = varargin{1};
  else%if nargin < 4
      iplot = 0;
      if nargin < 3 
          error('Missing reference solution''s energy!');
      end
  end
     
% -----------------------------------------------------------------------------  
% Effectivity indices  
% -----------------------------------------------------------------------------  
  effindices = errors ./ sqrt( refenergy^2 - energies.^2 );

% -----------------------------------------------------------------------------  
% Plot
% -----------------------------------------------------------------------------  
  if iplot == 1  
      fontSizeAxes = 14;
      iter = length(errors);
      figure;
      semilogy(1:iter,effindices(1:iter),'-bo','Linewidth',1.5,'MarkerSize',10);
      hold on; grid on;
      axis([1 iter 0.6 1]);
      xlabel('iteration','FontSize',fontSizeAxes);
      ylabel('effectivity index','FontSize',fontSizeAxes);
      % Setup axis and window's dimension and position 
      set(gca,'YMinorTick','on','YTickMode','manual','YMinorGrid','off',...
              'GridLineStyle','--','FontSize',fontSizeAxes);      
      set(gcf,'units','normalized','Position',[0.25 0.2 0.55 0.65]);
  end
  
end % end function