function [y] = stoch_matvecx(x,G,K)
%STOCH_MATVECX efficient matvec for sum of kronecker product matrices
%   
% [y] = stoch_matvecx(x,G,K)
%
% input
%          x    input vector of dimension (nKi $\times$ nGi)  
%          G    cell structure with noarv (nGi $\times$ nGi) matrices
%          K    cell structure with noarv (nKi $\times$ nKi) matrices 
% output
%          y    output vector of dimension (nKi $\times$ nGi)
%
% NOTE: this function is based on the original SIFISS function
% STOCH_MATVEC (DJS; 19 January 2013).
% The only difference is that now it is compatible with the stiffness 
% matrices allocated up to noarv (instead of norv). 
%
%   TIFISS function: LR; 05 January 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  dimk  = length(K);
  [n,~] = size(K{1});
  [p,~] = size(G{1});
  if ~isequal(length(x),n*p) % length(x) ~= n*p
      error('incompatible input vector');
  end
  
% Reshape input vector
  X = reshape(x,n,p);
  Y = zeros(size(X));
  
% Loop over the number of matrices
  for dim = 1:dimk
      % Efficient kronecker product of matrices: note that there 
      % should be G{dim}', but G-matrices are all symmetric
      Y = Y + K{dim} * X * G{dim};
  end

% Reshape output vector
  y = reshape(Y,n*p,1); 
  
end % end function