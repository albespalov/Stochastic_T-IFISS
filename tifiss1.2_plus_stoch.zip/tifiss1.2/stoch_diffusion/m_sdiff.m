function [x_it]=m_sdiff(f,aparams)
%M_SDIFF stochastic scalar problem exact mean based preconditioner
%   x_it = m_sdiff(x_it,aparams);
%   input
%          x_it         operand for preconditioning operator
%          aparams      structure for matrix vector multiply
%   output
%          x_it         result of MG preconditioning operation
%
%   SIFISS function: DJS; 20 January 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

r=f;   rn0=norm(r);         % initial residual
ndof = length(r); nint=aparams.nint; nsys = ndof/nint;
for k=1:nsys;
    start= nint*(k-1);
    r(start+1:start+nint) = aparams.U\(aparams.L\f(start+1:start+nint));
end
x_it=r;
return
