function [ade,bde,bdem,fde] = stoch_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar)
%STOCH_DIFFPOST_P1_YP_DETCONTRIB elementwise deterministic contributions in the spatial YP estimation
%
% [ade,bde,bdem,fde] = stoch_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar)
%
% input:
%               xy     vertex coordinate vector
%              evt     element mapping matrix
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%        subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%              ade     element-wise lhs contribution 
%              bde     element-wise rhs contribution from p1sol
%             bdem     sub-element-wise rhs contribution from p1sol
%              fde     element-wise rhs contribution from f
%
% The function computes the element-wise contributions to the spatial error
% over either the red or bisec3 uniform refinement.
%
% The following discrete formulation is considered
%
%   B0(eYP,v) = F(v) - B(uXP,v)    for all v \in VYP,
%
% and the element-wise contributions from the deterministic matrices on the 
% LHS as well as the contributions from the source f and the Galerkin 
% solution uXP on the RHS.
%
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_gauss_coeff
%                      stoch_gauss_source
%                      subelt_transf
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nel  = size(evt,1);   % Number of elements
  
% Recover local coordinates
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3); 
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2);
  end
  
% Initialise local matrices  
  adem = zeros(nel,4,3,3);
  xl_s = zeros(nel,4,3); 
  yl_s = zeros(nel,4,3);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% ----------------------------------------------------------------------------- 
% STEP 1: coordinates of midpoints: four sub-elements
% -----------------------------------------------------------------------------

% First physical mid-edge point
  xedge1(:,1) = 0.5 * (xl_v(:,2) + xl_v(:,3));    
  yedge1(:,1) = 0.5 * (yl_v(:,2) + yl_v(:,3));
  
% Second physical mid-edge point
  xedge2(:,1) = 0.5 * (xl_v(:,3) + xl_v(:,1));  
  yedge2(:,1) = 0.5 * (yl_v(:,3) + yl_v(:,1));
  
% Third physical mid-edge point
  xedge3(:,1) = 0.5 * (xl_v(:,1) + xl_v(:,2));  
  yedge3(:,1) = 0.5 * (yl_v(:,1) + yl_v(:,2));

% Define the local sub-division 
  if subdivPar == 1
      %
      % Red sub-division
      % 
      % First physical sub-element 
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge3(:);      yl_s(:,2,1) = yedge3(:);
      xl_s(:,2,2) = xl_v(:,2);      yl_s(:,2,2) = yl_v(:,2);
      xl_s(:,2,3) = xedge1(:);      yl_s(:,2,3) = yedge1(:);
      % Third physical sub-element 
      xl_s(:,3,1) = xedge2(:);      yl_s(:,3,1) = yedge2(:);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xl_v(:,3);      yl_s(:,3,3) = yl_v(:,3);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge1(:);      yl_s(:,4,1) = yedge1(:);
      xl_s(:,4,2) = xedge2(:);      yl_s(:,4,2) = yedge2(:);
      xl_s(:,4,3) = xedge3(:);      yl_s(:,4,3) = yedge3(:);    
  else
      %
      % Bisec3 sub-division
      % 
      % First physical sub-element
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge2(:);      yl_s(:,2,1) = yedge2(:);
      xl_s(:,2,2) = xedge3(:);      yl_s(:,2,2) = yedge3(:);
      xl_s(:,2,3) = xl_v(:,2);      yl_s(:,2,3) = yl_v(:,2);
      % Third physical sub-element 
      xl_s(:,3,1) = xl_v(:,2);      yl_s(:,3,1) = yl_v(:,2);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xedge2(:);      yl_s(:,3,3) = yedge2(:);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge2(:);      yl_s(:,4,1) = yedge2(:);
      xl_s(:,4,2) = xedge1(:);      yl_s(:,4,2) = yedge1(:);
      xl_s(:,4,3) = xl_v(:,3);      yl_s(:,4,3) = yl_v(:,3);
  end    

% ----------------------------------------------------------------------------- 
% STEP 2: left-Hand side of the linear system  
% ----------------------------------------------------------------------------- 

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);  

% Computing deterministic contribution from sub-elements 
  for subelt = 1:4 
      % Recover local coordinates of the current subelement
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end     
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);
          %
          % Evaluate derivatives and stochastic coefficients
          [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigpt,tigpt,xl_m,yl_m);  
          [coeff_v] = stoch_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % B0 bilinear form (i.e., with a_0(x) = coeff_v(:,1))
          for j = 1:3
              for i = 1:3                    
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidx_v(:,i) .* dphidx_v(:,j) .* invjac_v(:);
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidy_v(:,i) .* dphidy_v(:,j) .* invjac_v(:);              
              end
          end
      end
      % end of Gauss point loop
  end
% end of subdivided element loop

% Manual assembly of subelement contributions
  [ade] = assembling_lhs(adem,subdivPar);
  
% ----------------------------------------------------------------------------- 
% STEP 3: right-hand side of the linear system  
% ----------------------------------------------------------------------------- 
  
% Initialise local matrices
  bdem = zeros(nel,4,3,3,noarv+1); 
  fdem = zeros(nel,4,3,noarv+1);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% Computing deterministic contributions from sub-elements  
  for subelt = 1:4
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end
      % Loop over Gauss points
      for igpt = 1:nngpt
          sigpt = s(igpt);   
          tigpt = t(igpt);
          wght  = wt(igpt);
          %
          % Local transformation onto the sub-element of the reference element
          [sigptloc,tigptloc] = subelt_transf(sigpt,tigpt,subelt,subdivPar);
          %
          % Evaluate derivatives
          [~,invjac_v,~,dphidx_v,dphidy_v]  = tderiv(sigptloc,tigptloc,xl_v,yl_v);
          [jac_m,~,phi_m,dphidx_m,dphidy_m] = tderiv(sigpt,tigpt,xl_m,yl_m);
          %
          % Evaluate stochastic coefficient
          [coeff_m] = stoch_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % Evaluate source
          [rhs_m]   = stoch_gauss_source(sigpt,tigpt,xl_m,yl_m,norv);
          %
          % Loop over random variables
          for m = 0:noarv             
              % Loop over sub-element vertices
              for j = 1:3  
                  % Loop over X-basis functions
                  % Contributions: \int_subelt a(x) \grad(Xbasis) \cdot \grad(Ybasis) dx 
                  for i = 1:3                    
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * coeff_m(:,m+1) .* dphidx_v(:,i) .* dphidx_m(:,j) .* invjac_v(:);
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * coeff_m(:,m+1) .* dphidy_v(:,i) .* dphidy_m(:,j) .* invjac_v(:);
                  end
                  %
                  % Compute rhs-contribution from the source f
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) + wght * rhs_m(:,m+1) .* phi_m(:,j) .* jac_m(:); 
              end
          end
      end
      % end Gauss points loop
  end
% end sub-elements loop  

% Manual assembly of sub-element contributions
  [bde,fde] = assembling_rhs(bdem,fdem,subdivPar,noarv);
  
end  % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [ade] = assembling_lhs(adem,subdivPar)
% Elementwise assembling of the deterministic contributions of the lhs 
% for 4 subelements

  ade  = zeros(size(adem,1),3,3);
  
  if subdivPar == 1
      %
      % Red sub-division
      %
      % First edge
      ade(:,1,1) = adem(:,2,3,3) + adem(:,3,2,2) + adem(:,4,1,1);
      ade(:,1,2) = adem(:,3,2,1) + adem(:,4,1,2);
      ade(:,1,3) = adem(:,2,3,1) + adem(:,4,1,3);
      % Second edge
      ade(:,2,1) = adem(:,3,1,2) + adem(:,4,2,1);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,3,1,1) + adem(:,4,2,2);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,4,2,3);  
      % Third edge     
      ade(:,3,1) = adem(:,2,1,3) + adem(:,4,3,1);
      ade(:,3,2) = adem(:,1,2,3) + adem(:,4,3,2);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,1,1) + adem(:,4,3,3);  
      
  else
      %
      % Bisec3 sub-division: 
      %
      % First edge
      ade(:,1,1) = adem(:,3,2,2) + adem(:,4,2,2);
      ade(:,1,2) = adem(:,3,2,3) + adem(:,4,2,1);
      % ae(:,1,3) = empty
      % Second edge
      ade(:,2,1) = adem(:,3,3,2) + adem(:,4,1,2);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,2,1,1) + adem(:,3,3,3) + adem(:,4,1,1);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,2,1,2);
      % Third edge
      % ae(:,3,1) = empty 
      ade(:,3,2) = adem(:,1,2,3) + adem(:,2,2,1);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,2,2);
  end

end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [bde,fde] = assembling_rhs(bdem,fdem,subdivPar,noarv) 
% Elementwise assembling of the deterministic contributions of the rhs 
% for 4 subelements

  bde = zeros(size(bdem,1),3,3,noarv+1);
  fde = zeros(size(bdem,1),3,noarv+1);
  
  if subdivPar == 1
      %
      % Red sub-division
      %
      for m = 0:noarv
          % First edge
          bde(:,1,1,m+1) = bdem(:,2,3,1,m+1) + bdem(:,3,2,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,1,2,m+1) = bdem(:,2,3,2,m+1) + bdem(:,3,2,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,1,3,m+1) = bdem(:,2,3,3,m+1) + bdem(:,3,2,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,1,m+1)   = fdem(:,2,3,m+1)   + fdem(:,3,2,m+1)   + fdem(:,4,1,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,3,1,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,3,1,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,3,1,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,3,1,m+1)   + fdem(:,4,2,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,4,3,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,4,3,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,4,3,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,1,m+1)   + fdem(:,4,3,m+1);
      end
       
  else
      %
      % Bisec3 sub-division
      % 
      for m = 0:noarv  %norv
          % First edge
          bde(:,1,1,m+1) = bdem(:,3,2,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,1,2,m+1) = bdem(:,3,2,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,1,3,m+1) = bdem(:,3,2,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,1,m+1)   = fdem(:,3,2,m+1)   + fdem(:,4,2,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,3,3,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,3,3,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,3,3,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,2,1,m+1)   + fdem(:,3,3,m+1)   + fdem(:,4,1,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,2,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,2,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,2,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,2,m+1);
      end
  end

end % end child function  