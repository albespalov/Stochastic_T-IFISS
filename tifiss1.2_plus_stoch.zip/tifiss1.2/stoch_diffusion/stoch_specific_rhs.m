function [f] = stoch_specific_rhs(x,y,nel,norv)
%STOCH_UNIT_RHS unit deterministic RHS forcing function
%   
% [f] = stoch_specific_rhs(x,y,nel)
%
% input:
%         x       x coordinate vector
%         y       y coordinate vector
%       nel       number of elements
%      norv       number of random variables
%
% output:
%         f       forcing RHS function
%
% NOTE that this is a copy of original SIFISS function (DJS; 2 May 2013) 
%
%   TIFISS function: AB; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  f = [ones(nel,1),zeros(nel,norv)];

end % end function