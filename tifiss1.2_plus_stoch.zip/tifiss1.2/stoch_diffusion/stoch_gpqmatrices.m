function [GPQ] = stoch_gpqmatrices(indset1,indset2)
%STOCH_GPQMATRICES generates stochastic G-matrices for two input index sets
%   
% [GPQ] = stoch_gpqmatrices(indset1,indset2)
%
% input:
%   indset1    1st index set: an m1-row matrix of non-negative integers
%   indset2    2nd index set: an m2-row matrix of non-negative integers
%
% output:
%       GPQ    (noarv2+1)-cell of m2-by-m1 G-matrices (noarv2 is noarv of indset2)
%
% The GPQ-matrices will be computed according to the random variables 
% distribution chosen by the user; new feature by Feng Xu (2017).
% see also STOCH_INIT_STOCH, STOCH_ADAPT_INIT_STOCH.
%
% The GPQ-matrix (and G-matrix) entries are based on the coefficients of the
% 3-terms-recurrence formula satisfied by the orthonormal polynomials 
% in [-1,1] w.r.t the chosen distribution (currently, uniform and 
% truncated Gaussian):
%
%           beta_{n+1}P_{n+1}(y) = yP_n(y) - beta_{n}P_{n-1}(y).
%
% - distribution = uniform on [-1,1], then {P_n} are orthonormal Legendre 
%   polynomials w.r.t. density dy/2, and beta_{n} = n/sqrt{4n^2 - 1};  
% - distribution = truncated Gaussian on [-1,1], then the beta_{n} coefficients 
%   are loaded from datafiles/beta_truncated_gaussian.dat file;
%   see also STOCH_TRUNC_GAUSS_COEFFX.
%
% Main Reference:
% Lord, Powell, Shardlow, An introduction to computational stochastic 
% PDEs, Cambridge University Press,2014
%
% See also STOCH_GMATRICESX
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Computing sizes of indset1 and indset2
  [P1,norv] = size(indset1);
  [P2,~]    = size(indset2);
 
% Finding the 'number of active random variables' of indset2. If
%   indset2 = [ 0   1   0   0   ...],
% then noarv of indset2 is 1, but we need to take 2, as the last parameter 
% activated is in 2nd position.
% This allows the right computation of GPQ matrices also when the
% enrichment is just M-. See STOCH_DETAIL_INDSET
  [~,col] = find(indset2);
  noarv2  = max(col);
% noarv2 = norv - nnz( all(indset2 == 0, 1) ); <-- this will return noarv2 = 1

% Preallocate cells up to noarv2+1
  GPQ = cell(1,noarv2+1); 
  I = uint8(eye(norv)); 

% Initialise GPQ_0 = GPQ{1}: this always is the zero matrix
  GPQ{1} = sparse(P2,P1);
  
% -------------------------------------------------------------------------  
% Compute GPQ_1,...,GPQ_noarv2 = GPQ{2},...,GPQ_{noarv2+1}
% -------------------------------------------------------------------------

% Define GPQ-matrix entries according to the r.v. distribution
  parameter = csvread('parameter_choice.dat');
  distribution = parameter(2);
  if distribution == 1
      % Uniform
      gpqentry = @(nu) double(nu) ./ (sqrt(4.0*double(nu).^2 - 1.0));
  else% distribution == 2
      % Truncated Gaussian: load beta values
      beta = csvread('beta_truncated_gaussian.dat');
      gpqentry = @(nu) sqrt( beta(double(nu)) );
  end
  
  for m = 1:noarv2      
      % Correct index m for the matrices is m+1
      
      % Preallocate memory
      GPQ{m+1} = sparse(P2,P1);
      
      % eps_m matrix for the current value of m
      eps_m = repmat(I(m,:),P2,1);
      
      % Cheking sequences of indset2 + eps_m  
      [one,two] = ismember(indset2 + eps_m,indset1,'rows');
      row = find(one);
      col = nonzeros(two);
      if ~isempty(row)      
          GPQ{m+1} = GPQ{m+1} + sparse(row, col, gpqentry(row), P2, P1);          
      end
      
      % Cheking sequences of indset2 - eps_m 
      [one,two] = ismember(indset2 - eps_m,indset1,'rows');
      row = find(one);
      col = nonzeros(two);
      if ~isempty(row)
          nu = indset2(row,:);
          GPQ{m+1} = GPQ{m+1} + sparse(row, col, gpqentry(nu(:,m)), P2, P1);
      end  
  end
 
end % end function