%STOCH_REFENERGY computes the reference solution and its energy
%
% The reference solution is computed with P2 Galerkin approximations using:
% - a uniform refinement of the last mesh produced when the loop terminates,  
% - an index set given by the union of the last index set generated and the 
%   last set of marked indices when the loop terminates
% 
% Function(s) called: uniform_refinement
%                     p2_grid_generator
%                     stoch_femp2_setup
%                     stoch_imposebcx
%                     stoch_est_minresx
%                     stoch_variancex
%                     stoch_matvecx
%                     stoch_eff_indices
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  fprintf('\n');fprintf(num2str(repmat('-',1,75)));

  fprintf('\n<strong>Reference solution</strong> computed with P2 approximation using:\n');
  fprintf('- a uniform refinement of the last mesh obtained\n');
  fprintf('- the union of the last index set generated and the last set of marked indices.\n');

% -------------------------------------------------------------------------  
% Uniform refinement of the last mesh
% -------------------------------------------------------------------------
  [refxy,refevt,refbound,~,refeboundt] = uniform_refinement(xy,evt,bound,eboundt,2);
  fprintf('\n<strong>Mesh refinement:</strong>\n');
  fprintf('   total vertices:    %d\n',size(refxy,1));
  fprintf('   total elements:    %d',size(refevt,1));

% -------------------------------------------------------------------------  
% Parametric enrichment using the last set of the marked indices
% -------------------------------------------------------------------------
% Resize indeset correctly
  indset = uint8([indset,zeros(size(indset,1),norv-size(indset,2))]);
% Enrichment
  [~,Q_noarv] = find(Q_indset(M_ind,:));
  if (max(Q_noarv) + extra_rv) > norv
      error('<strong>Too many active parameters...</strong>\n');
  end
  indset = [indset; Q_indset(M_ind,:)];
% Length of the index set, active parameters, and degree
  P = size(indset,1);
  noarv = norv - nnz(all(indset == 0,1));
  polyd = max(sum(indset,2));
% Sort the index set
  indset = sortrows(indset);
  
  fprintf('\n<strong>Parametric enrichment:</strong>\n');
  fprintf('   total indices:     %d\n',P);
  fprintf('   active parameters: %d\n',noarv);
  
% -------------------------------------------------------------------------
% Setup and solve the discrete system  
% -------------------------------------------------------------------------
% New G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);
  
% Generating the P2 grid
  [p2xy,p2evt,p2bound] = p2_grid_generator(refxy,refevt,refbound);
  [Knbc,fnbc] = stoch_femp2_setup(p2xy,p2evt,indset,P,norv,noarv,KL_DATA);
  
% Boundary conditions
  [K,fnew,x_gal,dupl_intern] = stoch_imposebcx(Knbc,fnbc,G,p2xy,p2bound,indset,P,norv,noarv);

% Dofs
  totaldofs   = P*size(p2xy,1);
  intotaldofs = P*(size(p2xy,1) - length(p2bound));

% Number of internal node
  nint = length(dupl_intern)/P;

% -------------------------------------------------------------------------  
% MINRES solver      
% -------------------------------------------------------------------------
  Amean = K{1};
  [L,U,PP,QQ] = lu(Amean);        
  tol = 1e-10;    maxit = 99;
  apost = 0;      stopit = 0;    prob_type = 'sdiff';
  MA = 'm_sdiff'; aparams = struct('nint',nint,'L',PP\L,'U',U/QQ);
  
  [xminres,~,~,~,~] = stoch_est_minresx(G,K,fnew,apost,stopit,maxit,tol,prob_type,MA,aparams);                                     

% Computed reference solution                  
  x_gal(dupl_intern) = xminres;

% Computed variance
  [refvarsol] = stoch_variancex(x_gal,P);

% Energy norm of the reference solution
  [bref]    = stoch_matvecx(x_gal,G,Knbc);
  refenergy = sqrt(x_gal' * bref);
  
% -------------------------------------------------------------------------  
% Print data
% -------------------------------------------------------------------------  
  fprintf('<strong>New dofs:</strong>\n');
  fprintf('   Overall P2 total dofs:    %d\n',totaldofs); 
  fprintf('   Overall P2 internal dofs: %d\n',intotaldofs); 
  fprintf('<strong>Reference solution:</strong>\n');
  fprintf('   Maximum mean value:       %8.3e\n',max(x_gal(1:nvtx)));      
  fprintf('   Maximum variance:         %8.3e\n',max(refvarsol));
  fprintf('   Energy norm:              %8.4e\n',refenergy);

% Save data for solution's energy norm
  gohome; cd datafiles;
  save stoch_refsolution.mat refenergy totaldofs intotaldofs indset refxy refevt refbound refeboundt;
                            
  fprintf('\n-> Data saved to: datafiles/stoch_refsolution.mat\n');
  
% -------------------------------------------------------------------------
% Effectivity indices
% -------------------------------------------------------------------------
  fprintf('\nPlotting effectivity indices...');
  [effindices] = stoch_eff_indices(error_iter,energy_iter,refenergy,1);
  fprintf('done\n');
  fprintf(num2str(repmat('-',1,75)));fprintf('\n\n');

% end scriptfile