function [ade,bde,bdem,fde,gde] = stoch_goafem_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar)
%STOCH_GOAFEM_DIFFPOST_P1_YP_DETCONTRIB elementwise deterministic contributions in the spatial YP estimation
%
% [ade,bde,bdem,fde,gde] = stoch_goafem_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar)
%
% input:
%               xy     vertex coordinate vector
%              evt     element mapping matrix
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%        subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%              ade     elementwise lhs contribution 
%              bde     elementwise rhs contribution from galerkin solutions
%             bdem     sub-elementwise rhs contribution from galerkin solutions
%              fde     elementwise rhs contribution from F (primal)
%              gde     elementwise rhs contribution from G (dual)
%
% The function computes the elementwise contributions to the spatial error
% over either the red or bisec3 uniform refinement for both primal and dual
% error problems.
%
% The following discrete formulations are considered:
%
%   B0(eYP,v) = F(v) - B(uXP,v),  for all v \in V_YP,  (primal)
%   B0(eYP,v) = G(v) - B(zXP,v),  for all v \in V_YP,  (dual)
%
% Recall that the source F(v) (resp. G(v)) of (1) (resp. of (2)) follows the 
% representation of [MS09] (and [FPZ16]); see also STOCH_GOAFEM_FEMP1_SETUP.
%
% References:
%
% [MS09] Mommer, Stevenson, A goal-oriented finite element method with
% convergence rates, SIAM J. Numer. Anal., 47(2)861-866, 2009;
%
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016;
%
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_goafem_gauss_coeff
%                      stoch_goafem_gauss_L2
%                      stoch_goafem_gauss_H1
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel  = size(evt,1);   % Number of elements
  
% Recover local coordinates
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3); 
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2);
  end
  
% Initialise local matrices  
  adem = zeros(nel,4,3,3);
  xl_s = zeros(nel,4,3); 
  yl_s = zeros(nel,4,3);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% ----------------------------------------------------------------------------- 
% STEP 1: coordinates of midpoints: four sub-elements
% -----------------------------------------------------------------------------
% First physical mid-edge point
  xedge1(:,1) = 0.5 * (xl_v(:,2) + xl_v(:,3));    
  yedge1(:,1) = 0.5 * (yl_v(:,2) + yl_v(:,3));
  
% Second physical mid-edge point
  xedge2(:,1) = 0.5 * (xl_v(:,3) + xl_v(:,1));  
  yedge2(:,1) = 0.5 * (yl_v(:,3) + yl_v(:,1));
  
% Third physical mid-edge point
  xedge3(:,1) = 0.5 * (xl_v(:,1) + xl_v(:,2));  
  yedge3(:,1) = 0.5 * (yl_v(:,1) + yl_v(:,2));

% Define the local sub-division 
  if subdivPar == 1
      %
      % Red sub-division
      % 
      % First physical sub-element 
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge3(:);      yl_s(:,2,1) = yedge3(:);
      xl_s(:,2,2) = xl_v(:,2);      yl_s(:,2,2) = yl_v(:,2);
      xl_s(:,2,3) = xedge1(:);      yl_s(:,2,3) = yedge1(:);
      % Third physical sub-element 
      xl_s(:,3,1) = xedge2(:);      yl_s(:,3,1) = yedge2(:);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xl_v(:,3);      yl_s(:,3,3) = yl_v(:,3);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge1(:);      yl_s(:,4,1) = yedge1(:);
      xl_s(:,4,2) = xedge2(:);      yl_s(:,4,2) = yedge2(:);
      xl_s(:,4,3) = xedge3(:);      yl_s(:,4,3) = yedge3(:);    
  else
      %
      % Bisec3 sub-division
      % 
      % First physical sub-element
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge2(:);      yl_s(:,2,1) = yedge2(:);
      xl_s(:,2,2) = xedge3(:);      yl_s(:,2,2) = yedge3(:);
      xl_s(:,2,3) = xl_v(:,2);      yl_s(:,2,3) = yl_v(:,2);
      % Third physical sub-element 
      xl_s(:,3,1) = xl_v(:,2);      yl_s(:,3,1) = yl_v(:,2);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xedge2(:);      yl_s(:,3,3) = yedge2(:);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge2(:);      yl_s(:,4,1) = yedge2(:);
      xl_s(:,4,2) = xedge1(:);      yl_s(:,4,2) = yedge1(:);
      xl_s(:,4,3) = xl_v(:,3);      yl_s(:,4,3) = yl_v(:,3);
  end    

% ----------------------------------------------------------------------------- 
% STEP 2: left-hand side of the linear system  
% ----------------------------------------------------------------------------- 

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);

% Computing deterministic contribution from sub-elements 
  for subelt = 1:4 
      % Recover local coordinates of the current subelement
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end     
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);
          % Evaluate derivatives and stochastic coefficients
          [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigpt,tigpt,xl_m,yl_m);  
          [coeff_v] = stoch_goafem_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          % B0 bilinear form (i.e., with a_0(x) = coeff_v(:,1))
          for j = 1:3
              for i = 1:3                    
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidx_v(:,i) .* dphidx_v(:,j) .* invjac_v(:);
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidy_v(:,i) .* dphidy_v(:,j) .* invjac_v(:);              
              end
          end
      end
      % end of Gauss point loop
  end
% end of subdivided element loop

% Manual assembly of subelement contributions
  [ade] = assembling_lhs(adem,subdivPar);
  
% ----------------------------------------------------------------------------- 
% STEP 3: right-hand side of the linear system  
% ----------------------------------------------------------------------------- 
  
% Initialise local matrices
  bdem = zeros(nel,4,3,3,noarv+1); 
  fdem = zeros(nel,4,3,noarv+1);
  gdem = zeros(nel,4,3,noarv+1);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% Computing deterministic contributions from sub-elements  
  for subelt = 1:4
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end
      % Loop over Gauss points
      for igpt = 1:nngpt
          sigpt = s(igpt);   
          tigpt = t(igpt);
          wght  = wt(igpt);
          %
          % Local transformation onto the sub-element of the reference element
          [sigptloc,tigptloc] = subelt_transf(sigpt,tigpt,subelt,subdivPar);
          %
          % Evaluate derivatives, coefficients, and sources
          [~,invjac_v,~,dphidx_v,dphidy_v]  = tderiv(sigptloc,tigptloc,xl_v,yl_v);
          [jac_m,~,phi_m,dphidx_m,dphidy_m] = tderiv(sigpt,tigpt,xl_m,yl_m);
          [coeff_m] = stoch_goafem_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % L2rhs and H1rsh for primal problem
          [rhs0_m]          = stoch_goafem_gauss_L2(sigpt,tigpt,xl_m,yl_m,norv,1);  %goasgfem_gauss_source(sigpt,tigpt,xl_m,yl_m,norv,1);
          [rhs1_m,rhs2_m]   = stoch_goafem_gauss_H1(sigpt,tigpt,xl_m,yl_m,norv,1);
          % 
          % L2rhs and H1rsh for dual problem
          [goal0_m]         = stoch_goafem_gauss_L2(sigpt,tigpt,xl_m,yl_m,norv,2);  %goasgfem_gauss_source(sigpt,tigpt,xl_m,yl_m,norv,2);
          [goal1_m,goal2_m] = stoch_goafem_gauss_H1(sigpt,tigpt,xl_m,yl_m,norv,2);
          %
          % Loop over random variables
          for m = 0:noarv  %norv             
              % Loop over sub-element vertices
              for j = 1:3
                  % Compute rhs-contribution from the source f:
                  % Primal rhs
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) + wght * rhs0_m(:,m+1) .* phi_m(:,j) .* jac_m(:);  % L2 part
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) - wght * rhs1_m(:,m+1) .* dphidx_m(:,j);           % H1-part 1/2
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) - wght * rhs2_m(:,m+1) .* dphidy_m(:,j);           % H1-part 2/2        
                  % Dual rhs
                  gdem(:,subelt,j,m+1) = gdem(:,subelt,j,m+1) + wght * goal0_m(:,m+1) .* phi_m(:,j) .* jac_m(:); % L2 part
                  gdem(:,subelt,j,m+1) = gdem(:,subelt,j,m+1) - wght * goal1_m(:,m+1) .* dphidx_m(:,j);          % H1-part 1/2
                  gdem(:,subelt,j,m+1) = gdem(:,subelt,j,m+1) - wght * goal2_m(:,m+1) .* dphidy_m(:,j);          % H1-part 2/2
                  % Loop over X-basis functions
                  % Contributions: \int_subelt a(x) \grad(Xbasis) \cdot \grad(Ybasis) dx 
                  for i = 1:3                    
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * coeff_m(:,m+1) .* dphidx_v(:,i) .* dphidx_m(:,j) .* invjac_v(:);
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * coeff_m(:,m+1) .* dphidy_v(:,i) .* dphidy_m(:,j) .* invjac_v(:);                
                  end
              end
          end
      end
      % end Gauss points loop
  end
% end sub-elements loop  

% Manual assembly of sub-element contributions
  [bde,fde,gde] = assembling_rhs(bdem,fdem,gdem,subdivPar,noarv);
    
end  % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [ade] = assembling_lhs(adem,subdivPar)
% Elementwise assembling of the deterministic contributions of the lhs 
% for 4 subelements

  ade  = zeros(size(adem,1),3,3);
  
  if subdivPar == 1
      %
      % Red sub-division
      %
      % First edge
      ade(:,1,1) = adem(:,2,3,3) + adem(:,3,2,2) + adem(:,4,1,1);
      ade(:,1,2) = adem(:,3,2,1) + adem(:,4,1,2);
      ade(:,1,3) = adem(:,2,3,1) + adem(:,4,1,3);
      % Second edge
      ade(:,2,1) = adem(:,3,1,2) + adem(:,4,2,1);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,3,1,1) + adem(:,4,2,2);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,4,2,3);  
      % Third edge     
      ade(:,3,1) = adem(:,2,1,3) + adem(:,4,3,1);
      ade(:,3,2) = adem(:,1,2,3) + adem(:,4,3,2);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,1,1) + adem(:,4,3,3);  
      
  else
      %
      % Bisec3 sub-division: 
      %
      % First edge
      ade(:,1,1) = adem(:,3,2,2) + adem(:,4,2,2);
      ade(:,1,2) = adem(:,3,2,3) + adem(:,4,2,1);
      % ae(:,1,3) = empty
      % Second edge
      ade(:,2,1) = adem(:,3,3,2) + adem(:,4,1,2);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,2,1,1) + adem(:,3,3,3) + adem(:,4,1,1);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,2,1,2);
      % Third edge
      % ae(:,3,1) = empty 
      ade(:,3,2) = adem(:,1,2,3) + adem(:,2,2,1);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,2,2);
  end

end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [bde,fde,gde] = assembling_rhs(bdem,fdem,gdem,subdivPar,noarv) 
% Elementwise assembling of the deterministic contributions of the rhs 
% for 4 subelements

  bde = zeros(size(bdem,1),3,3,noarv+1);
  fde = zeros(size(bdem,1),3,noarv+1);
  gde = zeros(size(bdem,1),3,noarv+1);
  
  if subdivPar == 1
      %
      % Red sub-division
      %
      for m = 0:noarv
          % First edge
          bde(:,1,1,m+1) = bdem(:,2,3,1,m+1) + bdem(:,3,2,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,1,2,m+1) = bdem(:,2,3,2,m+1) + bdem(:,3,2,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,1,3,m+1) = bdem(:,2,3,3,m+1) + bdem(:,3,2,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,1,m+1)   = fdem(:,2,3,m+1)   + fdem(:,3,2,m+1)   + fdem(:,4,1,m+1);
          gde(:,1,m+1)   = gdem(:,2,3,m+1)   + gdem(:,3,2,m+1)   + gdem(:,4,1,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,3,1,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,3,1,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,3,1,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,3,1,m+1)   + fdem(:,4,2,m+1);
          gde(:,2,m+1)   = gdem(:,1,3,m+1)   + gdem(:,3,1,m+1)   + gdem(:,4,2,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,4,3,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,4,3,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,4,3,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,1,m+1)   + fdem(:,4,3,m+1);
          gde(:,3,m+1)   = gdem(:,1,2,m+1)   + gdem(:,2,1,m+1)   + gdem(:,4,3,m+1);
      end
       
  else
      %
      % Bisec3 sub-division
      % 
      for m = 0:noarv  %norv
          % First edge
          bde(:,1,1,m+1) = bdem(:,3,2,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,1,2,m+1) = bdem(:,3,2,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,1,3,m+1) = bdem(:,3,2,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,1,m+1)   = fdem(:,3,2,m+1)   + fdem(:,4,2,m+1);
          gde(:,1,m+1)   = gdem(:,3,2,m+1)   + gdem(:,4,2,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,3,3,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,3,3,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,3,3,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,2,1,m+1)   + fdem(:,3,3,m+1)   + fdem(:,4,1,m+1);
          gde(:,2,m+1)   = gdem(:,1,3,m+1)   + gdem(:,2,1,m+1)   + gdem(:,3,3,m+1)   + gdem(:,4,1,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,2,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,2,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,2,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,2,m+1);
          gde(:,3,m+1)   = gdem(:,1,2,m+1)   + gdem(:,2,2,m+1);
      end
  end

end % end child function  