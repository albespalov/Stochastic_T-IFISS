function [K,F,G] = stoch_goafem_femp1_setup(xy,evt,indset,P,norv,noarv,KL_DATA)
%STOCH_GOAFEM_FEMP1_SETUP assembled P1 stochastic coefficient matrix generator for both primal and dual problems
%
% [K,F,G] = stoch_goafem_femp1_setup(xy,evt,indset,P,norv,noarv,KL_DATA)
%   
% input:
%               xy     vertex coordinate vector  
%              evt     element mapping matrix
%           indset     index set of polynomial degrees
%                P     length of the index set
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%
% output:
%                K     cell structure with noarv matrices 
%                F     rhs vector for primal problem
%                G     rhs vector for dual problem
%
% The representation of the rhs (for both the primal and the dual problems)
% follows the one used in [MS09] (and [FPZ16]), which allows the estimation of 
% goal-functionals including (partial) derivatives of the (primal) solution 
% and also it introduces different non-geometric singularities in the primal 
% and/or dual solutions. 
%
% References:
%
% [MS09] Mommer, Stevenson, A goal-oriented finite element method with
% convergence rates, SIAM J. Numer. Anal., 47(2)861-866, 2009;
%
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016;
%
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_goafem_gauss_coeff
%                      stoch_goafem_gauss_L2
%                      stoch_goafem_gauss_H1
%                      stoch_rhs_multipliers
%
% See also STOCH_GOAFEM_FEMP2_SETUP
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);  % Number of vertices
  nel  = size(evt,1); % Number of elements

% Initialise global stochastic matrices and rhs vectors
  ade = zeros(nel,3,3,noarv+1);
  fde = zeros(nel,3,noarv+1);
  gde = zeros(nel,3,noarv+1);
  F   = zeros(nvtx*P,1);
  G   = zeros(nvtx*P,1);

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 73;
  [s,t,wt] = triangular_gausspoints(nngpt);

% Recover local coordinates  
  xl_v = zeros(nel,3);
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2); 
  end

% Loop over Gauss points 
  for igpt = 1:nngpt
      sigpt = s(igpt);
      tigpt = t(igpt);
      wght  = wt(igpt);
      %
      % Evaluate derivatives
      [jac,invjac,phi,dphidx,dphidy] = tderiv(sigpt,tigpt,xl_v,yl_v);
      %
      % Evaluate coefficients
      [coeff] = stoch_goafem_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
      %
      % Evaluate L2-rhs for primal and dual problem
      [rhs]  = stoch_goafem_gauss_L2(sigpt,tigpt,xl_v,yl_v,norv,1);
      [goal] = stoch_goafem_gauss_L2(sigpt,tigpt,xl_v,yl_v,norv,2);
      %
      % Evaluate H1-rhs for primal and dual problem
      [rhs1,rhs2]   = stoch_goafem_gauss_H1(sigpt,tigpt,xl_v,yl_v,norv,1);
      [goal1,goal2] = stoch_goafem_gauss_H1(sigpt,tigpt,xl_v,yl_v,norv,2);    
      %
      % Loop over active random variables
      for m = 0:noarv
          % Loop over basis functions
          for j = 1:3
              for i = 1:3
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff(:,m+1) .* dphidx(:,i) .* dphidx(:,j) .* invjac(:);
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff(:,m+1) .* dphidy(:,i) .* dphidy(:,j) .* invjac(:);
              end
              % Source term of primal problem
              fde(:,j,m+1) = fde(:,j,m+1) + wght * rhs(:,m+1)   .* phi(:,j) .* jac(:); % L2-part
              fde(:,j,m+1) = fde(:,j,m+1) - wght * rhs1(:,m+1)  .* dphidx(:,j);        % H1-part 1/2
              fde(:,j,m+1) = fde(:,j,m+1) - wght * rhs2(:,m+1)  .* dphidy(:,j);        % H1-part 2/2
              %
              % Source term of dual problem
              gde(:,j,m+1) = gde(:,j,m+1) + wght * goal(:,m+1)  .* phi(:,j) .* jac(:); % L2-part
              gde(:,j,m+1) = gde(:,j,m+1) - wght * goal1(:,m+1) .* dphidx(:,j);        % H1-part 1/2
              gde(:,j,m+1) = gde(:,j,m+1) - wght * goal2(:,m+1) .* dphidy(:,j);        % H1-part 2/2           
          end
      end
  end

% Cell structure to hold matrices K_1,...,K_{noarv}
  K = cell(1,noarv+1); %norv+1);
  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);

% Assembly of global matrices and rhs vector
  for m = 0:noarv      
      % Preallocation
      ad = sparse(nvtx,nvtx);
      fd = zeros(nvtx,1);
      gd = zeros(nvtx,1);
      for krow = 1:3
          nrow = evt(:,krow);
          for kcol = 1:3
              ncol = evt(:,kcol);
              ad = ad + sparse(nrow,ncol,ade(:,krow,kcol,m+1),nvtx,nvtx);
          end
          for els = 1:nel
              fd(nrow(els),1) = fd(nrow(els),1) + fde(els,krow,m+1);
              gd(nrow(els),1) = gd(nrow(els),1) + gde(els,krow,m+1);
          end
      end        
      % Save assembled matrix
      K{m+1} = ad;    
      % Assemble the rhs vector
      ind_m = rhs_ind(1,m+1);
      if ind_m > 0
         F(nvtx*(ind_m-1)+1:nvtx*ind_m,1) = fd(:,1) * beta(1,m+1);
         G(nvtx*(ind_m-1)+1:nvtx*ind_m,1) = gd(:,1) * beta(1,m+1);
      end
  end
   
end % end function