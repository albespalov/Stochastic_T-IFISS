%STOCH_GOAFEM_CONVPLOT plots the computed error estimates versus the overall number of dofs
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

% Set sizes for legend, axis, markers, and linewidth
  fontSizeLegend = 14;
  fontSizeAxis   = 14;
  markerSizePlot = 12;
  lindeWidthPlot = 1.5;
  
% Set of colors
  darkGreen  = [0.0 100 0.0] ./ 255;
  lightGrenn = [0.0 153 0.0] ./ 255;
  brownPeru  = [205 133  63] ./ 255;
  chocolate  = [210 105  30] ./ 255;
   
% Set limit for degrees of freedom
  xLimInf = (4)*10^(1.0);
  xLimSup = (1)*10^(6.0);
  if ismember(sn,[1,2])
      yLimInf = 10^(-6.0);
      yLimSup = 10^(-1);     
  elseif ismember(sn,[3,4])
      yLimInf = 10^(-5.0);
      yLimSup = 10^(-0.5);
  else%sn==5
      yLimInf = 10^(-3.0);
      yLimSup = 10^(-0);
  end
  
% ----------------------------------------------------------------------------- 
% Plot
% -----------------------------------------------------------------------------
  figure;
  
% Global error estimates (primal) - circles, blue
  loglog(dofInt_iter,error_primal_iter,'bo-','Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot); 
  hold on;

% Global error estimates (dual) - squares, red
  loglog(dofInt_iter,error_dual_iter,'rs-','Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot); 

% Global product estimates - triangles, green
  loglog(dofInt_iter,error_iter,'^-','Color',lightGrenn,'Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
  
  grid on;
  axis([xLimInf xLimSup yLimInf yLimSup]);
  xlabel('degrees of freedom $N$','FontSize',fontSizeAxis,'interpreter','latex');
  ylabel('error estimates','FontSize',fontSizeAxis,'interpreter','latex');

% Reference rates
  if ismember(sn,[1,2])
      loglog([xLimInf xLimSup],0.3*[xLimInf xLimSup].^(-1/3),'k-');
      loglog([xLimInf xLimSup],0.2*[xLimInf xLimSup].^(-3/4),'-.','Color',darkGreen);
  elseif sn == 3
      loglog([xLimInf xLimSup],0.7*[xLimInf xLimSup].^(-1/3),'k-');
      loglog([xLimInf xLimSup],1.0*[xLimInf xLimSup].^(-3/4),'-.','Color',darkGreen);
  elseif sn == 4
      loglog([xLimInf xLimSup],0.7*[xLimInf xLimSup].^(-1/3),'k-');
      loglog([xLimInf xLimSup],0.4*[xLimInf xLimSup].^(-3/4),'-.','Color',darkGreen);
  elseif sn == 5
      loglog([xLimInf xLimSup],3.5*[xLimInf xLimSup].^(-1/3),'k-');
      loglog([xLimInf xLimSup],4.0*[xLimInf xLimSup].^(-3/4),'-.','Color',darkGreen);
  end
  hl = legend('$\mu_\ell$ (primal)','$\zeta_\ell$ (dual)','$\mu_\ell\zeta_\ell$','$N^{ -1/3}$','$N^{ -3/4}$'); 
  set(hl,'FontSize',fontSizeLegend,'interpreter','latex');
   
% ----------------------------------------------------------------------------- 
% Setup axis, position, and size of the plot windows
% -----------------------------------------------------------------------------
  set(gca,'XTick',[10^1 10^2 10^3 10^4 10^5 10^6],...
          'XTickMode','manual',...
          'XMinorTick','on', 'YMinorTick','on',...
          'XMinorGrid','off','YMinorGrid','off',...
          'GridLineStyle','--','FontSize',fontSizeAxis);
  set(gcf,'units','normalized','Position',[0.25 0.05 0.55 0.8]);
  hold off;

% end scriptfile