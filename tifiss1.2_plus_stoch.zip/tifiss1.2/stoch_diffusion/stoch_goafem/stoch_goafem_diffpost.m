%STOCH_GOAFEM_DIFFPOST a posteriori error estimation for the adaptive goal-oriented algorithm
%
% The function implements P1-based error approximation scheme for the stochastic 
% Galerkin FE solution and it includes three types of estimations for the
% spatial component of the error:
%
% 1 - eYP hierarchical estimator (solving elementwise residual problems);
% 2 - eYP hierarchical estimator (solving fully assembled residual problem);
% 3 - 2-level error estimator.
%
% NOTE that it is possible to choose between red and bisec3 uniform  
% sub-divisions for the spatial estimation by changing the variable 'subdivPar'; 
% see STOCH_GOAFEM_INIT_PARAM.
%
% The global error estimate is returned in the variable "tot_err_est".
%
% Function(s) called: tedgegen
%                     p1grid_detail_space
%                     stoch_goafem_diffpost_p1_yp
%                     stoch_goafem_diffpost_p1_yp_linsys
%                     stoch_goafem_diffpost_p1_yp_2level
%                     stoch_adapt_new_indset
%                     stoch_gpqmatrices
%                     stoch_goafem_diffpost_p1_xq
%
%   TIFISS scriptfile: LR; 04 July 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  if pmethod == 1
      fprintf('\n<strong>A posteriori error estimation for P1 approximations:</strong>\n'); 
      %    
      % If polenr_or_meshref == 1, the parametric enrichment has been 
      % done during the current iteration, so the mesh remained the same;
      if polenr_or_meshref == 2
          % Mesh refinement has been done during the current iteration: 
          % edge connections and edge lengths have to be updated
          %
          % Update edge connections/lengths
          fprintf('Updating edge lengths/connections');
          edgeGenTime = tic;
          [eex,tve,els] = tedgegen(xy,evt);
          fprintf(' (%.5f sec)\n',toc(edgeGenTime));
          %
          % Update detail space Y 
          fprintf('Updating spatial detail space Y');
          detailTime = tic;
          [evtY,xyY,boundY,Ybasis] = p1grid_detail_space(xy,evt);
          fprintf('   (%.5f sec)\n',toc(detailTime));
      end
  
      % -------------------------------------------------------------------
      % YP error estimation 
      % -------------------------------------------------------------------
      % The estimation is based on the full detail space Y composed of basis
      % functions associated with all edge midpoints. 
      fprintf('<strong>YP-error estimation:</strong>\n');
      yptime = tic;
          
      if ypestim == 1         
          % Hierarchical eYP estimator: elementwise local residual problems. 
          % The elementwise B0-norms of local estimators are used for marking elements
          [yp_elerr_primal,yp_est_primal, ...
           yp_elerr_dual,  yp_est_dual] = ...
           stoch_goafem_diffpost_p1_yp(xy,evt,eboundt,u_gal,z_gal,evtY,xyY,...
                      eex,tve,els,G,indset,P,norv,noarv,KL_DATA,subdivPar);

      elseif ypestim == 2
          % Hierarchical eYP estimator: fully assembled residual problems.
          % Both edge-indicators and element-indicators are returned.
          [yp_elerr_primal, yp_ederr_primal, yp_est_primal, ...
           yp_elerr_dual,   yp_ederr_dual,   yp_est_dual] = ...
           stoch_goafem_diffpost_p1_yp_linsys(xy,evt,eboundt,evtY,xyY,boundY,...
                        Ybasis,u_gal,z_gal,G,P,norv,noarv,KL_DATA,subdivPar);
                        
      else
          % 2-Level error estimator. Both edge-indicators and element-indicators
          % are returned
          [yp_elerr_primal, yp_ederr_primal, yp_est_primal, ...
           yp_elerr_dual,   yp_ederr_dual,   yp_est_dual] = ...
           stoch_goafem_diffpost_p1_yp_2level(xy,evt,eboundt,evtY,xyY,boundY,...
                         Ybasis,u_gal,z_gal,G,P,norv,noarv,KL_DATA,subdivPar);                   
      end       
                 
      fprintf('   YP-estimation (primal):   %10.4e\n',yp_est_primal);
      fprintf('   YP-estimation (dual):     %10.4e\n',yp_est_dual);
      fprintf('(YP-error estimation took %.5f sec)\n',toc(yptime)); 
          
      % -------------------------------------------------------------------
      % XQ error estimator
      % -------------------------------------------------------------------
      fprintf('<strong>XQ-error estimation:</strong>\n');
      xqtime = tic;
      % Compute (or not) new Q_indset and GPQ matrices?
      if polenr_or_meshref == 1
          % Parametric enrichment has been chosen in the current iteration: 
          % new Q-index set and corresponding new GPQ stochastic matrices
          % have to be computed
          fprintf('Computing new ''Q'' indset and GPQ matrices...');    
          % Compute Q index set
          [new_indset] = stoch_adapt_new_indset(indset,noarv,extra_rv);
          Q_indset     = new_indset(~ismember(new_indset,indset,'rows'),:);
          % Compute G-matrices for P and Q index set (of size Q-by-P) 
          [GPQ] = stoch_gpqmatrices(indset,Q_indset);
          fprintf('done\n');
      end
      [xq_elerr_primal, xq_errvec_primal, xq_est_primal, ...
       xq_elerr_dual,   xq_errvec_dual,   xq_est_dual] = ...                     
       stoch_goafem_diffpost_p1_xq(xy,evt,bound,u_gal,z_gal,indset,norv,KL_DATA,Q_indset,GPQ);
      
      fprintf('   XQ-estimation (primal):   %10.4e\n',xq_est_primal);
      fprintf('   XQ-estimation (dual):     %10.4e\n',xq_est_dual);
      fprintf('(XQ-error estimation took %.5f sec)\n',toc(yptime));
      
  elseif pmethod == 2
      %
      % Not implemented yet
      %
      error('P2 error estimation is not implemented...');
  end
      
% ---------------------------------------------------------------------
% Compute total error estimator
% ---------------------------------------------------------------------
  tot_est_primal = sqrt(yp_est_primal^2 + xq_est_primal^2);
  tot_est_dual   = sqrt(yp_est_dual^2   + xq_est_dual^2);
  tot_err_est    = tot_est_primal * tot_est_dual;
  fprintf('\n<strong>Total error estimate:        %10.4e</strong>\n',tot_err_est);
  
% end scriptfile