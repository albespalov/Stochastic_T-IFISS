function [a] = stoch_goafem_specific_coeff(x,y,nel,norv,KL_DATA)
%STOCH_GOAFEM_EMN_COEFF synthetic stochastic diffusion coefficient
%
% [a] = stoch_goafem_specific_coeff(x,y,nel,norv,KL_DATA)
% 
% input:
%          x    x coordinate vector
%          y    y coordinate vector
%        nel    number of elements
%       norv    number of random variables
%    KL_DATA    data related to KL-expansion
%
% output:
%          a    synthetic stochastic diffusion coefficient
%
% This random field is discussed in:
% Eigel, Merdon, Neumann, An adaptive multilevel Monte Carlo method with
% stochastic bounda for quantities of interest with uncertain data, 
% SIAM/ASA J. Uncertain. Comput. 4(1)1219-1245, 2016.
%
% See also STOCH_GOAFEM_EMN_GRADCOEFF
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
  
% Load constant parameters for the field  
  load('const_emn_field.mat','eps','cc','A');
  
% Initialisation
  a = zeros(nel,norv+1);
  
% Set a_0
  a(:,1) = (cc + eps) * ones(nel,1);

% Set decay rate of stochastic coefficients
  sdecay = KL_DATA.decay;
  if sdecay == 1, sigma=2; end
  
% Compute alphamin = A * zeta(2) 
  alphamin = A * (pi^2/6);

% Set a_m
  for m = 1:norv
      km       = floor(-0.5e0 + sqrt(0.25e0 + 2*m));
      beta1    = m - km*(km+1)/2; 
      beta2    = km - beta1;
      a(:,m+1) = A * (m^(-sigma)) * cos(2*pi*beta1*x) .* cos(2*pi*beta2*y);
      a(:,m+1) = a(:,m+1) * cc / alphamin;
  end
 
end % end function