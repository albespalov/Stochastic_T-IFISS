function [dadx,dady] = stoch_goafem_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%STOCH_GOAFEM_EMN_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%
% [dadx,dady] = stoch_goafem_specific_gradcoeff(x,y,nel,norv,KL_DATA)
% 
% input:
%            x     x coordinate vector
%            y     y coordinate vector 
%          nel     number of elements  
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion (6-fields structure or zero)
%
% output:
%  [dadx,dady]     derivatives (gradient) of the stochastic coefficient
%
% This random field is discussed in:
% Eigel, Merdon, Neumann, An adaptive multilevel Monte Carlo method with
% stochastic bounda for quantities of interest with uncertain data, 
% SIAM/ASA J. Uncertain. Comput. 4(1)1219-1245, 2016.
%
% See also STOCH_GOAFEM_EMN_COEFF
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
  
% Load constant parameters for the field  
  load('const_emn_field.mat','eps','cc','A');
  
% Initialisation
  dadx = zeros(nel,norv+1);
  dady = zeros(nel,norv+1);

% Set da_0/dx and da_0/dy
  dadx(:,1) = zeros(nel,1);
  dady(:,1) = zeros(nel,1);

% Set decay rate of stochastic coefficients
  sdecay = KL_DATA.decay;
  if sdecay == 1, sigma = 2; end

% Compute alphamin = A * zeta(2) 
  alphamin = A * (pi^2/6);
  
% Set da_m/dx and da_m/dy
  for m = 1:norv
      km          = floor(-0.5e0 + sqrt(0.25e0 + 2*m));
      beta1       = m - km*(km+1)/2; 
      beta2       = km - beta1;
      dadx(:,m+1) = - (2*pi*beta1) * A * (m^(-sigma)) * sin(2*pi*beta1 * x) .* cos(2*pi*beta2 * y);
      dady(:,m+1) = - (2*pi*beta2) * A * (m^(-sigma)) * cos(2*pi*beta1 * x) .* sin(2*pi*beta2 * y);
      %
      dadx(:,m+1) = dadx(:,m+1) * cc / alphamin;
      dady(:,m+1) = dady(:,m+1) * cc / alphamin;
  end
  
end % end function