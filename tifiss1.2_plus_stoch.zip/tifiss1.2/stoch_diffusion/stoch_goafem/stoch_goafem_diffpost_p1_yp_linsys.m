function [yp_elerr_primal, yp_ederr_primal, yp_errest_primal, ...
          yp_elerr_dual,   yp_ederr_dual,   yp_errest_dual] = ...
          stoch_goafem_diffpost_p1_yp_linsys(xy,evt,eboundt,evtY,xyY,boundY,Ybasis,...
                                    xgal,zgal,G,P,norv,noarv,KL_DATA,subdivPar)
%STOCH_GOAFEM_DIFFPOST_P1_YP_LINSYS computes hierarchical YP-estimate solving the (fully) assembled error problems
%
% [yp_elerr_primal, yp_ederr_primal, yp_errest_primal, ...
%  yp_elerr_dual,   yp_ederr_dual,   yp_errest_dual] = ...
%  stoch_goafem_diffpost_p1_yp_linsys(xy,evt,eboundt,evtY,xyY,boundY,Ybasis,...
%                                 xgal,zgal,G,P,norv,noarv,KL_DATA,subdivPar)
%
% input:
%                xy     vertex coordinate vector  
%               evt     element mapping matrix
%           eboundt     element edge boundary matrix
%              evtY     element mapping matrix for midpoints
%               xyY     vertex coordinate vector for midpoints
%              xgal     stochastic primal P1 solution vector
%              zgal     stochastic dual P1 solution vector
%                 G     (1 x (noarv+1)) cell of G-matrices
%                 P     length of the index set
%              norv     number of random variables
%             noarv     number of active random variables
%           KL_DATA     data related to KL-expansion
%         subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%   yp_elerr_primal     vector of YP element indicators (primal)
%   yp_ederr_primal     vector of YP edge indicators    (primal)
%  yp_errest_primal     global YP error estimate        (primal)
%     yp_elerr_dual     vector of YP element indicators (dual)
%     yp_ederr_dual     vector of YP edge indicators    (dual)
%    yp_errest_dual     global YP error estimate        (dual)
%
% V_{YP}-estimator: employs elementwise P1-bubbles for the edge midpoints 
% (for both red and bisec3 uniform sub-division) tensorised with the 
% original set of polynomials.
%
% The function solves the discrete problems for the eYP estimators:
%
%   B0(eYP,v) = F(v) - B(uXP,v),     for all v \in VYP,        (1)
%   B0(eYP,v) = G(v) - B(zXP,v),     for all v \in VYP.        (2)
%
% Recall that the source F(v) (resp. G(v)) of (1) (resp. of (2)) follows the 
% representation of [MS09] (and [FPZ16]); see also STOCH_GOAFEM_FEMP1_SETUP.
%
% NOTE that given the midpoint-solutions (edge solutions) to problem (1)
% (resp. (2)) per each node
% - the midpoint indicators (edge indicators) are computed by square 
%   summation; see below;
% - the element indicators are computed by definition of local B0-norms
%   restricted to single elements.
%
% References:
%
% [MS09] Mommer, Stevenson, A goal-oriented finite element method with
% convergence rates, SIAM J. Numer. Anal., 47(2)861-866, 2009;
%
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016;
%
% Function(s) called: stoch_goafem_diffpost_p1_yp_detcontrib
%                     stoch_goafem_specific_bc
%                      
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);      % Number of vertices  (i.e., number of X-basis functions) 
  nyb  = size(Ybasis,1);  % Number of midpoints (i.e., number of Y-basis functions (boudary ones included))
  
% -----------------------------------------------------------------------------                 
% STEP 1: elementwise contributions from uniform red/bisec3 refinement type
% -----------------------------------------------------------------------------                 
  [ade,bde,~,fde,gde] = stoch_goafem_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar);

% -----------------------------------------------------------------------------
% STEP2: assembling non-parametric LHS matrix (the same for both (1) and (2))
% -----------------------------------------------------------------------------
  A = sparse(nyb,nyb);
  for i = 1:3
      % Indices for Y-basis
      idxY1 = evtY(:,i);	 
      for j = 1:3
          % Indices for Y-basis
          idxY2 = evtY(:,j);
          % Assembling
          A = A + sparse(idxY1, idxY2, ade(:,i,j), nyb, nyb);
      end
  end
     
% -----------------------------------------------------------------------------                       
% STEP 3: assembling F(v) and G(v) for all basis \phi_j*P_\nu in V_YP
% -----------------------------------------------------------------------------
% Extract elements and associated edges for Y-basis functions
  elems = Ybasis(:,[1,2]);   
  edges = Ybasis(:,[3,4]);
  
% Indices: elements, Y-basis, ones.
% Note the last indices are 'ones' as we need only fde(:,:,1) (resp. gde(:,:,1))
% since sources are deterministic 
  idx1 = {elems(:,1), edges(:,1), ones(size(elems,1),1)}; 
  idx2 = {elems(:,2), edges(:,2), ones(size(elems,1),1)};

% Summing deterministic contributions (primal problem) 
  ff = fde( sub2ind(size(fde) , idx1{:}) ) + fde( sub2ind(size(fde) , idx2{:}) );
% For a Y-basis on the boundary, we have to halve the contributions since in the 
% above line we doubled the contribution coming from the only boundary element
  ff(boundY) = ff(boundY) ./ 2;
  
% Summing deterministic contributions (dual problem)  
  gg = gde( sub2ind(size(gde) , idx1{:}) ) + gde( sub2ind(size(gde) , idx2{:}) );
% For a Y-basis on the boundary, we have to halve the contributions since in the 
% above line we doubled the contribution coming from the only boundary element
  gg(boundY) = gg(boundY) ./ 2;  
  
% Since sources are deterministic, F(v) = kron(g0,ff) = (ff,0,0,...)', where 
% g0 is the first column of the matrix G0, i.e., g0 = (1,0,0,...)'. 
% The same for the dual (error) problem.

% Keep F(v) in a nyb-by-P matrix  
  Fv = [ff, sparse(nyb,P-1)];

% Keep G(v) in a nyb-by-P matrix  
  Gv = [gg, sparse(nyb,P-1)];

% -----------------------------------------------------------------------------                                
% STEP 4: assembling B(uXP,v) and B(zXP,v) for all basis \phi_j*P_\nu in V_YP
% -----------------------------------------------------------------------------
% The terms B(uXP,v) and B(zXP,v) will be nyb-by-P vectors 

% Reshape xgal and zgal vector solutions in matrix form for efficient kronecker products 
  X = reshape(xgal,nvtx,P);
  Z = reshape(zgal,nvtx,P);  

% Matrix Bx and Bz for assembling B(uXP,v) and B(zXP,v), for each v in V_YP
  Bx = sparse(nyb,P);
  Bz = sparse(nyb,P);   
                    
% Loop over random variables
  for m = 0:noarv
      
      % Allocate memory for current noarv
      Km = sparse(nyb,nvtx);

      % Assembling deterministic matrix
      for kYb = 1:3
          % Indices for Y-basis
          indY = evtY(:,kYb);	 
          for kXb = 1:3
              % Indices for X-basis
              indX = evt(:,kXb);
              % Assembling
              Km = Km + sparse(indY, indX, bde(:, kYb, kXb, m+1), nyb, nvtx);
          end
      end
 
      % NOTE that if the problem has homogeneous bcs, then such conditions 
      % for the corresponding X-basis on the boundary should be imposed, 
      % i.e, Km(:,bound) = 0. However, this is unnecessary as Km will be
      % multiplied by X which already contains zeros in X-boundary positions.
      %
      % The global Kronecker matrix
      %
      %         [ kron(G{0},K{m}) + sum_m^M kron(G{m},K{m}) ] * x_gal
      %
      % is assembled by summing its component matrix contributions
      %
      %                kron(G{m},K{m}) * x_gal
      %
      % for the current value of m \geq 0. 
      % Efficient assembling avoiding 'kron' for the matrix kron(G{m},K{m}) 
      % saving both memory and time; note that there should be G' but the 
      % G-matrices are symmetric;
      
      % Primal(error) problem
      Bx = Bx + ( Km * X * G{m+1} );
      
      % Dual (error) problem
      Bz = Bz + ( Km * Z * G{m+1} );     
  end        
  
% Global rhs for primal (error) problem: F(v) - B(uXP,v)
  rhs_primal = Fv - Bx;
  
% Global rhs for dual (error) problem: G(v) - B(zXP,v)
  rhs_dual = Gv - Bz;
  
% -----------------------------------------------------------------------------  
% STEP 5: imposing interpolated error as Dirichlet boundary conditions 
% -----------------------------------------------------------------------------                                
  [rhs_primal,rhs_dual] = diffpost_nonzerobc(evt,evtY,xy,xyY,boundY,eboundt,A,rhs_primal,rhs_dual,P,norv);

% -----------------------------------------------------------------------------
% STEP 6: solving the assembled system (for interior nodes)
% -----------------------------------------------------------------------------
% The final ey_edsol_primal/dual contains the error-solution at each midpoint.
  yp_edsol_primal = zeros(nyb,P);
  yp_edsol_dual   = zeros(nyb,P);

% Set of interior midpoints 
  interiorY = 1:boundY(1)-1;
   
% Solving the linear systems for interior positions (primal and dual);
% NOTE that there should be G{1}', but G-matrices are symmetric;
% NOTE that there should be A' in the dual system, but A is symmetric;
  yp_edsol_primal(interiorY,:) = A(interiorY,interiorY) \ rhs_primal(interiorY,:) / G{1};
  yp_edsol_dual(interiorY,:)   = A(interiorY,interiorY) \ rhs_dual(interiorY,:)   / G{1};

% Update the error values in boundary-midpoints position (primal and dual)
  yp_edsol_primal(boundY,:) = rhs_primal(boundY,:);
  yp_edsol_dual(boundY,:)   = rhs_dual(boundY,:); 

% -----------------------------------------------------------------------------  
% STEP 7: computing the edge-indicators (midpoint-indicators)
% -----------------------------------------------------------------------------
  yp_ederr_primal = sqrt( sum( yp_edsol_primal.^2, 2) ) ;
  yp_ederr_dual   = sqrt( sum( yp_edsol_dual.^2  , 2) ) ;

% -----------------------------------------------------------------------------
% STEP 8: computing the elementwise estimates from edge-indicators
% -----------------------------------------------------------------------------  
  [yp_elerr_primal] = get_yp_errelem(ade,evtY,yp_edsol_primal,P);
  [yp_elerr_dual]   = get_yp_errelem(ade,evtY,yp_edsol_dual,P);  
  
% -----------------------------------------------------------------------------
% STEP 9: global estimates ||yperr||_B0^2 = B0(yperr,yperr) (primal and dual)
% -----------------------------------------------------------------------------
% Primal error problem
  sol_primal = reshape(yp_edsol_primal, nyb*P, 1);
  ff_primal  = reshape(rhs_primal,      nyb*P, 1);
  yp_errest_sq_primal = sol_primal' * ff_primal;
%
% Dual error problem
  sol_dual = reshape(yp_edsol_dual, nyb*P, 1);
  gg_dual  = reshape(rhs_dual,      nyb*P, 1);
  yp_errest_sq_dual = sol_dual' * gg_dual;
  
% Compute the global estimates ||yperr||_B0 = B0(yperr,yperr)^(1/2) (primal and dual)
  yp_errest_primal = full( sqrt( yp_errest_sq_primal ) );
  yp_errest_dual   = full( sqrt( yp_errest_sq_dual ) );

end  % end function


% -----------------------------------------------------------------------------  
% Child function
% -----------------------------------------------------------------------------     
function [rhs_primal,rhs_dual] = diffpost_nonzerobc(evt,evtY,xy,xyY,boundY,eboundt,K,rhs_primal,rhs_dual,P,norv)
%Imposes Dirichlet boundary conditions on boundary midpoints
  
  interiorY = 1:boundY(1)-1;

% -----------------------------------------------------------------------------
% Extract boundary elements with boundary edges respectively = 1, 2, and 3
% ----------------------------------------------------------------------------- 
  beled1 = eboundt( eboundt(:,2)==1 , 1);
  beled2 = eboundt( eboundt(:,2)==2 , 1);
  beled3 = eboundt( eboundt(:,2)==3 , 1);
   
% -----------------------------------------------------------------------------
% Extract boundary nodes/midpoints and compute the error
% -----------------------------------------------------------------------------
  node1    = evt ( beled1, [2 3]);   % nodes of the 1st boundary edges (columns 2,3 of evt)
  midp1    = evtY( beled1, 1);       % midpoints on 1st boundary edges (column 1 of evtY)
  [error1] = stoch_interperror_bc(xy,xyY,node1,midp1,norv);
  
  node2    = evt ( beled2, [3 1]);   % nodes of the 2nd boundary edges (columns 3,1 of evt)
  midp2    = evtY( beled2, 2);       % midpoints on 2nd boundary edges (column 2 of evtY)
  [error2] = stoch_interperror_bc(xy,xyY,node2,midp2,norv);
  
  node3    = evt ( beled3, [1 2]);   % nodes of the 3rd boundary edges (columns 1,2 of evt)
  midp3    = evtY( beled3, 3);       % midpoints on 3rd boundary edges (column 3 of evtY)
  [error3] = stoch_interperror_bc(xy,xyY,node3,midp3,norv);
  
% -----------------------------------------------------------------------------
% Vector of interpolated error on boundary midpoints
% -----------------------------------------------------------------------------
  miderrors = sortrows([midp1, error1; midp2, error2; midp3, error3],1);
  detbcY = miderrors(:,2);
  bcY    = [detbcY, zeros(length(detbcY),P-1)];
% Note that we add column of zeros (as bc are non parametric) for consistency 

% -----------------------------------------------------------------------------
% Update the rhs in the interior-midpoint positions
% -----------------------------------------------------------------------------
% We have to do the following:
%
%   rhs(interiorY,:) = rhs(interiorY,:) - kron(G{1},K(interiorY,boundY)) * bcY;
%
% Avoid the assembling of the kron matrix, saving both memory and time: 
% look at Nagy's lecture for efficient kronecker products in this case;
  rhs_primal(interiorY,:) = rhs_primal(interiorY,:) - ( K(interiorY,boundY) * bcY * eye(P) );
  rhs_dual(interiorY,:)   = rhs_dual(interiorY,:)   - ( K(interiorY,boundY) * bcY * eye(P) );
% NOTE that this update for both RHS in interior positions is a nIntY-by-P matrix  

% Update the rhs values in boundary-midpoints position with the imposed error
  rhs_primal(boundY,:) = bcY; 
  rhs_dual(boundY,:)   = bcY;

end % end child function
 

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [error] = stoch_interperror_bc(xy,xyY,bnodesX,bnodeY,norv)
% Impose the error values on boundary midpoints

% Coordinates of the boundary nodes and of boundary edge's midpoints
  allxbd_X = reshape( xy(bnodesX,1), size(bnodesX,1), 2);
  allybd_X = reshape( xy(bnodesX,2), size(bnodesX,1), 2);
  xybd_Y   = xyY(bnodeY, :);
  
% Compute boundary conditions for the given nodes
  [bc_firstNodeX]  = stoch_goafem_specific_bc(allxbd_X(:,1), allybd_X(:,1), norv);
  [bc_secondNodeX] = stoch_goafem_specific_bc(allxbd_X(:,2), allybd_X(:,2), norv);
  [bc_nodeY]       = stoch_goafem_specific_bc(xybd_Y(:,1),   xybd_Y(:,2),   norv);

% Extract the first "non-parametric" column (in case the b.c. are
% non-parametric, i.e., columns from 2 to norv+1 are zeros)
  bc_firstNodeX  = bc_firstNodeX(:,1);  
  bc_secondNodeX = bc_secondNodeX(:,1); 
  bc_nodeY       = bc_nodeY(:,1);

% Interpolated error
  error = bc_nodeY - 0.5 * (bc_firstNodeX + bc_secondNodeX);
  
end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [yp_elerr] = get_yp_errelem(ade,evtY,yp_edgevec,P)
%Recovers elementwise B_0^2 energy norms
  
  nel      = size(evtY,1); % Number of elements
  errloc   = zeros(nel,3);
  elerr_sq = zeros(nel,1);
  
% Loop over modes  
  for mu = 1:P   
      % Rearranging eYP nodal values elementwise
      for imid = 1:3
          errloc(:,imid) = yp_edgevec(evtY(:,imid),mu);
      end 
      % Computing elementwise B_0^2 energy norms
      for imid = 1:3          
          for jmid = 1:3
              elerr_sq(:) = elerr_sq(:) + errloc(:,imid) .* ade(:,imid,jmid) .* errloc(:,jmid);
          end  
      end 
  end
  
% B0 energy norms
  yp_elerr = sqrt( elerr_sq );
    
end % end child function 