function [f1,f2] = stoch_goafem_specific_H1rhs(x,y,nel,norv)
%STOCH_GOAFEM_ZERO_H1RHS zero deterministic H1 part of the RHS of the primal problem 
%
% [f1,f2] = stoch_goafem_specific_H1rhs(x,y,nel,norv)
%
% input:
%          x    x coordinate vector
%          y    y coordinate vector
%        nel    number of elements
%       norv    number of random variables
%
% The function computes the source vector \vec{f}=[f1,f2], with f1=f2=0, 
% in the RHS F(v) of the primal problem; see STOCH_GOAFEM_FEMP1_SETUP.
%
% See also STOCH_GOAFEM_ZERO_H1GOAL
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  f1 = zeros(nel,norv+1);
  f2 = zeros(nel,norv+1);

end % end function