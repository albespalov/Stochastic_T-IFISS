function [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
%STOCH_GOAFEM_PO99_L2GOAL Prudhomme-Oden mollifier L2 part of RHS of the dual problem
%   
% [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
%
% input:
%        x    x coordinate vector
%        y    y coordinate vector
%      nel    number of elements
%     norv    number of random variables
%
% output: 
%        g    Prudhomme-Oden mollifier 
%
% The function computes the deterministic L2 part g0(x) of RHS G(v) of the dual 
% problem (see also STOCH_GOAFEM_FEMP1_SETUP) defined as the "mollifier" as 
% given in:
% [PO99] Prudhomme, Oden, On goal-oriented error estimation for elliptic 
% problems: application to the control of pointwise errors, Comput.
% Methods. Appl. Mech. Engrg. 176(1-4):313-331, 1999.
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
   
% Load constant parameters for pointwise estimation 
  load constmollifier_po99.mat;
   
  g_det = zeros(nel,1);
   
  for i = 1:length(x)
      % Support of the Ball B((x0,y0);r)
      dp = sqrt( (x0 - x(i))^2 + (y0 - y(i))^2 );
      if dp < r
          g_det(i) = C * exp( -r^2 / (r^2 - dp^2) ); 
      end
  end 
  
  g = [g_det,zeros(nel,norv)];

end % end function