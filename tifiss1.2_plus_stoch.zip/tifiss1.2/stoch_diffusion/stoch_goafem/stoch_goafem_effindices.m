function [effindices] = stoch_goafem_effindices(errors,Gul,Guref,varargin)
%STOCH_GOAFEM_EFFINDICES computes the effectivity indices given a reference goal-functional
%
% [effindices] = stoch_goafem_effindices(errors,Gul,Guref,varargin)
%
% input: 
%          errors   vector of (product) error estimates \mu_\ell\zeta_\ell
%             Gul   vector of computed goal-functionals G(u_\ell)
%           Guref   computed reference goal-function G(u_\ref)
%           iplot   (optional) plot switch for the effectivity indices 0/1
%
% output:
%      effindices   vector of computed effectivity indices
%
% The effectivity indices are calculated via the formula:
%   effindices = errors / |Guref - Gul| 
%
%   TIFISS function: AB; 11 February 2019
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  if nargin == 4
      iplot = varargin{1};
  else%if nargin < 4
      iplot = 0;
      if nargin < 3 
          error('Missing reference goal-functional!');
      end
  end
     
% -----------------------------------------------------------------------------  
% Effectivity indices  
% -----------------------------------------------------------------------------  
  truegerr   = abs( repmat(Guref,1,length(Gul)) - Gul ); % |G(uref) - G(u_\ell)|
  effindices = errors ./ truegerr;                       % prod-est / |G(uref) - G(u_\ell)|

% -----------------------------------------------------------------------------  
% Plot
% -----------------------------------------------------------------------------  
  if iplot == 1     
      fontSizeAxes = 14;
      iter = length(errors);
      figure;
      semilogy(1:iter,effindices(1:iter),'-bo','Linewidth',1.5,'MarkerSize',10);
      hold on; grid on;
      axis([1 iter min(effindices) max(effindices)]);
      xlabel('iteration','FontSize',fontSizeAxes);
      ylabel('effectivity index','FontSize',fontSizeAxes);
      % Setup axis and window's dimension and position 
      set(gca,'YMinorTick','on','YTickMode','manual','YMinorGrid','off',...
              'GridLineStyle','--','FontSize',fontSizeAxes);      
      set(gcf,'units','normalized','Position',[0.25 0.2 0.55 0.65]);
  end
  
end % end function