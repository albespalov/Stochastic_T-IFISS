function [divf] = stoch_goafem_gauss_divH1(s,t,xl,yl,norv,problem)
%STOCH_GOAFEM_GAUSS_DIVH1 evaluates the divergence of the H1 part of the RHSs at Gauss point 
%
% [divf] = stoch_goafem_gauss_divH1(s,t,xl,yl,norv,problem)
%  
% input:
%            s     reference element x coordinate
%            t     reference element y coordinate
%           xl     physical element x vertex coordinates
%           yl     physical element y vertex coordinates
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion
%      problem     1 for primal problem, 2 for dual problem
%
% output:
%         divf     divergence of the source vector of the RHS (primal)
%
% Function(s) called: stoch_goafem_specific_divH1rhs
%                     stoch_goafem_specific_divH1goal
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel         = length(xl(:,1));
  zero_v      = zeros(nel,1);
  xx          = zero_v;
  yy          = xx;
  [phi_e,~,~] = tshape(s,t);

  for ivtx=1:3 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  
  if problem == 1
      % Primal problem
      divf = stoch_goafem_specific_divH1rhs(xx,yy,nel,norv);
  elseif problem == 2
      % Dual problem
      divf = stoch_goafem_specific_divH1goal(xx,yy,nel,norv);
  end

end % end function