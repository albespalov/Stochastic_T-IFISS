function [K,fgal,ggal,x_gal,z_gal,dupl_intern] = stoch_goafem_imposebcx(Knbc,fnbc,gnbc,G,xy,bound,indset,P,norv,noarv)
%STOCH_GOAFEM_IMPOSEBCX imposes Dirichlet boundary conditions for both primal and dual problems
%
% [K,fgal,ggal,x_gal,z_gal,dupl_intern] = stoch_goafem_imposebcx(Knbc,fnbc,gnbc,...
%                                         G,xy,bound,indset,P,norv,noarv)
%
% input:
%               Knbc    input cell structure (before bc's imposed)
%               fnbc    input rhs vector primal
%               gnbc    input rhs vector dual
%                  G    a 1-by-(norv+1) cell of G-matrices
%                 xy    vertex coordinate vector
%              bound    boundary vertex vector
%             indset    index set of polynomial degrees
%                  P    length of the index set
%               norv    number of random variables
%              noarv    number of active random variables
%
% output:
%                  K    output cell structure (with bc's imposed)
%               fgal    output rhs vector primal
%               ggal    output rhs vector dual
%              x_gal    template solution vector primal (with bc's imposed)
%              z_gal    template solution vector dual (with bc's imposed)
%        dupl_intern    boundary condition interior dof map
%
% Function(s) called:   stoch_rhs_multipliers
%                       stoch_goafem_specific_bc
%
% NOTE: this function is based on the original SIFISS function
% (DJS; 27 July 2015, STOCH_IMPOSEBC). Differences are as follows:
% - G-matrices amongst the input;
% - computation limited to active random variables noarv (instead of norv);
% - avoiding multiplication by 2^noarv;
% - efficient computation of the new rhs avoids kron products saving both 
%   memory and time;
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
  
  nvtx = length(xy);      % Number of total vertices
  nbd  = length(bound);   % Number of boundary vertices

% -----------------------------------------------------------------------------
% Checking dimensions of deterministic matrices (= noarv+1)
% -----------------------------------------------------------------------------
  dimk = length(Knbc); 
  if ~isequal(dimk,noarv+1)  %dimk ~= norv+1, 
      error('Incompatible cell dimensions!');
  end
  [nK,~] = size(Knbc{1});
  if ~isequal(nK,nvtx)       %nK ~= nvtx
      error('Incompatible dimensions');
  end
  
% Preallocate memory  
  x_gal      = zeros(length(fnbc),1);   %zeros(nvtx*P,1);
  z_gal      = zeros(length(gnbc),1);   %zeros(nvtx*P,1);
  dupl_bound = zeros(nbd*P,1);
  bc_primal  = zeros(nbd*P,1);
  bc_dual    = zeros(nbd*P,1);

% Single internal nodes vector (i.e, per a single mode)
  nodes = (1:nvtx)';
  intern = nodes(~ismember(nodes,bound));
   
% Global internal nodes vector (per 1st node, per 2nd node...)
  dupl_nodes = 1:length(fnbc);  
  for k = 1:P
      l = nvtx*(k-1)*ones(nbd,1);
      dupl_bound((k-1)*nbd+1:k*nbd) = l + bound;
  end
  dupl_intern = dupl_nodes(~ismember(dupl_nodes,dupl_bound));
     
% Update the rhs  
  fgal = fnbc(dupl_intern);
  ggal = gnbc(dupl_intern);
  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);

% -----------------------------------------------------------------------------
% Set boundary conditions
% -----------------------------------------------------------------------------
  xbd = xy(bound,1);
  ybd = xy(bound,2);
  % Primal problem
  [temp_bc_primal] = stoch_goafem_specific_bc(xbd,ybd,norv);
  for m = 0:noarv  %norv
      ind_m = rhs_ind(1,m+1);
      if ind_m > 0
         bc_primal((1+nbd*(ind_m-1)):(nbd*ind_m)) = temp_bc_primal(:,m+1) * beta(1,m+1); 
      end
  end
  detbc_primal = bc_primal(1:nbd);

  % Dual problem
  [temp_bc_dual] = stoch_goafem_specific_bc(xbd,ybd,norv);
  for m = 0:noarv  %norv
      ind_m = rhs_ind(1,m+1);
      if ind_m > 0
         bc_dual((1+nbd*(ind_m-1)):(nbd*ind_m)) = temp_bc_dual(:,m+1) * beta(1,m+1); 
      end
  end
  detbc_dual = bc_dual(1:nbd);
  
% Construct output structure
  K = cell(1,noarv+1);   %norv+1);
   
% -----------------------------------------------------------------------------  
% Assembling the new rhs
% -----------------------------------------------------------------------------
  for dim = 1:dimk
      Kk = Knbc{dim}; 
      Gk = G{dim}; 
      gk = Gk(:,1); 
      % This is what we have to do:
      % fgal = fgal - kron( gk, Kk(intern,bound) ) * detbc;
      % Avoid the assembling of the kron matrix, saving both memory and
      % time: look at Nagy's lecture for efficient kronecker products
      [m,n] = size( gk );
      [p,q] = size( Kk(intern,bound) );
      fgal = fgal - reshape( (Kk(intern,bound) * reshape(detbc_primal,q,n) * gk'), m*p, 1);
      ggal = ggal - reshape( (Kk(intern,bound) * reshape(detbc_dual,q,n)   * gk'), m*p, 1);
      % Save new K matrix
      K{dim} = Kk(intern,intern);
  end

% Update the Galerkin solution  
  x_gal(dupl_bound) = bc_primal;
  z_gal(dupl_bound) = bc_dual;

end % end function