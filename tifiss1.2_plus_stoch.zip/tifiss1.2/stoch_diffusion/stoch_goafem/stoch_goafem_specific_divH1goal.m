function [divg] = stoch_goafem_specific_divH1goal(x,y,nel,norv)
%STOCH_GOAFEM_ZERO_DIVH1GOAL zero deterministic divergence of H1 part of RHS of the dual problem
%
% [divg] = stoch_goafem_specific_divH1goal(x,y,nel,norv)
%   
% input:
%        x   x coordinate vector
%        y   y coordinate vector
%      nel   number of elements
%     norv   number of random variables
%
% output: 
%     divg   divergence of source vector of the RHS (dual)
%
% The function returns the divergence of the source vector \vec{g} of the RHS 
% of the dual problem; see also STOCH_GOAFEM_SPECIFIC_H1GOAL.
%
% See also STOCH_GOAFEM_ZERO_DIVH1RHS
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  divg = [zeros(nel,1),zeros(nel,norv)]; 

end % end function