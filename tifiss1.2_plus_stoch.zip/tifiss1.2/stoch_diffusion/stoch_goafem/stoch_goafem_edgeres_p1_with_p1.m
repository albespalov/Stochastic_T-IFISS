function [edgeres_primal, edgeres_dual] = stoch_goafem_edgeres_p1_with_p1(xy,evt,eboundt,...
                                          ugal,zgal,eex,tve,els,indset,P,G,norv,noarv,KL_DATA)
%STOCH_GOAFEM_EDGERES_P1_WITH_P1 computes YP edge residuals for both primal and dual solutions
%
% [edgeres_primal, edgeres_dual] = stoch_goafem_edgeres_p1_with_p1(xy,evt,eboundt,...
%                           ugal,zgal,eex,tve,els,indset,P,G,norv,noarv,KL_DATA)
%
% input:
%                xy   vertex coordinate vector
%               evt   element mapping matrix
%           eboundt   element edge boundary matrix
%              ugal   stochastic P1 primal solution vector
%              zgal   stochastic P1 dual solution vector
%               eex   element connectivity array
%               tve   edge location array
%               els   elementwise edge lengths
%                 P   length of the index set
%                 G   (1 x (noarv+1)) cell of G-matrices
%              norv   number of random variables
%             noarv   number of active random variables
%           KL_DATA   data related to KL-expansion
%
% output:
%    edgeres_primal   edge residuals (primal problem)
%      edgeres_dual   edge residuals (dual problem)
%
% The function computes the 'edge' residuals of local residual problems. 
% For the primal solution this is given by
% 
% edgeres := (1/2)\int_Gamma\int_{\partial K}(Jump(\vec{f}) + a(s,y)Jump(ugal))v(s,y) dsdpiy
%
% For the dual solution, in the expression above there would be \vec{g} and ugal, 
% respectively.
%
% Function(s) called: gausspoints_oned
%                     tderiv
%                     stoch_goafem_gauss_coeff
%                     stoch_goafem_p1fluxjmps
%                     stoch_goafem_jump_H1
%                     stoch_rhs_multipliers
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);   % Number of vertices
  nel  = size(evt,1);  % Number of elements
    
% Construct the integration rule (1/2/3/4/7/10 Gaussian points)
  ngpt = 10;
  [oneg,onew] = gausspoints_oned(ngpt);

% Allocate memory
  detresol_primal = zeros(nel,3,P,noarv+1);  
  edgeres_primal  = zeros(nel,3*P);
  detresol_dual   = zeros(nel,3,P,noarv+1);
  edgeres_dual    = zeros(nel,3*P);
  
% Recover local coordinates
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2); 
  end
  
% Recover first the 3 external normals of each element
  [nx,ny] = get_normals(xl_v,yl_v,els);  
  
% -----------------------------------------------------------------------------  
% (Deterministic) edge residual due to Galerkin solutions
% -----------------------------------------------------------------------------  
  for igpt = 1:ngpt     
      sigpt = oneg(igpt);
      sigpt_ref_edge = (1.0 + sigpt)/2.0; % [-1,1] -> [0,1]    reference-edge map
      sigpt_l = (1.0 + sigpt)/4.0;        % [-1,1] -> [0,1/2]  LEFT sub-edge map
      sigpt_r = (3.0 + sigpt)/4.0;        % [-1,1] -> [1/2,1]  RIGHT sub-edge map
      wigpt = onew(igpt);
      %
      % First edge
      [~,~,phi_v_1,~,~] = tderiv(sigpt_ref_edge,1-sigpt_ref_edge,xl_v,yl_v);
      [coeff_l_1] = stoch_goafem_gauss_coeff(sigpt_l,1-sigpt_l,xl_v,yl_v,norv,KL_DATA);
      [coeff_r_1] = stoch_goafem_gauss_coeff(sigpt_r,1-sigpt_r,xl_v,yl_v,norv,KL_DATA);
      %      
      % Second edge
      [~,~,phi_v_2,~,~] = tderiv(0,sigpt_ref_edge,xl_v,yl_v);
      [coeff_l_2] = stoch_goafem_gauss_coeff(0,sigpt_l,xl_v,yl_v,norv,KL_DATA);
      [coeff_r_2] = stoch_goafem_gauss_coeff(0,sigpt_r,xl_v,yl_v,norv,KL_DATA);
      %
      % Third edge
      [~,~,phi_v_3,~,~] = tderiv(sigpt_ref_edge,0,xl_v,yl_v);
      [coeff_l_3] = stoch_goafem_gauss_coeff(sigpt_l,0,xl_v,yl_v,norv,KL_DATA);
      [coeff_r_3] = stoch_goafem_gauss_coeff(sigpt_r,0,xl_v,yl_v,norv,KL_DATA);
       
      % Loop over indices in the index set
      for k = 1:P   
          %
          % Galerkin solution's jumps over the LEFT sub-element edges (primal and dual)
          [njmp_l_primal] = stoch_goafem_p1fluxjmps(xl_v,yl_v,ugal((k-1)*nvtx+1:k*nvtx),nx,ny,eboundt,evt,eex,tve,sigpt_l);    
          [njmp_l_dual]   = stoch_goafem_p1fluxjmps(xl_v,yl_v,zgal((k-1)*nvtx+1:k*nvtx),nx,ny,eboundt,evt,eex,tve,sigpt_l);    
          %
          % Galerkin solution's jumps over the RIGHT sub-element edges (primal and dual)
          [njmp_r_primal] = stoch_goafem_p1fluxjmps(xl_v,yl_v,ugal((k-1)*nvtx+1:k*nvtx),nx,ny,eboundt,evt,eex,tve,sigpt_r);
          [njmp_r_dual]   = stoch_goafem_p1fluxjmps(xl_v,yl_v,zgal((k-1)*nvtx+1:k*nvtx),nx,ny,eboundt,evt,eex,tve,sigpt_r);
          %
          % Loop over stochastic variables
          for m = 0:noarv                      
              % Contribution from the FIRST edge (primal and dual)
              detresol_primal(:,1,k,m+1) = detresol_primal(:,1,k,m+1) + (1/2) * wigpt * coeff_l_1(:,m+1) .* njmp_l_primal(:,1) .* phi_v_1(:,2) .* (els(:,1)/4);
              detresol_primal(:,1,k,m+1) = detresol_primal(:,1,k,m+1) + (1/2) * wigpt * coeff_r_1(:,m+1) .* njmp_r_primal(:,1) .* phi_v_1(:,3) .* (els(:,1)/4);
              detresol_dual(:,1,k,m+1)   = detresol_dual(:,1,k,m+1)   + (1/2) * wigpt * coeff_l_1(:,m+1) .* njmp_l_dual(:,1)   .* phi_v_1(:,2) .* (els(:,1)/4);
              detresol_dual(:,1,k,m+1)   = detresol_dual(:,1,k,m+1)   + (1/2) * wigpt * coeff_r_1(:,m+1) .* njmp_r_dual(:,1)   .* phi_v_1(:,3) .* (els(:,1)/4);            
              %
              % Contribution from the SECOND edge (primal and dual)
              detresol_primal(:,2,k,m+1) = detresol_primal(:,2,k,m+1) + (1/2) * wigpt * coeff_l_2(:,m+1) .* njmp_l_primal(:,2) .* phi_v_2(:,3) .* (els(:,2)/4);
              detresol_primal(:,2,k,m+1) = detresol_primal(:,2,k,m+1) + (1/2) * wigpt * coeff_r_2(:,m+1) .* njmp_r_primal(:,2) .* phi_v_2(:,1) .* (els(:,2)/4);
              detresol_dual(:,2,k,m+1)   = detresol_dual(:,2,k,m+1)   + (1/2) * wigpt * coeff_l_2(:,m+1) .* njmp_l_dual(:,2)   .* phi_v_2(:,3) .* (els(:,2)/4);
              detresol_dual(:,2,k,m+1)   = detresol_dual(:,2,k,m+1)   + (1/2) * wigpt * coeff_r_2(:,m+1) .* njmp_r_dual(:,2)   .* phi_v_2(:,1) .* (els(:,2)/4);
              %
              % Contribution from the THIRD edge (primal and dual)
              detresol_primal(:,3,k,m+1) = detresol_primal(:,3,k,m+1) + (1/2) * wigpt * coeff_l_3(:,m+1) .* njmp_l_primal(:,3) .* phi_v_3(:,2) .* (els(:,3)/4);
              detresol_primal(:,3,k,m+1) = detresol_primal(:,3,k,m+1) + (1/2) * wigpt * coeff_r_3(:,m+1) .* njmp_r_primal(:,3) .* phi_v_3(:,1) .* (els(:,3)/4);
              detresol_dual(:,3,k,m+1)   = detresol_dual(:,3,k,m+1)   + (1/2) * wigpt * coeff_l_3(:,m+1) .* njmp_l_dual(:,3)   .* phi_v_3(:,2) .* (els(:,3)/4);
              detresol_dual(:,3,k,m+1)   = detresol_dual(:,3,k,m+1)   + (1/2) * wigpt * coeff_r_3(:,m+1) .* njmp_r_dual(:,3)   .* phi_v_3(:,1) .* (els(:,3)/4);
          end
          % end of the loop over stochastic variables
      end
      % end of the loop over indices in the index set
  end
% end of Gauss points loop
  
% Full edge residual vector due to galerkin solutions (primal and dual)
  for m = 0:noarv
      [nzi,nzj,gval] = find(G{m+1});
      for t = 1:length(nzi)
          i = nzi(t);
          j = nzj(t);
          edgeres_primal(:,(3*(j-1)+1):(3*j)) = edgeres_primal(:,(3*(j-1)+1):(3*j)) + gval(t)*detresol_primal(:,1:3,i,m+1);
          edgeres_dual(:,(3*(j-1)+1):(3*j))   = edgeres_dual(:,(3*(j-1)+1):(3*j))   + gval(t)*detresol_dual(:,1:3,i,m+1);
      end
  end
   
% (Deterministic) edge residual due to jumps of source vectors (primal and dual) 
  [detres_fjump] = stoch_goafem_jump_H1(xl_v,yl_v,nx,ny,evt,eboundt,els,eex,tve,norv,noarv,1);
  [detres_gjump] = stoch_goafem_jump_H1(xl_v,yl_v,nx,ny,evt,eboundt,els,eex,tve,norv,noarv,2);

% Full edge residual vector due to jumps of the sources (primal and dual)
%  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);
  for m = 0:noarv   %norv         
      ind_m = rhs_ind(1,m+1);
      if ind_m>0
         edgeres_primal(:,(3*(ind_m-1)+1):(3*ind_m)) = edgeres_primal(:,(3*(ind_m-1)+1):(3*ind_m)) + detres_fjump(:,:,m+1) * beta(1,m+1);
         edgeres_dual(:,(3*(ind_m-1)+1):(3*ind_m))   = edgeres_dual(:,(3*(ind_m-1)+1):(3*ind_m))   + detres_gjump(:,:,m+1) * beta(1,m+1);
      end
  end
  
end % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [nx,ny] = get_normals(xv,yv,els)
%Recover the 3 external unit normals per each element in the mesh: nx and ny
%contain the x-component and the y-component of the normals respectively

  sxe1 = (xv(:,3) - xv(:,2))./els(:,1);  sye1 = (yv(:,3) - yv(:,2))./els(:,1);  % unit tangential components 1st edge
  sxe2 = (xv(:,1) - xv(:,3))./els(:,2);  sye2 = (yv(:,1) - yv(:,3))./els(:,2);  % unit tangential components 2nd edge 
  sxe3 = (xv(:,2) - xv(:,1))./els(:,3);  sye3 = (yv(:,2) - yv(:,1))./els(:,3);  % unit tangential components 3rd edge
	  
  nxe1 = sye1;    nye1 = -sxe1;                                                 % unit normal components 1st edge
  nxe2 = sye2;    nye2 = -sxe2;                                                 % unit normal components 2nd edge
  nxe3 = sye3;    nye3 = -sxe3;                                                 % unit normal components 3rd edge
	  
% Store the x-component and the y-component of the normals
  nx = [nxe1, nxe2, nxe3];   	  
  ny = [nye1, nye2, nye3];
  
end % end child function