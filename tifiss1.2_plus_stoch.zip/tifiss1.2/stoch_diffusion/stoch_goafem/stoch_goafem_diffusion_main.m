%STOCH_GOAFEM_DIFFUSION_MAIN main driver for goal-oriented adaptive SGFEM
%
% Final data are saved to:
% - datafiles/stoch_goafem_adaptive_output (all data from the adaptive loop)
% - datafiles/stoch_goafem_final_mesh_info (info of the last triangulation)
%
%   TIFISS scriptfile: LR; 04 July 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

% Initial parameters  
  stoch_goafem_init_param;
    
% Spatial initialisation of the mesh
  stoch_goafem_init_spatial;

% Parameters distribution and stochastic coefficients initialisation  
  stoch_goafem_init_stoch;
  
% -------------------------------------------------------------------------
% Adaptive Finite Element Loop
% -------------------------------------------------------------------------
  iter = 0;
  endLoopFlag = 0;
  polenr_or_meshref = 0; % Mesh-refinement/parametric-enrichment switch

% Preallocating memory
  stoch_goafem_update_vectors;

  startLoopTime = tic;
  while true
      % Update counter iteration
      iter = iter + 1;
    
      fprintf('\n'); fprintf(num2str(repmat('<strong>-</strong>',1,75))); fprintf('\n');
      fprintf('<strong>Iteration %i\n</strong>',iter);
      fprintf(num2str(repmat('<strong>-</strong>',1,75))); fprintf('\n');
   
      % -------------------------------------------------------
      % Parametric enrichments or spatial refinements
      % -------------------------------------------------------
      if polenr_or_meshref == 1
          % Polynomial enrichment: updating the index set
          % Checking limit on random variables
          [~,Q_noarv] = find(Q_indset(M_ind,:));
          if (max(Q_noarv) + extra_rv) > norv
              fprintf('<strong>Terminated: limit norv is achieved. Tolerance is not met</strong>\n');
              endLoopFlag = 1;
              iter = iter-1;
              break;
          end
          stoch_pol_enrich;
         
      elseif polenr_or_meshref == 2
          % Mesh refinement
          fprintf('\n<strong>Local mesh refinement </strong>');
          meshRefTime = tic;
          [evt,xy,bound,interior,eboundt] = mesh_ref(MMele,MMedge,evt,xy,bound,evtY,xyY,boundY);
          fprintf(' (%.5f sec)\n',toc(meshRefTime));        
      end
           
      % -------------------------------------------------------
      % Setup and solve 
      % -------------------------------------------------------
      stoch_goafem_setup_and_solve;
        
      % -------------------------------------------------------
      % A posteriori error estimation
      % -------------------------------------------------------
      stoch_goafem_diffpost;
     
      % -------------------------------------------------------
      % Marking step:
      % -------------------------------------------------------
      stoch_goafem_marking;  
      
      % Update vectors
      stoch_goafem_update_vectors;
      
      % -------------------------------------------------------
      % Checking tolerance and number of iterations
      % -------------------------------------------------------
      if tot_err_est <= err_tol
          % Tolerance reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Tolerance reached!</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
      elseif isequal(iter,max_iter)
          % Maximum number of allowed iterations reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Max number of iterations reached before the tolerance is achieved</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
      end    
      
      % -------------------------------------------------------
      % Mesh refinement or parametric enrichment? 
      % -------------------------------------------------------     
      % vartheta variable:
      % vartheta < 1 delays parametric enrichments;
      % vartheta > 1 triggers earlier parametric enrichments.
      % Default value is 1.
      vartheta = 1;
      if  rho_Y >= vartheta * rho_Q
          polenr_or_meshref = 2; % Mesh refinement
      else
          polenr_or_meshref = 1; % Polynomial enrichment
      end

  end
% end while loop
  endLoopTime = toc(startLoopTime);

% Resizing vectors
  stoch_goafem_update_vectors;
  
% Display the final data
  stoch_goafem_display_finaldata;
  
% ----------------------------------------------------------------------------- 
% Save output
% -----------------------------------------------------------------------------
% Resize the index set up to active norvs (noarv)
  [~,col] = find(indset);     
  indset = indset(:,1:max(col));
  
  gohome; cd datafiles;
% Final mesh info                   
  save stoch_goafem_final_mesh_info.mat xy evt bound interior eboundt;
% Update data sot stoch_data file
  save stoch_data -append noarv P;    
% Data from the adaptive loop  
  save stoch_goafem_adaptive_output.mat threshold_ele threshold_ind                     ... 
                                        nel_iter totnvtx_iter intnvtx_iter              ...
                                        dof_iter dofInt_iter indset noarv               ...
                                        cardP_iter cardQ_iter markind_iter arv_iter     ...
                                        index_iter index_init Q_indset M_ind extra_rv   ...
                                        error_iter error_primal_iter error_dual_iter    ...
                                        yp_est_primal_iter yp_est_dual_iter             ...
                                        xq_est_primal_iter xq_est_dual_iter             ...
                                        energy_primal_iter energy_dual_iter Gu_iter     ...
                                        rhoY_iter rhoQ_iter                             ...
                                        Ncum_iter endLoopTime;

% -------------------------------------------------------------------------
% Plots
% -------------------------------------------------------------------------
% Plot final mesh
  plot_mesh(evt,xy,'Final mesh'); 
  
% Convergence plot
  stoch_goafem_convplot;
  
% Plot expectation, variance, and YP/XQ-error estimates 
  fprintf('\nPlotting expectation, variance and estimated errors...');
  stoch_goafem_plotdata(dom_type,u_gal,var_sol_primal,yp_elerr_primal,xq_elerr_primal,evt,xy,'primal');
  stoch_goafem_plotdata(dom_type,z_gal,var_sol_dual,  yp_elerr_dual,  xq_elerr_dual,  evt,xy,'dual');
  fprintf('done\n');
  fprintf('\n-> Output mesh data saved to: datafiles/stoch_goafem_final_mesh_info.mat');  
  fprintf('\n-> Output data saved to:      datafiles/stoch_goafem_adaptive_output.mat\n');
  fprintf('\nTo compute a reference goal-functional run the script <strong>stoch_goafem_refgoal_effindices</strong>\n');
  
% end scriptfile