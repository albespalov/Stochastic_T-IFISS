%STOCH_GOAFEM_DATA2PGFPLOTS creates a .dat file for the pgfplots latex package
% 
% Provide a name for the file .dat and a value for the reference goal-functional
% G(uref). In case G(uref) is not available, either because it is not computable
% or it is not a matter of interest, just put some value anyway.
% 
% In order to work, this file requires the data produced at the end of
% the adaptive code, which have to be loaded in the workspace; this is the file:
% - stoch_goafem_adaptive_output.mat
%
% The default data file created contains the following columns:
% - iterations                        (iter)
% - overall (internal) dofs           (dofs = #intvtx \times #indset)
% - number of elements                (nels)
% - cumulative Ntotal                 (Ncum = \sum_{\ell=0}^{L} \dim(V_\ell))
% - cardinality of the P index set    (cardP)
% - cardinality of the Q index set    (cardQ)
% - number of marked indices          (markInd)
% - number of active parameters       (arv)
% - computed G(u_gal)                 (Gul)
% - product estimate \mu\zeta         (error_product)
% - estimate \mu for primal problem   (error_primal)
% - estimate \zeta for dual problem   (error_dual)
% - xq-error (primal problem)         (xq_primal)
% - xq-error (dual problem)           (xq_dual)
% - yp-error (primal problem)         (yp_primal)
% - yp-error (dual problem)           (yp_dual)
% - "true" error in the QoI           (treugerr)
% - effectivity indices               (effindices)
%
% File saved to /datafiles/filename.data
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  gohome; cd datafiles;
  
% File name
  filename = 'thetaX1.0_thetaP1.0_longer3.dat';

% Reference G(uref): cannot be empty (put the right value, or a fake one)
  Guref = 1.90117e-02;

% Compute the effectivity indices
  truegerr   = abs( repmat(Guref,1,length(Gu_iter)) - Gu_iter ); % |G(uRef) - G(uXP)|
  effindices = error_iter ./ truegerr;                           % prod-est / |G(uRef) - G(uXP)|   

% Create data structure
  godata = [((1:length(dofInt_iter))-1)', ...
            dofInt_iter',                 ...
            nel_iter',                    ...
            Ncum_iter',                   ... 
            cardP_iter',                  ...
            cardQ_iter',                  ...
            markind_iter',                ...
            arv_iter',                    ... 
            Gu_iter',                     ...
            error_iter',                  ...
            error_primal_iter',           ...
            error_dual_iter',             ...
            xq_est_primal_iter',          ...
            xq_est_dual_iter',            ...
            yp_est_primal_iter',          ...
            yp_est_dual_iter',            ... 
            truegerr',                    ...
            effindices'];

% Open file
  fid = fopen(filename,'w');
  if fid == -1, error('Error opening file!\n'); end  
% Save data
  fprintf(fid,'iter\t dofs\t nels\t Ncum\t cardP\t cardQ\t markInd\t arv\t Gul\t error_product\t error_primal\t error_dual\t xq_primal\t xq_dual\t yp_primal\t yp_dual\t truegerr\t effindices\n');
  fprintf(fid,'%d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\n',godata');
% Close file
  fclose(fid);

% end scriptfile