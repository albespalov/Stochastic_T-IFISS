function [f1,f2] = stoch_goafem_gauss_H1(s,t,xl,yl,norv,problem)
%STOCH_GOAFEM_GAUSS_H1 evaluates stochastic H1 source term at Gauss point 
%
% [f1,f2] = stoch_goafem_gauss_H1(s,t,xl,yl,norv,problem)
%
% input:
%             s    reference element x coordinate   
%             t    reference element y coordinate
%            xl    physical element x vertex coordinates 
%            yl    physical element y vertex coordinates  
%          norv    number of random variables
%       problem    1 for primal problem, 2 for dual problem
%
% output:
%       [f1,f2]    H1 part of the right-hand side
%
% NOTE: this is the same original SIFISS function STOCH_GAUSS_SOURCE
% (DJS; 17 March 2013) with few modifications: 
% - one more input (problem);
% - right function stoch_goafem_specific_H1rhs/stoch_goafem_specific_H1goal called;
%
% Function(s) called: tshape
%                     stoch_goafem_specific_H1rhs
%                     stoch_goafem_specific_H1goal
% 
% See also STOCH_GOAFEM_GAUSS_L2
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel         = length(xl(:,1));
  zero_v      = zeros(nel,1);
  xx          = zero_v;
  yy          = xx;
  [phi_e,~,~] = tshape(s,t);

  for ivtx = 1:3 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  
  if problem == 1
      % H1 rhs of primal problem 
      [f1,f2] = stoch_goafem_specific_H1rhs(xx,yy,nel,norv);
  elseif problem == 2
      % H1 rhs of dual problem 
      [f1,f2] = stoch_goafem_specific_H1goal(xx,yy,nel,norv);
  end

end % end function