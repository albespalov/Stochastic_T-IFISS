function [ff] = stoch_goafem_gauss_L2(s,t,xl,yl,norv,problem)
%STOCH_GOAFEM_GAUSS_L2 evaluates L2 stochastic source term at Gauss point 
%   
% [ff] = stoch_goafem_gauss_L2(s,t,xl,yl,norv,problem)
%   
% input:
%             s    reference element x coordinate   
%             t    reference element y coordinate
%            xl    physical element x vertex coordinates 
%            yl    physical element y vertex coordinates  
%          norv    number of random variables
%
% output: 
%            ff    L2 part of the right-hand side
%
% NOTE: this is the same original SIFISS function STOCH_GAUSS_SOURCE
% (DJS; 17 March 2013) with few modifications: 
% - one more input (problem);
% - right function stoch_goafem_specific_L2rhs/stoch_goafem_specific_L2goal called;
%
% Function(s) called: tshape
%                     stoch_goafem_specific_L2rhs
%                     stoch_goafem_specific_L2goal
%
% See also STOCH_GOAFEM_GAUSS_H1
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel         = length(xl(:,1));
  zero_v      = zeros(nel,1);
  xx          = zero_v;
  yy          = xx;
  [phi_e,~,~] = tshape(s,t);

  for ivtx = 1:3 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  
  if problem == 1
      % L2 rhs of primal problem 
      ff = stoch_goafem_specific_L2rhs(xx,yy,nel,norv);
  elseif problem == 2
      % L2 rhs of dual problem 
      ff = stoch_goafem_specific_L2goal(xx,yy,nel,norv);
  end

end % end function