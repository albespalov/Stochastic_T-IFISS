%STOCH_GOAFEM_INIT_PARAM sets up parameters for adaptive algorithm
%
% The initialised parameters are:
%
%           iPlotConv    plotting switch for stoch_minres convergence
%            max_iter    maximum number of iterations allowed
%           adapt_max    maximum number of pol. enrichments allowed
%          index_iter    cell-array containing new indices of pol. enrichments
%       index_counter    variable counting the polynomial enrichments
%      index_saveiter    iterations's numbers when enrichments occur
%             pmethod    P1 Galerkin approximation
%             err_tol    tolerance
%           subdivPar    red/bisec3 subdivision for spatial error estimation
%             ypestim    a posteriori spatial error estimator type
%         markedgelem    spatial marking type (elements or edges) 
%       threshold_ele    spatial marking parameter (Doerfler marking)
%       threshold_ind    parametric marking parameter (Doerfler marking)
%
% See also STOCH_ADAPT_INIT_PARAM
%                     
%   TIFISS scriptfile: LR; 04 July 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

% Plotting switch for stoch_minres convergence (0/1)
  iPlotConv = 0;
  
% Maximum number of allowed iterations
  max_iter = 100;

% Set up cell array for the evolving index set and maximum number of enrichments
  adaptmax       = 20;
  index_iter     = cell(1,adaptmax);
  index_counter  = 1;
  index_saveiter = zeros(1,adaptmax);

% Polynomial degree:
% - currently only P1 for both solving and estimation;
% - P2 available for solving only.
  pmethod = 1;

% Tolerance
  if ismember(sn,[1,2])
      err_tol = default('Tolerance (default 7.0e-05)',7.0e-05);
  elseif ismember(sn,[3,4])
      err_tol = default('Tolerance (default 4.0e-04)',4.0e-04);
  else%if sn==5
      err_tol = default('Tolerance (default 8.0e-03)',8.0e-03);
  end

% Red/Bisec3 for spatial error estimation 1/2? See:
% Ainsworth, Oden, A posteriori error estimation in finite element analysis, 
% Wiley, 2000 - Figure 5.2 (p. 87) for the basis functions in both cases.
  subdivPar = 2;
  
% (Spatial) error estimation type (see STOCH_GOAFEM_DIFFPOST):
% 1 - eYP hierarchical estimator (elementwise residual problems);
% 2 - eYP hierarchical estimator (assembled system for the residual problems);
% 3 - 2-level error estimator.
  ypestim = 3; 
  
% Marking elements or edges 1/2? 
% This depends on the estimation type:
% - ypestim=1   -> only elements can be marked, i.e., markedgelem=1;
% - ypestim=2/3 -> both elements and edges can be marked, i.e.,markedgelem=1/2.
  markedgelem = 2;
  if ismember(markedgelem,[1,2])
      if ypestim == 1 && markedgelem == 2
          error('Hierarchical elementwise eYP allows marking elements only!');
      end
  else
      error('Marking type not allowed!');
  end
     
% Marking threshold parameters for both elements/edges and indices
  fprintf('Marking threshold parameters for Doerfler marking:\n');
  threshold_ele = default('   spatial parameter    (default 0.25)',0.25);
  threshold_ind = default('   parametric parameter (default 0.90)',0.90);

% end scriptfile