function [a] = stoch_goafem_gauss_coeff(s,t,xl,yl,norv,KL_DATA)
%STOCH_GOAFEM_GAUSS_COEFF evaluates stochastic coefficient at Gauss point
%   
% [a] = stoch_goafem_gauss_coeff(s,t,xl,yl,norv,KL_DATA)
%   
% input:
%            s     reference element x coordinate
%            t     reference element y coordinate
%           xl     physical element x vertex coordinates
%           yl     physical element y vertex coordinates
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion
%
% output: 
%            a     stochastic coefficient evaluated at Gauss point
%
% NOTE: this is the same original SIFISS function STOCH_GAUSS_COEFF
% (DJS; 19 January 2013) with the only modification: 
% - calling function goasgfem_specific_coeff.m 
% 
% Function(s) called: tshape
%                     stoch_goafem_specific_coeff
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel         = length(xl(:,1));
  zero_v      = zeros(nel,1);
  xx          = zero_v;
  yy          = xx; 
  [phi_e,~,~] = tshape(s,t);
  
  for ivtx = 1:3 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  
  [a] = stoch_goafem_specific_coeff(xx,yy,nel,norv,KL_DATA);
        
end % end function