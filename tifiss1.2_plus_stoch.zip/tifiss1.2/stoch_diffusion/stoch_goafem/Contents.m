% STOCH_GOAFEM
%
% Files
%   stoch_goafem_convplot                  - plots the computed error estimates versus the overall number of dofs
%   stoch_goafem_data2pgfplots             - creates a .dat file for the pgfplots latex package
%   stoch_goafem_diffpost                  - a posteriori error estimation for the adaptive goal-oriented algorithm
%   stoch_goafem_diffpost_p1_xq            - computes XQ error estimator for stochastic P1 primal and dual solutions
%   stoch_goafem_diffpost_p1_yp            - computes hierarchical YP error estimator for both primal and dual solutions
%   stoch_goafem_diffpost_p1_yp_2level     - computes YP 2-level error estimator for both primal and dual solutions
%   stoch_goafem_diffpost_p1_yp_bc         - imposes Dirichlet boundary conditions on boundary midpoints
%   stoch_goafem_diffpost_p1_yp_detcontrib - elementwise deterministic contributions in the spatial YP estimation
%   stoch_goafem_diffpost_p1_yp_linsys     - computes hierarchical YP-estimate solving the (fully) assembled error problems
%   stoch_goafem_diffusion_main            - main driver for goal-oriented adaptive SGFEM
%   stoch_goafem_display_finaldata         - prints the data at the end of adaptive loop
%   stoch_goafem_edgeres_p1_with_p1        - computes YP edge residuals for both primal and dual solutions
%   stoch_goafem_effindices                - computes the effectivity indices given a reference goal-functional
%   stoch_goafem_femp1_setup               - assembled P1 stochastic coefficient matrix generator for both primal and dual problems
%   stoch_goafem_femp2_setup               - assembled P2 stochastic coefficient matrix generator for both primal and dual problems
%   stoch_goafem_gauss_coeff               - evaluates stochastic coefficient at Gauss point
%   stoch_goafem_gauss_divH1               - evaluates the divergence of the H1 part of the RHSs at Gauss point 
%   stoch_goafem_gauss_gradcoeff           - evaluates gradient of the stochastic coefficient at Gauss point
%   stoch_goafem_gauss_H1                  - evaluates stochastic H1 source term at Gauss point 
%   stoch_goafem_gauss_L2                  - evaluates L2 stochastic source term at Gauss point 
%   stoch_goafem_imposebcx                 - imposes Dirichlet boundary conditions for both primal and dual problems
%   stoch_goafem_init_param                - sets up parameters for adaptive algorithm
%   stoch_goafem_init_spatial              - generates a (coarse) spatial grid for the adaptive loop
%   stoch_goafem_init_stoch                - sets up stochastic coefficients and initial index sets for the adaptive loop
%   stoch_goafem_intres_p1_with_p1         - computes YP elementwise interior residuals for both primal and dual solutions
%   stoch_goafem_jump_H1                   - computes the jump components of the H1 part of the residual problem
%   stoch_goafem_marking                   - spatial and parametric marking for the goal-oriented algorithm
%   stoch_goafem_mollifier                 - computes the normalization constant of [PO99] mollifier
%   stoch_goafem_p1fluxjmps                - vectorised edge jumps of P1 stochastic Galerkin solution
%   stoch_goafem_plotdata                  - plots mean-field, variance and YP/XQ-errors for P1 approximations
%   stoch_goafem_refgoal_effindices        - computes a reference QoI and the effectiviy indices
%   stoch_goafem_setup_and_solve           - sets up and solves the sGFEM linear system for both primal and dual problems
%   stoch_goafem_specific_bc               - STOCH_ZERO BC zero boundary condition 
%   stoch_goafem_specific_coeff            - STOCH_GOAFEM_EMN_COEFF synthetic stochastic diffusion coefficient
%   stoch_goafem_specific_divH1goal        - STOCH_GOAFEM_ZERO_DIVH1GOAL zero deterministic divergence of H1 part of RHS of the dual problem
%   stoch_goafem_specific_divH1rhs         - STOCH_GOAFEM_ZERO_DIVH1RHS zero deterministic divergence of H1 part of RHS of the primal problem
%   stoch_goafem_specific_gradcoeff        - STOCH_GOAFEM_EMN_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%   stoch_goafem_specific_H1goal           - STOCH_GOAFEM_ZERO_H1GOAL zero deterministic H1 part of the RHS of the dual problem 
%   stoch_goafem_specific_H1rhs            - STOCH_GOAFEM_ZERO_H1RHS zero deterministic H1 part of the RHS of the primal problem 
%   stoch_goafem_specific_L2goal           - STOCH_GOAFEM_PO99_L2GOAL Prudhomme-Oden mollifier L2 part of RHS of the dual problem
%   stoch_goafem_specific_L2rhs            - STOCH_GOAFEM_UNIT_L2RHS unit deterministic L2 part of RHS of the primal problem
%   stoch_goafem_update_vectors            - preallocation, update, and resizing of vectors in the adaptive loop
