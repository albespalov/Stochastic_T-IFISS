function [g1,g2] = stoch_goafem_specific_H1goal(x,y,nel,norv)
%STOCH_GOAFEM_ZERO_H1GOAL zero deterministic H1 part of the RHS of the dual problem 
%
% [g1,g2] = stoch_goafem_specific_H1goal(x,y,nel,norv)
%
% input:
%          x    x coordinate vector
%          y    y coordinate vector
%        nel    number of elements
%       norv    number of random variables
%
% The function computes the source vector \vec{g}=[g1,g2], with g1=g2=0, 
% in the RHS G(v) of the dual problem; see STOCH_GOAFEM_FEMP1_SETUP.
%
% See also STOCH_GOAFEM_ZERO_H1RHS
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  g1 = zeros(nel,norv+1);
  g2 = zeros(nel,norv+1);

end % end function