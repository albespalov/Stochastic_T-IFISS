function [divf] = stoch_goafem_specific_divH1rhs(x,y,nel,norv)
%STOCH_GOAFEM_ZERO_DIVH1RHS zero deterministic divergence of H1 part of RHS of the primal problem
%
% [divf] = stoch_goafem_specific_divH1rhs(x,y,nel,norv)
%
% input:
%        x   x coordinate vector
%        y   y coordinate vector
%      nel   number of elements
%     norv   number of random variables
%
% output: 
%     divf   divergence of source vector of the RHS (primal)
%
% The function returns the divergence of the source vector \vec{f} of the RHS 
% of the primal problem; see also STOCH_GOAFEM_SPECIFIC_H1RHS.
%
% See also STOCH_GOAFEM_ZERO_DIVH1GOAL
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
  
  divf = [zeros(nel,1),zeros(nel,norv)];
  
end % end fuction