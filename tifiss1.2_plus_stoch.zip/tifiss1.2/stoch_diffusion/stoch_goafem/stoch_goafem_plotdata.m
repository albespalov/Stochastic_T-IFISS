function stoch_goafem_plotdata(dom_type,sol,var,yperrelem,xqerrelem,evt,xy,problem)
%STOCH_GOAFEM_PLOTDATA plots mean-field, variance and YP/XQ-errors for P1 approximations
%
% stoch_goafem_plotdata(sn,sol,var,yperrelem,xqerrelem,evt,xy,problem)
%
% input: 
%        dom_type    domain type
%             sol    nodal stochatic FE solution vector
%             var    nodal variance of the solution
%       yperrelem    YP-elementwise error indicators
%       xqerrelem    XQ-elementwise error indicators
%             evt    element mapping matrix
%              xy    vertex coordinate vector  
%         problem    'primal' or 'dual' 
%
% NOTE that the mean-field and the variance are interpolated on a square grid 
% [X,Y] in order to plot isolines (contour plot); Matlab does not provide a 
% countour function for mesh-based functions.
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
    
  nvtx = size(xy,1);    % Number of vertices
  nel  = size(evt,1);   % Number of elements

% Refine grid and get cartesian product mesh
  npoints = 120; 
  x = linspace(min(xy(:,1)),max(xy(:,1)),npoints);
  y = linspace(min(xy(:,2)),max(xy(:,2)),npoints); 
  [X,Y] = meshgrid(x,y);

% -----------------------------------------------------------------------------    
% Expectation and variance of the solution (for countour plots)
% -----------------------------------------------------------------------------
  expsol = griddata(xy(:,1),xy(:,2),sol(1:nvtx),X,Y);
  varsol = griddata(xy(:,1),xy(:,2),var,X,Y);
% Fix to zero (eventual very small) negative values of the variance
% (due to griddata interpolation)
  varsol(varsol<0.0) = 0.0;
  
% Get rid of points outside the domain for X-Y grid
  [expsol,varsol] = recover_domain(dom_type,expsol,varsol,X,Y);
  
% Plot mean value and variance
  title1 = ['Expectation of ',problem,' solution'];
  title2 = ['Variance of ',problem,' solution'];
  plot_solvar(X,Y,expsol,varsol,sol(1:nvtx),var,xy,evt,dom_type,title1,title2);
       
% -----------------------------------------------------------------------------  
% Error estimators
% -----------------------------------------------------------------------------
% Recover local coordinates of elements
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3); 
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1); % x-coordinates of all vertices
      yl_v(:,ivtx) = xy(evt(:,ivtx),2); % y-coordinates of all vertices
  end
% Recover the element's centroid coordinates
  xyc(:,1) = (1/3) * sum(xl_v,2);
  xyc(:,2) = (1/3) * sum(yl_v,2);

% Refined grid and cartesian product mesh
  x = 0.5 * ( x(1:end-1) + x(2:end) );
  y = 0.5 * ( y(1:end-1) + y(2:end) );
  [X,Y] = meshgrid(x,y);  
  
% YP and XQ error estimators
  yperr = griddata(xyc(:,1),xyc(:,2),yperrelem,X,Y);
  xqerr = griddata(xyc(:,1),xyc(:,2),xqerrelem,X,Y);
  
% Get rid of points outside the domain for X-Y grid
  [yperr,xqerr] = recover_domain(dom_type,yperr,xqerr,X,Y);  
  
% Plot error estimators
  title1 = ['YP estimated error (',problem,')'];
  title2 = ['XQ estimated error (',problem,')'];
  plot_error(X,Y,yperr,xqerr,dom_type,title1,title2);
   
end % end function  


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [func1,func2] = recover_domain(dom_type,func1,func2,X,Y)
% Get rid of those points of the cartesian grid X-Y outside the domain 

  global slope1crack
  global slope2crack
  
% Nothing to do for convex domains (square):
% - dom_type == 1, (0,1)^2
% - dom_type == 2, (-1,1)^2
% Non-convex domains:  
  if dom_type == 3
      % L-shaped domain
      func1(X<0 & Y<0) = nan;
      func2(X<0 & Y<0) = nan;
  elseif dom_type == 4
      % Unit crack domain (0,1)^2  \ (1/2,1)x{1/2} (crack on the right)
  elseif dom_type == 5
      % Large crack domain (-1,1)^2 \ (-1,0)x{0} (crack on the left)
      func1((Y>slope1crack*X & X<0) & (Y<0)) = nan;
      func1((Y<slope2crack*X & X<0) & (Y>0)) = nan;
      func2((Y>slope1crack*X & X<0) & (Y<0)) = nan;
      func2((Y<slope2crack*X & X<0) & (Y>0)) = nan;
  end
  
end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function plot_solvar(X,Y,func1,func2,expmesh,varmesh,xy,evt,dom_type,title1,title2)
% In this plot function both mean value and variance are plotted using trimesh 

  fontSize = 14;

% Plot functions 
  figure%(fig);
  
  subplot(221)
  contour(X,Y,func1,20);    
  axis square;  axis off; 
  outline_domain(dom_type);
  title(title1); 
  
  subplot(222)
  trimesh(evt,xy(:,1),xy(:,2),expmesh); %mesh(X,Y,func1);          
  axis square;
  view(330,30);
  
  subplot(223)
  contour(X,Y,func2,20);    
  axis square;  axis off; 
  outline_domain(dom_type);
  title(title2);
   
  subplot(224)
  trimesh(evt,xy(:,1),xy(:,2),varmesh); % mesh(X,Y,func2);          
  axis square;
  view(330,30);
    
  set(findall(gcf,'-property','Fontsize'),'Fontsize',fontSize);
  
end % end child function

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function plot_error(X,Y,func1,func2,dom_type,title1,title2)
% In this plot function errors are plotted using mesh with the interpolated data 

  fontSize = 14;

% Plot functions 
  figure%(fig);
  
  subplot(221)
  contour(X,Y,func1,20);    
  axis square;  axis off; 
  outline_domain(dom_type);
  title(title1); 
  
  subplot(222)
  mesh(X,Y,func1);          
  axis square;
  view(330,30);
  
  subplot(223)
  contour(X,Y,func2,20);    
  axis square;  axis off; 
  outline_domain(dom_type);
  title(title2);
   
  subplot(224)
  mesh(X,Y,func2);
  axis square;
  view(330,30);
    
  set(findall(gcf,'-property','Fontsize'),'Fontsize',fontSize);

end % end child function

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function outline_domain(dom_type)
% Outline the corresponding domain 
  if dom_type == 1
      unitsquare;
  elseif dom_type == 2
      squarex;
  elseif dom_type == 3
      ellx;
  elseif dom_type == 4
      unitcrack;
  elseif dom_type == 5
      largecrack;
  end
  
end % end child function