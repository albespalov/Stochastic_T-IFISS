function [xq_elerr_primal, xq_errvec_primal, xq_errest_primal, ...
          xq_elerr_dual,   xq_errvec_dual,   xq_errest_dual] = ...
          stoch_goafem_diffpost_p1_xq(xy,evt,bound,xgal,zgal,indset,norv,KL_DATA,Q_indset,GPQ) 
%STOCH_GOAFEM_DIFFPOST_P1_XQ computes XQ error estimator for stochastic P1 primal and dual solutions
%
% [xq_elerr_primal, xq_errvec_primal, xq_errest_primal, ...
%  xq_elerr_dual,   xq_errvec_dual,   xq_errest_dual] = ...
%  stoch_goafem_diffpost_p1_xq(xy,evt,bound,xgal,zgal,indset,norv,KL_DATA,Q_indset,GPQ) 
%                                    
% input:
%                  xy    vertex coordinate vector
%                 evt    element mapping matrix
%               bound    boundary vertex vector
%                xgal    stochastic primal P1 solution vector
%                zgal    stochastic dual P1 solution vector
%              indset    index set of polynomial degrees
%                norv    number of admissible random variables
%             KL_DATA    data related to KL-expansion
%            Q_indset    current 'detail' index set
%                 GPQ    current cell of GPQ-matrices
%
% output:
%     xq_elerr_primal    vector of elementwise XQ-estimates       (primal)
%    xq_errvec_primal    vector of XQ-estimate per each \mu index (primal)
%    xq_errest_primal    global XQ energy error estimate          (primal)
%       xq_elerr_dual    vector of elementwise XQ-estimates       (dual)
%      xq_errvec_dual    vector of XQ-estimate per each \mu index (dual)
%      xq_errest_dual    global XQ energy error estimate          (dual)
%
% Function(s) called:    triangular_gausspoints
%                        tderiv
%                        stoch_goafem_gauss_coeff
%
% V_{XQ}-estimator: employs the same P1 basis functions as for the solution
% tensorised with the 'detailed set' of polynomials. 
%
% The function solves the discrete formulations for the eXQ error estimators
% for the primal and the dual Galerkin solutions:
%
%   B0(eXQ,v) = F(v) - B(uXP,v),     for all v \in VXQ,             (1)
%   B0(eXQ,v) = G(v) - B(zXP,v),     for all v \in VXQ,             (2)
%
% by exploiting the decomposition of eXQ into contributions individual 
% indices \mu in Q. See pag. A2127-A2128 of [BS16];
%
% Recall that the source F(v) (resp. G(v)) of (1) (resp. of (2)) is represented 
% as in [MS09] (or [FPZ16]); see also STOCH_GOAFEM_FEMP1_SETUP.
%
% References:
%
% [BS16] Bespalov, Silvester, Efficient adaptive stochastic Galerkin methods for
% parametric operator equations, SIAM J. Sci. Comput., 38(4)A2127-A2128, 2016;
%
% [MS09] Mommer, Stevenson, A goal-oriented finite element method with
% convergence rates, SIAM J. Numer. Anal., 47(2)861-866, 2009;
%
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016;
%
% Function(s) called: triangular_gausspoints
%                     tderiv
%                     stoch_goafem_gauss_coeff
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri
  
  nvtx = size(xy,1);    % Number of vertices
  nel  = size(evt,1);   % Number of elements

% Length of the index set
  [P,~] = size(indset); 
  
% Length of Q_indset
  Q = size(Q_indset,1);   
     
% Setting the effective number of active random variables needed for computation
  new_noarv = size(GPQ,2) - 1;
      
% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);
     
% Recover local coordinates
  xl_v = zeros(nel,3);
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2); 
  end

% -----------------------------------------------------------------------------
% Computing deterministic element-wise contributions
% -----------------------------------------------------------------------------
% Allocate memory 
  ade = zeros(nel,3,3,new_noarv+1); 
  
% Loop over Gaussian points  
  for igpt = 1:nngpt
      sigpt = s(igpt);
      tigpt = t(igpt);
      wght  = wt(igpt);
      % Evaluate derivatives and coefficients
      [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigpt,tigpt,xl_v,yl_v);
      [coeff_v] = stoch_goafem_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
      %
      % Element-wise stiffness matrices
      for m = 0:new_noarv
          for j = 1:3
              for i = 1:3
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff_v(:,m+1) .* dphidx_v(:,i) .* dphidx_v(:,j) .* invjac_v(:);
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff_v(:,m+1) .* dphidy_v(:,i) .* dphidy_v(:,j) .* invjac_v(:);
              end
          end
      end
  end
 
% -----------------------------------------------------------------------------
% Left-Hand sides of (1) (the same of (2)): B(e_XQ,v), with e_XQ and v \in V_XQ
% -----------------------------------------------------------------------------
% The resulting fully assembled matrix will be a block diagonal matrix 
% where each block is represented by [K_0]_ij, that is the stiffness matrix
% associated with a_0(x). It comes from the Kronecker product between Id 
% matrix of size Q and K_0. However, there is no need to assemble it
  
% Deterministic block K_0 of the full matrix on the lhs
  K_0 = sparse(nvtx,nvtx);
  for krow = 1:3
      nrow = evt(:,krow);	 
      for kcol = 1:3
          ncol = evt(:,kcol);	  
          K_0 = K_0 + sparse(nrow,ncol,ade(:,krow,kcol,1),nvtx,nvtx);
      end
  end
  
% -----------------------------------------------------------------------------
% Right-Hand sides of (1)-(2): 
% F(v) - B(uXP,v), with uXP \in VXP and v \in VXQ
% G(v) - B(zXP,v), with zXP \in VXP and v \in VXQ 
% -----------------------------------------------------------------------------
% In the representation used for F(v) (resp. G(v)) (see references above), there 
% is a L2 term due to f0 (resp. g0) and a H1 term \vec{f}\cdot\grad(v) (resp.
% \vec{g}\cdot\grad(v)). Since both sources f0 and \vec{f} are non-parametric, 
% and, as always assumed the index (0,0,0,...) is not in Q_indset, we have 
% F(v) = G(v) = 0.
  ff = sparse(nvtx,Q);
  gg = sparse(nvtx,Q);
  
% Reshape primal and dual solution vectors for efficient kronecker product  
  Ugal = reshape(xgal,nvtx,P);
  Zgal = reshape(zgal,nvtx,P);
  
% Perform assembly of global rhs 
  for m = 1:new_noarv 
      % Assembling K_m stiffness matrices for current value of m
      Km = sparse(nvtx,nvtx);
      for krow = 1:3
          nrow = evt(:,krow);	 
          for kcol = 1:3
              ncol = evt(:,kcol);	  
              Km = Km + sparse(nrow,ncol,ade(:,krow,kcol,m+1),nvtx,nvtx);
          end
      end 
      % Efficient kronecker product between GPQ{m+1} and K_m matrices 
      % avoiding storage of the full matrix \sum_m kron(G{m},rhsB{m});
      % see Nagy's lecture and stoch_matvec function
      %
      % Primal (error) problem
      Bu = Km * Ugal * GPQ{m+1}';      
      ff = ff - Bu;   
      %
      % Dual (error) problem
      Bz = Km * Zgal * GPQ{m+1}';      
      gg = gg - Bz;      
  end
   
% -----------------------------------------------------------------------------
% Imposing Dirichlet boundary condition
% -----------------------------------------------------------------------------
% Note that these are zeros if bcs are non-parametric (deterministic)
% and, as always assumed, (0,0,0,...) is not in Q_indset; this means the bcs 
% matrix contains zero-columns from the 2nd to norv+1 column.
% In this case, it suffices to put zero on boundary rows/columns, put 1 in
% the corresponding diagonal entries, and set the rhs to zero in boundary 
% positions, no matter whether bcs were homogeneous or not (here, we are in VXQ).
% If the b.c. are parametric, then STOCH_RHS_MULTIPLIERS has to be called and 
% the same construction as in STOCH_IMPOSEBCX has to be done.

  K_0(bound,:) = 0.0;
  K_0(:,bound) = 0.0;
  K_0(bound,bound) = speye(length(bound),length(bound));
  ff(bound,:)  = 0.0;  % Primal problem
  gg(bound,:)  = 0.0;  % Dual problem
  
% -----------------------------------------------------------------------------
% Solving the systems
% ----------------------------------------------------------------------------
% Computing the e_XQ solution for each vertex (and for each mode).
% NOTE that the lhs of both primal and dual problems is the same.
  G1 = eye(Q,Q);
  xq_errgal_primal = (K_0\ff)/G1;
  xq_errgal_dual   = (K_0\gg)/G1;
   
% -----------------------------------------------------------------------------  
% B0-norm and elementwise estimates
% -----------------------------------------------------------------------------
% Computing the B0-norm of e_XQ^(\mu), for each index \mu \in Q, and the 
% elementwise XQ-estimates needed (only) to plot the last XQ-estimate at
% the end of the loop
  [xq_errvec_primal,xq_elerr_sq_primal] = xq_local_est(ade,K_0,evt,Q,xq_errgal_primal);
  [xq_errvec_dual,  xq_elerr_sq_dual]   = xq_local_est(ade,K_0,evt,Q,xq_errgal_dual);
    
% -----------------------------------------------------------------------------
% Global XQ-estimates (B0-norm of the estimated error)
% -----------------------------------------------------------------------------
% Primal (error) problem
  xq_elerr_primal  = sqrt(xq_elerr_sq_primal);
  xq_errest_primal = norm(xq_elerr_primal,2);
  
% Dual (error) problem
  xq_elerr_dual  = sqrt(xq_elerr_sq_dual);
  xq_errest_dual = norm(xq_elerr_dual,2);
   
end % end function

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [errvec,elerr_sq] = xq_local_est(ade,K0,evt,Q,xqerrgal)
%Computes single eXQ^(\mu) estimates for each \mu \in Q and elementwise XQ-estimates

  nel      = size(evt,1); 
  errvec   = zeros(Q,1);
  err_loc  = zeros(nel,3);
  elerr_sq = zeros(nel,1);
  
% Loop over modes  
  for mu = 1:Q     
      % Local B0-norm for the current index \mu
      errvec(mu) = sqrt( xqerrgal(:,mu)' * K0 * xqerrgal(:,mu) );
      %
      % Rearranging e_XQ nodal values elementwise
      for ivtx = 1:3
          err_loc(:,ivtx) = xqerrgal(evt(:,ivtx),mu);
      end
      %
      % Computing elementwise B0^2 energy norm
      for ivtx = 1:3          
          for jvtx = 1:3
              elerr_sq(:) = elerr_sq(:) + err_loc(:,ivtx) .* ade(:,ivtx,jvtx,1) .* err_loc(:,jvtx);
          end  
      end 
  end

end % end child function