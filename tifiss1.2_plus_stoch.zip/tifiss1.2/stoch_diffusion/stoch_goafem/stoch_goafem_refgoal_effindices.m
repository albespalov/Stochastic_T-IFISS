%STOCH_GOAFEM_REFGOAL_EFFINDICES computes a reference QoI and the effectiviy indices
%
% The reference solution is computed with P2 Galerkin approximations using:
% - a uniform refinement of the last mesh produced when the loop terminates,  
% - an index set given by the union of the last index set generated and the 
%   last set of marked indices when the loop terminates
% 
% Function(s) called: uniform_refinement
%                     p2_grid_generator
%                     stoch_goafem_femp2_setup
%                     stoch_goafem_imposebcx
%                     stoch_est_minresx
%                     stoch_variancex
%                     stoch_matvecx
%                     stoch_goafem_effindices
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  fprintf('\n');fprintf(num2str(repmat('-',1,75)));

  fprintf('\n<strong>Reference solution</strong> computed with P2 approximation using:\n');
  fprintf('- a uniform refinement of the last mesh obtained,\n');
  fprintf('- the union of the last index set generated and the last set of marked indices.\n');

% -------------------------------------------------------------------------  
% Uniform refinement of the last mesh
% -------------------------------------------------------------------------
  [refxy,refevt,refbound,~,refeboundt] = uniform_refinement(xy,evt,bound,eboundt,2);
  fprintf('\n<strong>Mesh refinement:</strong>\n');
  fprintf('   total vertices:    %d\n',size(refxy,1));
  fprintf('   total elements:    %d',size(refevt,1));
  
% -------------------------------------------------------------------------  
% Parametric enrichment using the last set of the marked indices
% -------------------------------------------------------------------------
% Resize indeset correctly
  indset = uint8([indset,zeros(size(indset,1),norv-size(indset,2))]);
% Enrichment
  [~,Q_noarv] = find(Q_indset(M_ind,:));
  if (max(Q_noarv) + extra_rv) > norv
      error('<strong>Too many active parameters...</strong>\n');
  end
  indset = [indset; Q_indset(M_ind,:)];
% Length of the index set, active parameters, and degree
  P = size(indset,1);
  noarv = norv - nnz(all(indset == 0,1));
  polyd = max(sum(indset,2));
% Sort the index set
  indset = sortrows(indset);
  
  fprintf('\n<strong>Parametric enrichment:</strong>\n');
  fprintf('   total indices:     %d\n',P);
  fprintf('   active parameters: %d\n',noarv);
 
% -------------------------------------------------------------------------
% Setup and solve the discrete system  
% -------------------------------------------------------------------------
% New G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);
  
% Generating the P2 grid
  [p2xy,p2evt,p2bound] = p2_grid_generator(refxy,refevt,refbound);
  [Knbc,fnbc,gnbc] = stoch_goafem_femp2_setup(p2xy,p2evt,indset,P,norv,noarv,KL_DATA);

% Boundary conditions 
  [K,fnew,gnew,u_gal,z_gal,dupl_intern] = stoch_goafem_imposebcx(Knbc,fnbc,gnbc,G,p2xy,p2bound,indset,P,norv,noarv);

% Dofs
  totaldofs   = P*size(p2xy,1);
  intotaldofs = P*(size(p2xy,1) - length(p2bound));

% Number of internal node
  nint = length(dupl_intern)/P;

% -------------------------------------------------------------------------  
% MINRES solver      
% -------------------------------------------------------------------------
  Amean = K{1};
  [L,U,PP,QQ] = lu(Amean);        
  tol = 1e-10;    maxit = 99;
  apost = 0;      stopit = 0;    prob_type = 'sdiff';
  MA = 'm_sdiff'; aparams = struct('nint',nint,'L',PP\L,'U',U/QQ);
  
  [xminres,~,~,~,~] = stoch_est_minresx(G,K,fnew,apost,stopit,maxit,tol,prob_type,MA,aparams);                                     
  [zminres,~,~,~,~] = stoch_est_minresx(G,K,gnew,apost,stopit,maxit,tol,prob_type,MA,aparams); 

% Computed Galerkin solutions                  
  u_gal(dupl_intern) = xminres;  % Primal solution
  z_gal(dupl_intern) = zminres;  % Dual solution

% Compute variances
  [refvarsol_primal] = stoch_variancex(u_gal,P); % Primal solution's variance
  [refvarsol_dual]   = stoch_variancex(z_gal,P); % Dual solution's variance

% Energy norm of primal solution
  [bref_primal]    = stoch_matvecx(u_gal,G,Knbc);
  refenergy_primal = sqrt(u_gal' * bref_primal);

% Energy norm of dual solution
  [bref_dual]    = stoch_matvecx(z_gal,G,Knbc);
  refenergy_dual = sqrt(z_gal' * bref_dual);
   
% -----------------------------------------------------------------------------
% Compute G(u)=G(u_gal) at current iteration
% -----------------------------------------------------------------------------  
% Note that B(u,z) = G(u), with u being the primal solution and z being the dual solution.
% Hence, G(u) = B(u,z) = u' * A * z;
  Guref = u_gal' * stoch_matvecx(z_gal,G,Knbc);  %=b_ref_dual
  
% -----------------------------------------------------------------------------
% Print data
% ----------------------------------------------------------------------------- 
  fprintf('<strong>New dofs:</strong>\n');
  fprintf('   Overall P2 total dofs:    %d\n',totaldofs); 
  fprintf('   Overall P2 internal dofs: %d\n',intotaldofs); 
  fprintf('<strong>Reference primal solution:</strong>\n');
  fprintf('   Maximum mean value:       %8.3e\n',max(u_gal(1:nvtx)));      
  fprintf('   Maximum variance:         %8.3e\n',max(refvarsol_primal));
  fprintf('   Energy norm:              %8.4e\n',refenergy_primal);
  fprintf('<strong>Reference dual solution:</strong>\n');
  fprintf('   Maximum mean value:       %8.3e\n',max(z_gal(1:nvtx)));      
  fprintf('   Maximum variance:         %8.3e\n',max(refvarsol_dual));  
  fprintf('   Energy norm:              %8.4e\n',refenergy_dual);
  fprintf('<strong>Reference goal-functional:</strong>   %8.4e\n',Guref);

% Save data for energy solution
  gohome; cd datafiles;
  save stoch_goafem_refgoal.mat refenergy_primal refenergy_dual totaldofs intotaldofs ...
                                indset refxy refevt refbound refeboundt;
                            
  fprintf('\n-> Data saved to: datafiles/stoch_goafem_refgoal.mat\n');
  fprintf(num2str(repmat('-',1,75)));fprintf('\n\n');
  
% -----------------------------------------------------------------------------
% Effectivity indices
% -----------------------------------------------------------------------------   
  [effindices] = stoch_goafem_effindices(error_iter,Gu_iter,Guref,1);

% end scriptfile