%STOCH_GOAFEM_MARKING spatial and parametric marking for the goal-oriented algorithm
% 
% The function implements the marking step for both element/edges and
% indices. In particular, the spatial marking allows to mark either the
% elements or the edges (see 'markedgelem' below and in STOCH_GOAFEM_INIT_PARAM).
%
% Also, the function computes the refinements indicators used to choose the
% enhancement type (either mesh refinement of parametric enrichment).
%
% The marking strategy implemented is the one described in:
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016;
%
% Function(s) called: marking_strategy_fa
%                     get_all_marked_elem
%                     
%   TIFISS scriptfile: LR; 04 July 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  fprintf('\n<strong>Marking step (spatial and parametric):</strong>');

% ----------------------------------------------------------------------------    
% Spatial marking step
% ----------------------------------------------------------------------------
  if markedgelem == 1
      %
      % Marking elements
      %
      markTime = tic;
      % Spatial Doerfler marking for both primal and dual problem
      [Mele_primal] = marking_strategy_fa(yp_elerr_primal,2,threshold_ele);
      [Mele_dual]   = marking_strategy_fa(yp_elerr_dual,  2,threshold_ele);
      %
      % Join the two sets of marked elements
      n_marked_ele = min( length(Mele_primal), length(Mele_dual) );
      %
      % Set of marked elements (for primal and dual problem)
      Mele = sort( unique([Mele_primal(1:n_marked_ele); Mele_dual(1:n_marked_ele)]) );
      %
      % Overall set of marked elements (and edges, needed for mesh refinement)
      [MMele,MMedge] = get_all_marked_elem(Ybasis,evtY,Mele,markedgelem);
      
      fprintf('\n-> marked %d elements out of total %d',length(Mele),size(evt,1));
      fprintf('\n-> <strong>%d</strong> overall marked elements out of total %d',length(MMele),size(evt,1));
      fprintf(' (%.5f sec)',toc(markTime));
      
      % Spatial estimates associated with marked elements
      yp_refined_primal = norm( yp_elerr_primal(MMele), 2 );
      yp_refined_dual   = norm( yp_elerr_dual(MMele),   2 );

  else% markedgelem == 2
      %
      % Marking edges
      %
      markTime = tic;
      % Perform spatial Doerfler marking for both primal and dual problem
      [Medge_primal] = marking_strategy_fa(yp_ederr_primal,2,threshold_ele);
      [Medge_dual]   = marking_strategy_fa(yp_ederr_dual,2,  threshold_ele);
      %
      % Join the two sets of marked edges
      n_marked_edge = min( length(Medge_primal), length(Medge_dual) );
      %
      % Set of marked edges (for primal and dual problem)
      Medge = sort( unique([Medge_primal(1:n_marked_edge); Medge_dual(1:n_marked_edge)]) );
             
      % Overall set of marked edges (and elements, needed for mesh refinement)
      [MMele,MMedge] = get_all_marked_elem(Ybasis,evtY,Medge,markedgelem);
      
      fprintf('\n-> marked %d edges out of total %d',length(Medge),size(Ybasis,1));
      fprintf('\n-> <strong>%d</strong> overall marked edges out of total %d',length(MMedge),size(Ybasis,1));
      fprintf(' (%.5f sec)',toc(markTime));
      
      % Spatial estimates associated with marked edges
      yp_refined_primal = norm( yp_ederr_primal(MMedge), 2 );
      yp_refined_dual   = norm( yp_ederr_dual(MMedge),   2 );
  end
  
% ----------------------------------------------------------------------------    
% Parametric marking 
% ----------------------------------------------------------------------------    
  markTime = tic;
% Perform parametric Doerfler marking for both primal and dual problem
  [Mind_primal] = marking_strategy_fa(xq_errvec_primal,2,threshold_ind);
  [Mind_dual]   = marking_strategy_fa(xq_errvec_dual,  2,threshold_ind);
    
% Join the two sets of marked edges
  n_marked_ind = min( length(Mind_primal), length(Mind_dual) );
 
% Set of marked indices
  M_ind = sort( unique([Mind_primal(1:n_marked_ind); Mind_dual(1:n_marked_ind)]) );
  fprintf('\n-> <strong>%d</strong> overall marked indices out of total %d',length(M_ind),length(xq_errvec_primal));
  fprintf(' (%.5f sec)\n',toc(markTime));

% Parametric estimates associated with marked indices
  xq_marked_primal  = norm( xq_errvec_primal(M_ind),2 );
  xq_marked_dual    = norm( xq_errvec_dual(M_ind),2   );
            
% ----------------------------------------------------------------------------    
% Refinement indicators rhos
% ----------------------------------------------------------------------------    
% Compute the spatial rho_Y and the parametric rho_Q indicators: 
% the larger indicator indicates the enhancement (either mesh refinement or 
% parametric enrichment) to perform on the next iteration
        
  rho_Y = sqrt( tot_est_primal^2 * yp_refined_dual^2 + tot_est_dual^2 * yp_refined_primal^2 );
  rho_Q = sqrt( tot_est_primal^2 * xq_marked_dual^2  + tot_est_dual^2 * xq_marked_primal^2  );
   
% % Alternatively: including also the (very small) term neglected in the true
% % expression of the refinement indicators, i.e., 
% % - yp_refined_primal^2 * yp_refined_dual^2 (for rho_Y)
% % - xq_marked_primal^2  * xq_marked_dual^2  (for rho_Q) 
%
%   rho_Y = sqrt( tot_est_primal^2 * yp_refined_dual^2 + tot_est_dual^2 * yp_refined_primal^2 - ( yp_refined_primal^2 * yp_refined_dual^2 ) );
%   rho_Q = sqrt( tot_est_primal^2 * xq_marked_dual^2  + tot_est_dual^2 * xq_marked_primal^2  - ( xq_marked_primal^2  * xq_marked_dual^2  ) );

% % Playing with actual number of new dof that will be added?   
%   rho_Y = rho_Y / ( (nvtx + length(MM_edge)) * P );
%   rho_Q = rho_Q / ( nvtx * (P + length(M_ind))   );

% end scriptfile