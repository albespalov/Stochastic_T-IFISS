function [yp_elerr_primal,yp_err_est_primal, ...
          yp_elerr_dual,  yp_err_est_dual] = ...
          stoch_goafem_diffpost_p1_yp(xy,evt,eboundt,xgal,zgal,evtY,xyY,eex,tve,...
                                      els,G,indset,P,norv,noarv,KL_DATA,subdivPar)
%STOCH_GOAFEM_DIFFPOST_P1_YP computes hierarchical YP error estimator for both primal and dual solutions
%
% [yp_elerr_primal,yp_err_est_primal, ...
%  yp_elerr_dual,  yp_err_est_dual] = ...
%  stoch_goafem_diffpost_p1_yp(xy,evt,eboundt,xgal,zgal,evtY,xyY,eex,tve,...
%                              els,G,indset,P,norv,noarv,KL_DATA,subdivPar)
%
% input:
%                  xy     vertex coordinate vector  
%                 evt     element mapping matrix
%             eboundt     element edge boundary matrix 
%                xgal     stochastic primal P1 solution vector
%                zgal     stochastic dual P1 solution vector
%                evtY     element mapping matrix for midpoints
%                 xyY     vertex coordinate vector for midpoints
%                 eex     element connectivity array
%                 tve     edge location array
%                 els     elementwise edge lengths
%                   G     (1 x (noarv+1)) cell of G-matrices
%              indset     index set of polynomial degrees
%                   P     length of the index set
%                norv     number of random variables
%               noarv     number of active random variables
%             KL_DATA     data related to KL-expansion
%           subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%     yp_elerr_primal     vector of YP element indicators (primal)
%   yp_err_est_primal     global YP error estimate        (primal)
%       yp_elerr_dual     vector of YP element indicators (dual)
%     yp_err_est_dual     gglobal YP error estimate       (dual)
%
% V_{YP}-estimator: employs elementwise P1-bubbles for the edge midpoints 
% (for both red and bisec3 uniform sub-division) tensorised with the 
% original set of polynomials.
%
% The function solves the discrete problems for the eYP estimators:
%
%   B0(eYP,v) = F(v) - B(uXP,v),     for all v \in VYP,        (1)
%   B0(eYP,v) = G(v) - B(zXP,v),     for all v \in VYP.        (2)
%
% using a standard element residual technique to construct the corresponding 
% local residual problems over each element K in the mesh; see [BS16, eq. (5.3)]
%
% Recall that the source F(v) (resp. G(v)) of (1) (resp. of (2)) follows the 
% representation of [MS09] (and [FPZ16]); see also STOCH_GOAFEM_FEMP1_SETUP.
%
% References:
%
% [BS16] Bespalov, Silvester, Efficient adaptive stochastic Galerkin methods for 
% parametric operator equations, SIAM J. Sci. Comput., 38(4)A2118-A2140, 2016;
%
% [MS09] Mommer, Stevenson, A goal-oriented finite element method with
% convergence rates, SIAM J. Numer. Anal., 47(2)861-866, 2009;
%
% [FPZ16] Feischl, Praetorius, van der Zee, An abstract analysis of optimal 
% goal-oriented adaptivity, SIAM J. Numer. Anal., 54(3)1423-1448, 2016.
%
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_goafem_gauss_coeff
%                      stoch_goafem_intres_p1_with_p1
%                      stoch_goafem_edgeres_p1_with_p1
%                      stoch_goafem_diffpost_p1_yp_bc
% 
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nel = size(evt,1);  % Number of elements
 
% Recover local coordinates 
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2);
  end
  
% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);
  
% Allocate memory  
  adem = zeros(nel,4,3,3);
  ade  = zeros(nel,3,3);   
  xl_s = zeros(nel,4,3);
  yl_s = zeros(nel,4,3);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% ----------------------------------------------------------------------------- 
% STEP 1: coordinates of midpoints: four sub-elements
% -----------------------------------------------------------------------------
% First physical mid-edge points
  xedge1(:,1) = 0.5*(xl_v(:,2) + xl_v(:,3));  
  yedge1(:,1) = 0.5*(yl_v(:,2) + yl_v(:,3));
  
% Second physical mid-edge points
  xedge2(:,1) = 0.5*(xl_v(:,1) + xl_v(:,3));   
  yedge2(:,1) = 0.5*(yl_v(:,1) + yl_v(:,3));
  
% Third physical mid-edge points
  xedge3(:,1) = 0.5*(xl_v(:,1) + xl_v(:,2));  
  yedge3(:,1) = 0.5*(yl_v(:,1) + yl_v(:,2));

% Define the local sub-division 
  if subdivPar == 1
      %
      % Red sub-division
      % 
      % First physical sub-element 
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge3(:);      yl_s(:,2,1) = yedge3(:);
      xl_s(:,2,2) = xl_v(:,2);      yl_s(:,2,2) = yl_v(:,2);
      xl_s(:,2,3) = xedge1(:);      yl_s(:,2,3) = yedge1(:);
      % Third physical sub-element 
      xl_s(:,3,1) = xedge2(:);      yl_s(:,3,1) = yedge2(:);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xl_v(:,3);      yl_s(:,3,3) = yl_v(:,3);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge1(:);      yl_s(:,4,1) = yedge1(:);
      xl_s(:,4,2) = xedge2(:);      yl_s(:,4,2) = yedge2(:);
      xl_s(:,4,3) = xedge3(:);      yl_s(:,4,3) = yedge3(:);    
  else
      %
      % Bisec3 sub-division
      % 
      % First physical sub-element
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge2(:);      yl_s(:,2,1) = yedge2(:);
      xl_s(:,2,2) = xedge3(:);      yl_s(:,2,2) = yedge3(:);
      xl_s(:,2,3) = xl_v(:,2);      yl_s(:,2,3) = yl_v(:,2);
      % Third physical sub-element 
      xl_s(:,3,1) = xl_v(:,2);      yl_s(:,3,1) = yl_v(:,2);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xedge2(:);      yl_s(:,3,3) = yedge2(:);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge2(:);      yl_s(:,4,1) = yedge2(:);
      xl_s(:,4,2) = xedge1(:);      yl_s(:,4,2) = yedge1(:);
      xl_s(:,4,3) = xl_v(:,3);      yl_s(:,4,3) = yl_v(:,3);
  end    
  
% ----------------------------------------------------------------------------- 
% STEP 2: (non-parametric) contributions on LHS of problems (1)-(2)
% ----------------------------------------------------------------------------- 
  for subelt = 1:4   
      % Recoverl local coordinates
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end     
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);
          %
          % Evaluate derivatives
          [~,invjac_m,~,dphidx_m,dphidy_m] = tderiv(sigpt,tigpt,xl_m,yl_m);
          %
          % Evaluate diffusion coefficients
          [coeff_v] = stoch_goafem_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % Loop over the three mid-edge linear functions
          for j = 1:3
              for i = 1:3
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidx_m(:,i) .* dphidx_m(:,j) .* invjac_m(:);
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidy_m(:,i) .* dphidy_m(:,j) .* invjac_m(:);
              end
          end
          
      end
      % end of Gauss point loop
  end
% end of subdivided element loop

% -----------------------------------------------------------------------------
% STEP 3: manual assembly of subelement contributions
% -----------------------------------------------------------------------------
  if subdivPar == 1
      % 
      % Red sub-division: assembling
      % 
      % First edge
      ade(:,1,1) = adem(:,2,3,3) + adem(:,3,2,2) + adem(:,4,1,1);
      ade(:,1,2) = adem(:,3,2,1) + adem(:,4,1,2);
      ade(:,1,3) = adem(:,2,3,1) + adem(:,4,1,3);
      % Second edge
      ade(:,2,1) = adem(:,3,1,2) + adem(:,4,2,1);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,3,1,1) + adem(:,4,2,2);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,4,2,3);  
      % Third edge     
      ade(:,3,1) = adem(:,2,1,3) + adem(:,4,3,1);
      ade(:,3,2) = adem(:,1,2,3) + adem(:,4,3,2);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,1,1) + adem(:,4,3,3);  
  else
      %
      % Bisec3 sub-division: assembling
      % 
      % First edge
      ade(:,1,1) = adem(:,3,2,2) + adem(:,4,2,2);
      ade(:,1,2) = adem(:,3,2,3) + adem(:,4,2,1);
      % ae(:,1,3) = empty
      % Second edge
      ade(:,2,1) = adem(:,3,3,2) + adem(:,4,1,2);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,2,1,1) + adem(:,3,3,3) + adem(:,4,1,1);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,2,1,2);  
      % Third edge     
      % ae(:,3,1) = empty 
      ade(:,3,2) = adem(:,1,2,3) + adem(:,2,2,1);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,2,2);
  end 
    
% ----------------------------------------------------------------------------- 
% STEP 4: right-hand side of problems (1)-(2)
% -----------------------------------------------------------------------------   
% Local rhs of the local residual problems are given by the difference of
%
% resint := \int_Gamma\int_K (f0(x) + div(\vec{f}))v(x,y)    dxdpiy  
%         + \int_Gamma\int_K div(a(x,y)\grad uXP(x,y))v(x,y) dxdpiy 
%
% which is the 'internal residual' and
%
% resedge := (1/2)\int_Gamma\int_{\partial K}(Jump(\vec{f}) + a(s,y)Jump(uXP))v(s,y) dsdpiy
%
% which is the 'edge residual' for each element K in the mesh. 
% The same for the dual error problem.
   
% Internal residuals (primal and dual)
  [resint_primal, resint_dual] = stoch_goafem_intres_p1_with_p1(xy,xl_s,yl_s,evt,xgal,zgal,indset,P,G,norv,noarv,KL_DATA,subdivPar);

% Edge residuals (primal and dual)
  [resedge_primal, resedge_dual] = stoch_goafem_edgeres_p1_with_p1(xy,evt,eboundt,xgal,zgal,eex,tve,els,indset,P,G,norv,noarv,KL_DATA);
  
  fprintf('Primal problem: internal_res = %7.4e;   edge_res = %7.4e\n',norm(resint_primal),norm(resedge_primal));
  fprintf('Dual problem:   internal_res = %7.4e;   edge_res = %7.4e\n',norm(resint_dual),norm(resedge_dual));

% Final rhs (primal and dual)
  rhs_primal = resint_primal - resedge_primal;
  rhs_dual   = resint_dual   - resedge_dual;
  
% -----------------------------------------------------------------------------  
% Impose Dirichlet boundary conditions 
% -----------------------------------------------------------------------------
  Ade = ade;
  
% ...on primal error problem
  [~,rhs_primal] = stoch_goafem_diffpost_p1_yp_bc(Ade,rhs_primal,xy,evt,eboundt,evtY,xyY,P,norv);
    
% ...on dual error problem
  [ade,rhs_dual] = stoch_goafem_diffpost_p1_yp_bc(Ade,rhs_dual,xy,evt,eboundt,evtY,xyY,P,norv);
  
% NOTE that the lhs matrix ade is the same for both problems (hence it is
% returned only once)
  
% -----------------------------------------------------------------------------
% STEP 4: solving the system
% -----------------------------------------------------------------------------

% LDLT vectorised factorization
  [ade] = element_ldlt_factorization(ade,nel);

% Solver forward-backward substitutions (primal and dual)
  [yp_elerr_sq_primal] = yp_err_solver(ade,rhs_primal,nel,P);
  [yp_elerr_sq_dual]   = yp_err_solver(ade,rhs_dual,nel,P);
 
% Element-indicators and B0-norm of the estimator ||eYP||_B0 (primal)
  yp_elerr_primal   = sqrt(yp_elerr_sq_primal);
  yp_err_est_primal = norm(yp_elerr_primal,2);
  
% Element-indicators and B0-norm of the estimator ||eYP||_B0 (dual)
  yp_elerr_dual   = sqrt(yp_elerr_sq_dual);
  yp_err_est_dual = norm(yp_elerr_dual,2);  
        
end  % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [yp_err_sq_el] = yp_err_solver(ade,rhs,nel,P)
%Solve the stochastic linear system and returns the elementwise YP error
%indicators squared

% Loop over the stochastic components
  elerr = zeros(3*P,nel);
  for nnp = 1:P
      fde = rhs(:,(nnp-1)*3+1:nnp*3);
      xdx = element_lusolve(ade,fde);
      % The vector elerr contains the solution values over the 3 edge 
      % midpoints for each element
      elerr((nnp-1)*3+1:nnp*3,1:nel) = xdx';
  end
         
% The vector yp_err_sq_el is the set of the B_0^2 norms of e_Y|_K,P for 
% each element K in the mesh
  yp_err_sq_el = zeros(nel,1);
  for svtx = 1:3*P
      yp_err_sq_el(:) = yp_err_sq_el(:) + rhs(:,svtx) .* elerr(svtx,:)';
  end

end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [ade] = element_ldlt_factorization(ade,nel)
% LDLT factorization of the matrix ade
  
  nn = 3; % number of hat functions per element
  dd = zeros(nel,nn);
  rr = zeros(nel,nn);
  
  for kk = 1:nn-1
      for pp = 1:kk-1
          rr(1:nel,pp) = dd(1:nel,pp).*ade(1:nel,kk,pp);
      end
      dd(1:nel,kk) = ade(1:nel,kk,kk);
      for pp = 1:kk-1
          dd(1:nel,kk) = dd(1:nel,kk) - ade(1:nel,kk,pp).*rr(1:nel,pp);
      end
      for ii = kk+1:nn
          for pp = 1:kk-1
              ade(1:nel,ii,kk) = ade(1:nel,ii,kk) - ade(1:nel,ii,pp).*rr(1:nel,pp);
          end
          ade(1:nel,ii,kk) = ade(1:nel,ii,kk)./dd(1:nel,kk);
      end
  end
  
  for pp = 1:nn-1
      rr(1:nel,pp) = dd(1:nel,pp).*ade(1:nel,nn,pp);
  end
  
  dd(1:nel,nn) = ade(1:nel,nn,nn);
  
  for pp = 1:nn-1
      dd(1:nel,nn) = dd(1:nel,nn) - ade(1:nel,nn,pp).*rr(1:nel,pp);
  end
  
% Overwrite diagonal entries
  for kk = 1:nn
      ade(1:nel,kk,kk) = dd(1:nel,kk);
  end

end % end child function