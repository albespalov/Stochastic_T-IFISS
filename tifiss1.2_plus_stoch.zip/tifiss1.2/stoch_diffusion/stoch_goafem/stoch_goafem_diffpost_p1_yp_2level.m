function [yp_elerr_primal,yp_ederr_primal,yp_errest_primal, ...
          yp_elerr_dual,  yp_ederr_dual,  yp_errest_dual] = ...
          stoch_goafem_diffpost_p1_yp_2level(xy,evt,eboundt,evtY,xyY,boundY,Ybasis,...
                                         xgal,zgal,G,P,norv,noarv,KL_DATA,subdivPar)
%STOCH_GOAFEM_DIFFPOST_P1_YP_2LEVEL computes YP 2-level error estimator for both primal and dual solutions
%
% [yp_elerr_primal,yp_ederr_primal,yp_errest_primal, ...
%  yp_elerr_dual,  yp_ederr_dual,  yp_errest_dual] = ...
%  stoch_goafem_diffpost_p1_yp_2level(xy,evt,eboundt,evtY,xyY,boundY,Ybasis,...
%                                     xgal,zgal,G,P,norv,noarv,KL_DATA,subdivPar)
%
% input:
%                xy     vertex coordinate vector  
%               evt     element mapping matrix
%           eboundt     element edge boundary matrix
%              evtY     element mapping matrix for midpoints
%               xyY     vertex coordinate vector for midpoints
%              xgal     stochastic primal P1 solution vector
%              zgal     stochastic dual P1 solution vector
%                 G     (1 x (noarv+1)) cell of G-matrices
%                 P     length of the index set
%              norv     number of random variables
%             noarv     number of active random variables
%           KL_DATA     data related to KL-expansion
%         subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%   yp_elerr_primal     vector of 2-level YP-element indicators (primal)
%   yp_ederr_primal     vector of 2-level YP-edge indicators    (primal) 
%  yp_errest_primal     global 2-level YP error estimate        (primal) 
%     yp_elerr_dual     vector of 2-level YP element indicators (dual)
%     yp_ederr_dual     vector of 2-level YP-edge indicators    (dual)
%    yp_errest_dual     global 2-level YP error estimate        (dual)
%
% V_{YP}-estimator: employs elementwise P1-bubbles for the edge midpoints 
% (for both red and bisec3 uniform sub-division) tensorised with the 
% original set of polynomials.
%
% The element indicators are recovered by square summing the 3 
% edge indicators per element.
%
% Main reference for this estimator: 
% [BPRR18] Bespalov, Praetorius, Rocchi, Ruggeri, Goal-oriented error estimation 
% and adaptivity for elliptic PDEs with parametric or uncertaint inputs, 2018. 
%
% Function(s) called:  stoch_goafem_diffpost_p1_yp_detcontrib
%                      stoch_goafem_specific_bc
%                      
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);      % Number of vertices  (i.e., number of X-basis functions) 
  nyb  = size(Ybasis,1);  % Number of midpoints (i.e., number of Y-basis functions (boudary ones included))
  
% -----------------------------------------------------------------------------                 
% STEP 1: elementwise contributions from uniform red/bisec3 refinement type
% -----------------------------------------------------------------------------                 
  [ade,bde,~,fde,gde] = stoch_goafem_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar);

% -----------------------------------------------------------------------------
% STEP2: assembling ||a0^(1/2)\grad\phi_j||^2_L^2(D), for all \phi_j in Y 
% -----------------------------------------------------------------------------
% Extract elements and associated edges for Y-basis functions
  elems = Ybasis(:,[1,2]);   
  edges = Ybasis(:,[3,4]);
   
% Indices: elements, Y-basis, Y-basis
  ind1 = {elems(:,1), edges(:,1), edges(:,1)};
  ind2 = {elems(:,2), edges(:,2), edges(:,2)};
  
% Summing contributions  
  B0phi = ade( sub2ind(size(ade) , ind1{:}) ) + ade( sub2ind(size(ade) , ind2{:}) );
% For a Y-basis on the boundary, we have to halve the contribution, since in 
% the above line it has been doubled
  B0phi(boundY) = B0phi(boundY) ./ 2;
  
% -----------------------------------------------------------------------------                       
% STEP 3: assembling F(v) and G(v) for all basis \phi_j*P_\nu in V_YP
% -----------------------------------------------------------------------------
  
% Indices: elements, Y-basis, ones.
% Note the last indices are 'ones' as we need only fde(:,:,1) (resp. gde(:,:,1))
% since sources are non-parametric (deterministic) 
  idx1 = {elems(:,1), edges(:,1), ones(size(elems,1),1)}; 
  idx2 = {elems(:,2), edges(:,2), ones(size(elems,1),1)};

% Summing deterministic contributions (primal problem) 
  ff = fde( sub2ind(size(fde) , idx1{:}) ) + fde( sub2ind(size(fde) , idx2{:}) );
% For a Y-basis on the boundary, we have to halve the contributions since in the 
% above line we doubled the contribution coming from the only boundary element
  ff(boundY) = ff(boundY) ./ 2;
  
% Summing deterministic contributions (dual problem)  
  gg = gde( sub2ind(size(gde) , idx1{:}) ) + gde( sub2ind(size(gde) , idx2{:}) );
% For a Y-basis on the boundary, we have to halve the contributions since in the 
% above line we doubled the contribution coming from the only boundary element
  gg(boundY) = gg(boundY) ./ 2;  
  
% Since sources are non-parametric, F(v) = kron(g0,ff) = (ff,0,0,...)', where 
% g0 is the first column of the matrix G0, i.e., g0 = (1,0,0,...)'. 
% The same for the dual (error) problem.

% Keep F(v) as a nyb-by-P matrix  
  Fv = [ff, sparse(nyb,P-1)];

% Keep G(v) as a nyb-by-P matrix  
  Gv = [gg, sparse(nyb,P-1)];

% -----------------------------------------------------------------------------                                
% STEP 4: assembling B(uXP,v) and B(zXP,v) for all basis \phi_j*P_\nu in V_YP
% -----------------------------------------------------------------------------
% The terms B(uXP,v) and B(zXP,v) will be nyb-by-P vectors 

% Reshape xgal and zgal vector solutions in matrix form for efficient kronecker products 
  X = reshape(xgal,nvtx,P);
  Z = reshape(zgal,nvtx,P);  

% Matrix Bx and Bz for assembling B(uXP,v) and B(zXP,v), for each v in V_YP
  Bx = sparse(nyb,P);
  Bz = sparse(nyb,P);   
                    
% Loop over random variables
  for m = 0:noarv
      %
      % Allocate memory for current noarv
      Km = sparse(nyb,nvtx);
      %
      % Assembling deterministic matrix
      for kYb = 1:3
          % Indices for Y-basis
          indY = evtY(:,kYb);	 
          for kXb = 1:3
              % Indices for X-basis
              indX = evt(:,kXb);
              % Assembling
              Km = Km + sparse(indY, indX, bde(:, kYb, kXb, m+1), nyb, nvtx);
          end
      end
 
      % NOTE that if the problem has homogeneous bcs, then such conditions 
      % for the corresponding X-basis on the boundary should be imposed, 
      % i.e, Km(:,bound) = 0. However, this is unnecessary as Km will be
      % multiplied by X which already contains zeros in X-boundary positions.
      %
      % The global Kronecker matrix
      %
      %         [ kron(G{0},K{m}) + sum_m^M kron(G{m},K{m}) ] * x_gal
      %
      % is assembled by summing its component matrix contributions
      %
      %                kron(G{m},K{m}) * x_gal
      %
      % for the current value of m \geq 0. 
      % Efficient assembling avoiding 'kron' for the matrix kron(G{m},K{m}) 
      % saving both memory and time; note that there should be G' but the 
      % G-matrices are symmetric;
      
      % Primal(error) problem
      Bx = Bx + ( Km * X * G{m+1} );
      
      % Dual (error) problem
      Bz = Bz + ( Km * Z * G{m+1} );     
  end        
  
% Global rhs for primal (error) problem: F(v) - B(uXP,v)
  rhs_primal = Fv - Bx;
  
% Global rhs for dual (error) problem: G(v) - B(zXP,v)
  rhs_dual = Gv - Bz;
  
% -----------------------------------------------------------------------------  
% STEP 5: imposing interpolated error as Dirichlet boundary conditions 
% -----------------------------------------------------------------------------                                
  [rhs_primal,rhs_dual,~,nonzerobndY,freebndY] = diffpost_nonzerobc(evt,evtY,xy,xyY,...
                                                 boundY,eboundt,rhs_primal,rhs_dual,P,norv);
  
% -----------------------------------------------------------------------------
% STEP 6: compute the 2-level estimate
% -----------------------------------------------------------------------------

% Interior Y-nodes
  interiorY = 1:boundY(1)-1;
  
% Vector of edge-indicators^2 (internal and boundary Y-basis nodes)
%
% Primal problem
  yp_edgevec_sq_primal = zeros(nyb,1);
  yp_edgevec_sq_primal(interiorY)   = sum( rhs_primal(interiorY,:).^2 , 2)   ./ B0phi(interiorY);
  yp_edgevec_sq_primal(nonzerobndY) = sum( rhs_primal(nonzerobndY,:).^2 , 2) ./ B0phi(nonzerobndY);
  yp_edgevec_sq_primal(freebndY)    = sum( rhs_primal(freebndY,:).^2 , 2)    ./ B0phi(freebndY);
%
% Dual problem
  yp_edgevec_sq_dual = zeros(nyb,1);
  yp_edgevec_sq_dual(interiorY)     = sum( rhs_dual(interiorY,:).^2 , 2)   ./ B0phi(interiorY);
  yp_edgevec_sq_dual(nonzerobndY)   = sum( rhs_dual(nonzerobndY,:).^2 , 2) ./ B0phi(nonzerobndY);
  yp_edgevec_sq_dual(freebndY)      = sum( rhs_dual(freebndY,:).^2 , 2)    ./ B0phi(freebndY);
%
% NOTE that:
% - second contributions (due to nonzerobndY) are zero if bcs = 0 everywhere;
% - third contributions (due to freebndY) are zero if bcs are imposed (whatever 
% they are) only on some parts of the domain (e.g., in case of a channel domain).

% Vector of edge-indicators (primal and dual)
  yp_ederr_primal  = sqrt( yp_edgevec_sq_primal );
  yp_ederr_dual    = sqrt( yp_edgevec_sq_dual );   
  
% Global 2-level estimates (primal and dual) 
  yp_errest_primal = sqrt( sum( yp_ederr_primal.^2 ) );
  yp_errest_dual   = sqrt( sum( yp_ederr_dual.^2 ) );
    
% -----------------------------------------------------------------------------
% STEP 7: recovering the element indicators from edge indicators
% -----------------------------------------------------------------------------  
  [yp_elerr_primal] = get_yp_errelem(evtY,yp_ederr_primal,1);
  [yp_elerr_dual]   = get_yp_errelem(evtY,yp_ederr_dual,1);

end  % end function


% -----------------------------------------------------------------------------  
% Child function
% -----------------------------------------------------------------------------     
function [rhs_primal,rhs_dual,zerobndY,nonzerobndY,freebndY] = diffpost_nonzerobc(evt,evtY,xy,xyY,boundY,eboundt,rhs_primal,rhs_dual,P,norv)
%Imposes boundary conditions on boundary midpoints
  
% -----------------------------------------------------------------------------
% Extract boundary elements with boundary edges respectively = 1, 2, and 3
% ----------------------------------------------------------------------------- 
  beled1 = eboundt( eboundt(:,2)==1 , 1);
  beled2 = eboundt( eboundt(:,2)==2 , 1);
  beled3 = eboundt( eboundt(:,2)==3 , 1);
   
% -----------------------------------------------------------------------------
% Extract boundary nodes/midpoints and compute the error
% -----------------------------------------------------------------------------
  node1    = evt ( beled1, [2 3]);   % nodes of the 1st boundary edges (columns 2,3 of evt)
  midp1    = evtY( beled1, 1);       % midpoints on 1st boundary edges (column 1 of evtY)
  [error1,bcnodeY1] = stoch_interperror_bc(xy,xyY,node1,midp1,norv);
  
  node2    = evt ( beled2, [3 1]);   % nodes of the 2nd boundary edges (columns 3,1 of evt)
  midp2    = evtY( beled2, 2);       % midpoints on 2nd boundary edges (column 2 of evtY)
  [error2,bcnodeY2] = stoch_interperror_bc(xy,xyY,node2,midp2,norv);
  
  node3    = evt ( beled3, [1 2]);   % nodes of the 3rd boundary edges (columns 1,2 of evt)
  midp3    = evtY( beled3, 3);       % midpoints on 3rd boundary edges (column 3 of evtY)
  [error3,bcnodeY3] = stoch_interperror_bc(xy,xyY,node3,midp3,norv);
 
% Update the two rhs in all boundary-node positions: note that to adjust
% dimensions we have to add also zeros columns as in case of non-parametric 
% b.c. only the first (column) component counts as boundary conditions
%
% Primal problem
  rhs_primal(midp1,:) = [error1, zeros(length(midp1),P-1) ];
  rhs_primal(midp2,:) = [error2, zeros(length(midp2),P-1) ];
  rhs_primal(midp3,:) = [error3, zeros(length(midp3),P-1) ];
%
% Dual problem
  rhs_dual(midp1,:)   = [error1, zeros(length(midp1),P-1) ];
  rhs_dual(midp2,:)   = [error2, zeros(length(midp2),P-1) ];
  rhs_dual(midp3,:)   = [error3, zeros(length(midp3),P-1) ];  
  
% -----------------------------------------------------------------------------
% Separate Y-boundary nodes with nonzero boundary conditions
% -----------------------------------------------------------------------------
% Among all the Y-boundary nodes, we want to return those ones for which 
% the corresponding boundary conditions are non-homogeneous (if any).
% However, we have to ensure that where bc == 0 the returned value are really 
% zero (and not some value like ~1.3e-17) as this would not be read as zero. 
% To this end, if some values is returned as ~1.3e-17, we find it by looking
% at those values smaller than, for instance, 1e-10.

% Set of Y-boundary nodes with zero boundary conditions
  zerobndY1 = midp1( bcnodeY1 <= 1e-10 );  
  zerobndY2 = midp2( bcnodeY2 <= 1e-10 );  
  zerobndY3 = midp3( bcnodeY3 <= 1e-10 );  
  zerobndY  = [zerobndY1; zerobndY2; zerobndY3];
  
% Set of Y-boundary nodes with non-zero boundary conditions  
  nonzerobndY1 = midp1( ~ismember(midp1,zerobndY1) );
  nonzerobndY2 = midp2( ~ismember(midp2,zerobndY2) );
  nonzerobndY3 = midp3( ~ismember(midp3,zerobndY3) );
  nonzerobndY  = [nonzerobndY1; nonzerobndY2; nonzerobndY3];
    
% Finally, create the set of all the rest of "free" nodes, for example, where 
% Neumann bcs = 0 have been imposed (i.e., those parts of the domain where 
% Dirichlet bcs are not imposed, if any). 
% At this point of the function, these free nodes are the Y-boundary nodes not 
% included in the previous two sets.
  freebndY = boundY( ~ismember(boundY,[zerobndY;nonzerobndY]) );
% NOTE that if bcs are homogeneous everywhere, this set is empty.

end % end child function
 

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [error,bc_nodeY] = stoch_interperror_bc(xy,xyY,bnodesX,bnodeY,norv)
% Impose the error values on boundary midpoints

% Coordinates of the boundary nodes and of boundary edge's midpoints
  allxbd_X = reshape( xy(bnodesX,1), size(bnodesX,1), 2);
  allybd_X = reshape( xy(bnodesX,2), size(bnodesX,1), 2);
  xybd_Y   = xyY(bnodeY, :);
  
% Compute boundary conditions for the given nodes
  [bc_firstNodeX]  = stoch_goafem_specific_bc(allxbd_X(:,1), allybd_X(:,1), norv);
  [bc_secondNodeX] = stoch_goafem_specific_bc(allxbd_X(:,2), allybd_X(:,2), norv);
  [bc_nodeY]       = stoch_goafem_specific_bc(xybd_Y(:,1),   xybd_Y(:,2),   norv);

% Extract the first "non-parametric" column (in case the b.c. are
% non-parametric, i.e., columns from 2 to norv+1 are zeros)
  bc_firstNodeX  = bc_firstNodeX(:,1);  
  bc_secondNodeX = bc_secondNodeX(:,1); 
  bc_nodeY       = bc_nodeY(:,1);

% Interpolated error
  error = bc_nodeY - 0.5 * (bc_firstNodeX + bc_secondNodeX);
  
end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [yp_err_el] = get_yp_errelem(evtY,yp_edges_vec,P)
%Recovers elementwise spatial indicators by square summing the edge
%indicators for all modes

% Here, P=1, since stochastic components have already been added 

% Get the matrix nel-by-3*P ypedgelem having per each row (element) the 
% correspoding edge-indicators (column) per each mode
  ypedgelem = zeros(size(evtY,1),3*P);
  
  evtYvec = reshape(evtY',3*size(evtY,1),1);
  for k = 1:P
      ypedgelem_k = yp_edges_vec(evtYvec,k);
      % Update ypedgelem for the k-th mode
      ypedgelem(:,1+3*(k-1):3*k) = reshape(ypedgelem_k,3,length(ypedgelem_k)/3)';
  end  
 
% Compute the elementwise estimates by square summing the 3*P edge 
% indicators per element
  yp_err_el = sqrt( sum(ypedgelem.^2, 2) );
  
end % end child function