function [intres_primal,intres_dual] = stoch_goafem_intres_p1_with_p1(xy,xl_s,yl_s,evt,...
                                       ugal,zgal,indset,P,G,norv,noarv,KL_DATA,subdivPar)
%STOCH_GOAFEM_INTRES_P1_WITH_P1 computes YP elementwise interior residuals for both primal and dual solutions
%
% [intres_primal,intres_dual] = stoch_goafem_intres_p1_with_p1(xy,xl_s,yl_s,evt,...
%                               ugal,zgal,indset,P,G,norv,noarv,KL_DATA,subdivPar)
% input:
%                 xy     vertex coordinate vector
%          xl_s,yl_s     local coordinates of sub-elements
%                evt     element mapping matrix
%               ugal     stochastic P1 primal solution vector
%               zgal     stochastic P1 dual solution vector
%             indset     index set of polynomial degrees
%                  P     length of the index set
%                  G     (1 x (noarv+1)) cell of G-matrices
%               norv     number of random variables
%              noarv     number of active random variables
%            KL_DATA     data related to KL-expansion
%          subdivPar     red or bisec3 uniform sub-division flag
%
% output: 
%      intres_primal     interior residuals (primal problem)
%        intres_dual     interior residuals (dual problem)
%
% The function computes the elementwise 'internal' residuals of local 
% residual problems. For the primal solution this is given by
%
% res_int := \int_Gamma\int_K ( f0(x) + div(\vec{f}) )    v(x,y) dxdpiy  
%          + \int_Gamma\int_K div( a(x,y)\grad uXP(x,y) ) v(x,y) dxdpiy 
%
% For the dual solution, in the expression above there would be g0, \vec{g} and 
% zXP, respectively.
%
% Function(s) called:    triangular_gausspoints
%                        subelt_transf
%                        tderiv
%                        stoch_goafem_gauss_gradcoeff
%                        stoch_goafem_gauss_L2
%                        stoch_goafem_gauss_divH1
%                        stoch_rhs_multiplier
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);    % Number of vertices
  nel  = size(evt,1);   % Number of elements

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);

% Recover local coordinates and local solutions
  xl_v   = zeros(nel,3); 
  yl_v   = zeros(nel,3); 
  usol_v = zeros(nel,3*P);
  zsol_v = zeros(nel,3*P);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2);
      for k = 1:P
          usol_v(:,ivtx + 3*(k-1)) = ugal(nvtx*(k-1) + evt(:,ivtx));
          zsol_v(:,ivtx + 3*(k-1)) = zgal(nvtx*(k-1) + evt(:,ivtx));
      end
  end
  
% Allocate memory 
  intres_primal = zeros(nel,3*P);
  intres_dual = zeros(nel,3*P);
  bdem     = zeros(nel,4,3,3,noarv+1); 
  bde      = zeros(nel,3,3,noarv+1);
  fdem     = zeros(nel,4,3,noarv+1);
  gdem     = zeros(nel,4,3,noarv+1);
  fde      = zeros(nel,3,noarv+1);
  gde      = zeros(nel,3,noarv+1);
  xl_m     = zeros(nel,3);
  yl_m     = zeros(nel,3);
  
% Loop over sub-elements
  for subelt = 1:4
      % Recover local coordinates
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end    
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);       
          [sigptloc,tigptloc] = subelt_transf(sigpt,tigpt,subelt,subdivPar);
          %
          % Evaluate derivatives
          [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigptloc,tigptloc,xl_v,yl_v);
          [jac_m,~,phi_m,~,~] = tderiv(sigpt,tigpt,xl_m,yl_m);
          %
          % Gradient of the diffusion coefficients
          [dcoeffdx_m,dcoeffdy_m] = stoch_goafem_gauss_gradcoeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % L2 parts of the sources F and G
          [frhs_m] = stoch_goafem_gauss_L2(sigpt,tigpt,xl_m,yl_m,norv,1);
          [grhs_m] = stoch_goafem_gauss_L2(sigpt,tigpt,xl_m,yl_m,norv,2);
          %
          % Divergence of the H1 parts of the sources F and G
          [fdiv_m] = stoch_goafem_gauss_divH1(sigpt,tigpt,xl_m,yl_m,norv,1);
          [gdiv_m] = stoch_goafem_gauss_divH1(sigpt,tigpt,xl_m,yl_m,norv,2);
          %
          % Loop over random variables
          for m = 0:noarv
              % Loop over sub-element vertices
              for j = 1:3  
                  % Compute div(a*grad)-contribution = grad(a)*grad(u_h)
                  % Loop over element vertices
                  for i = 1:3  
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * dcoeffdx_m(:,m+1) .* dphidx_v(:,i) .* phi_m(:,j) .* invjac_v(:) .* jac_m(:);
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * dcoeffdy_m(:,m+1) .* dphidy_v(:,i) .* phi_m(:,j) .* invjac_v(:) .* jac_m(:);
                  end
                  %                
                  % Compute rhs-contribution from the source f
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) + wght * frhs_m(:,m+1) .* phi_m(:,j) .* jac_m(:); % L2-part
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) + wght * fdiv_m(:,m+1) .* phi_m(:,j) .* jac_m(:); % div-part
                  %
                  % Compute rhs-contribution from the source g
                  gdem(:,subelt,j,m+1) = gdem(:,subelt,j,m+1) + wght * grhs_m(:,m+1) .* phi_m(:,j) .* jac_m(:); % L2-part
                  gdem(:,subelt,j,m+1) = gdem(:,subelt,j,m+1) + wght * gdiv_m(:,m+1) .* phi_m(:,j) .* jac_m(:); % div-part
              end
              % end mid-edge hat functions loop
          end
          % end random variables loop
      end
      % end Gauss points loop
  end
% end sub-element loop  

% Manual assembly of sub-element contributions
  if subdivPar == 1
      %
      % Red sub-division
      % 
      for m = 0:noarv
          % First edge
          bde(:,1,1,m+1) = bdem(:,2,3,1,m+1) + bdem(:,3,2,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,1,2,m+1) = bdem(:,2,3,2,m+1) + bdem(:,3,2,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,1,3,m+1) = bdem(:,2,3,3,m+1) + bdem(:,3,2,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,1,m+1)   = fdem(:,2,3,m+1)   + fdem(:,3,2,m+1)   + fdem(:,4,1,m+1);
          gde(:,1,m+1)   = gdem(:,2,3,m+1)   + gdem(:,3,2,m+1)   + gdem(:,4,1,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,3,1,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,3,1,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,3,1,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,3,1,m+1)   + fdem(:,4,2,m+1);
          gde(:,2,m+1)   = gdem(:,1,3,m+1)   + gdem(:,3,1,m+1)   + gdem(:,4,2,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,4,3,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,4,3,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,4,3,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,1,m+1)   + fdem(:,4,3,m+1);
          gde(:,3,m+1)   = gdem(:,1,2,m+1)   + gdem(:,2,1,m+1)   + gdem(:,4,3,m+1);
      end     
  else
      %
      % Bisec3 sub-division
      % 
      for m = 0:noarv  %norv
          % First edge
          bde(:,1,1,m+1) = bdem(:,3,2,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,1,2,m+1) = bdem(:,3,2,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,1,3,m+1) = bdem(:,3,2,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,1,m+1)   = fdem(:,3,2,m+1)   + fdem(:,4,2,m+1);
          gde(:,1,m+1)   = gdem(:,3,2,m+1)   + gdem(:,4,2,m+1);    
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,3,3,1,m+1) + bdem(:,4,1,1,m+1); 
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,3,3,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,3,3,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,2,1,m+1)   + fdem(:,3,3,m+1)   + fdem(:,4,1,m+1);
          gde(:,2,m+1)   = gdem(:,1,3,m+1)   + gdem(:,2,1,m+1)   + gdem(:,3,3,m+1)   + gdem(:,4,1,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,2,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,2,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,2,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,2,m+1);
          gde(:,3,m+1)   = gdem(:,1,2,m+1)   + gdem(:,2,2,m+1);
      end
  end
  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);

% -----------------------------------------------------------------------------
% Assemble interior residuals from rhs-contributions
% -----------------------------------------------------------------------------
  for m = 0:noarv
      %
      % Assemble interior residual from source f
      ind_m = rhs_ind(1,m+1);
      if ind_m>0
         intres_primal(:,(3*(ind_m-1)+1):(3*ind_m)) = intres_primal(:,(3*(ind_m-1)+1):(3*ind_m)) + fde(:,:,m+1) * beta(1,m+1);
         intres_dual(:,(3*(ind_m-1)+1):(3*ind_m))   = intres_dual(:,(3*(ind_m-1)+1):(3*ind_m))   + gde(:,:,m+1) * beta(1,m+1);
      end
      %
      % Assemble interior residuals from div(a*grad)-contributions
      [nzi,nzj,gval] = find(G{m+1});
      for t = 1:length(nzi)
          i = nzi(t); 
          j = nzj(t);
          for ii = 1:3
              for jj = 1:3
                  intres_primal(:,3*(i-1)+ii) = intres_primal(:,3*(i-1)+ii) + (gval(t)*bde(:,ii,jj,m+1)) .* usol_v(:,3*(j-1)+jj);
                  intres_dual(:,3*(i-1)+ii)   = intres_dual(:,3*(i-1)+ii)   + (gval(t)*bde(:,ii,jj,m+1)) .* zsol_v(:,3*(j-1)+jj);
              end
          end
      end
      
  end
  
end % end function