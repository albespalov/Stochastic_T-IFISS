%STOCH_GOAFEM_SETUP_AND_SOLVE sets up and solves the sGFEM linear system for both primal and dual problems
% 
% Variables computed and returned are:
%               G     stochastic G-matrices
%           u_gal     stochastic primal solution
%           z_gal     stochastic dual solution
%  var_sol_primal     variance of stochastic primal solution
%    var_sol_dual     variance of stochastic dual solution
%   energy_primal     energy norm of stochastic primal solution
%     energy_dual     energy norm of stochastic dual solution
%          G_ugal     computed quantity of interest (goal-functional)
%
% Currently only spatial approximation with P1 elements is implemented.
%
% Function(s) called: stoch_gmatricesx
%                     stoch_goafem_femp1_setup
%                     stoch_goafem_imposebcx
%                     p2_grid_generator
%                     stoch_goafem_femp2_setup
%                     stoch_est_minresx      
%                     stoch_variancex
%                     stoch_matvecx
% 
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  nvtx = size(xy,1);  % Number of vertices
  nel  = size(evt,1); % Number of elements

  fprintf('\nMesh info:');
  fprintf('\n   Number of vertices: %d',nvtx);  
  fprintf('\n   Number of elements: %d\n',nel);    
    
% Generate the G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);
  
% -------------------------------------------------------------------------  
% Setup matrices for P1 and P2 discretisations
% -------------------------------------------------------------------------
  setupmat = tic;
  if pmethod == 1
      fprintf('\nSetting up stochastic P1 diffusion matrices...');
      [Knbc,fnbc,gnbc] = stoch_goafem_femp1_setup(xy,evt,indset,P,norv,noarv,KL_DATA);    
      % Boundary conditions
      [K,fnew,gnew,u_gal,z_gal,dupl_intern] = stoch_goafem_imposebcx(Knbc,fnbc,gnbc,G,xy,bound,indset,P,norv,noarv);
      
  elseif pmethod == 2  
      % Generating the P2 grid
      [p2xy,p2evt,p2bound] = p2_grid_generator(xy,evt,bound);
      [Knbc,fnbc,gnbc] = stoch_goafem_femp2_setup(p2xy,p2evt,indset,P,norv,noarv,KL_DATA);
      % Boundary conditions
      [K,fnew,gnew,u_gal,z_gal,dupl_intern] = stoch_goafem_imposebcx(Knbc,fnbc,gnbc,G,p2xy,p2bound,indset,P,norv,noarv);
  end
  fprintf('done (%.5f sec)\n',toc(setupmat));

% Number of internal node
  nint = length(dupl_intern)/P;

% -------------------------------------------------------------------------      
% Solve the system
% -------------------------------------------------------------------------
  fprintf('MINRES solution of the linear systems...\n');  
% Extract the mean stiffness matrix
  Amean = K{1};
% Fast (LU factorisation) solver using LUPQ -------------------------------
  fprintf('LU(PQ) factorisation of K_0...'); 
  LUtime = tic; 
  [L,U,PP,QQ] = lu(Amean);
  fprintf('done (%.6f sec)\n',toc(LUtime));
  tol = 1e-10;    maxit = 99;
  apost = 0;      stopit = 0;    prob_type = 'sdiff';
  MA = 'm_sdiff'; aparams = struct('nint',nint,'L',PP\L,'U',U/QQ);
% -------------------------------------------------------------------------
  
% Minres solver for primal problem (internal nodes only)
  [uminres,resvec,emin,~,info] = stoch_est_minresx(G,K,fnew,...
                                 apost,stopit,maxit,tol,prob_type,MA,aparams);
                          
% Minres solver for dual problem (internal nodes only)
  [zminres,resvec_dual,emin_dual,~,info_dual] = stoch_est_minresx(G,K,gnew,...
                                 apost,stopit,maxit,tol,prob_type,MA,aparams);
                    
% Update computed Galerkin solutions (primal and dual)              
  u_gal(dupl_intern) = uminres;
  z_gal(dupl_intern) = zminres;
  
% NOTE: 
% - length(u_gal): overall number of dofs INCLUDING boundary nodes (per each mode)
% - length(uminres): number of the "internal" dofs, i.e., EXCLUDING boundary 
%   nodes(per each mode). This is the right number of dofs if homogeneous 
%   Dirichlet bcs are used
% The same for the dual solution.  
  
% -----------------------------------------------------------------------------  
% Plot (or not) the minres convergence  
% -----------------------------------------------------------------------------
  if iPlotConv
      if noarv > 0
          figure(13)
          inx = 0:info(4)-1;rx=9:9:info(4);
          if info(4) > 4
              semilogy(inx,sqrt(2)*resvec./emin,'-r');
              hold on;  semilogy(inx,resvec,'-b');  hold off;
              axis('square');
              xlabel('iteration number {\it k}');
              title('MINRES convergence history');
              h = legend('${\sqrt{2}/ \lambda_k^2}\> ||r_k||_{M_*}$','$||r_k||_{M_*}$');
              set(h,'Interpreter','latex');
          end
      end
  end

% -----------------------------------------------------------------------------
% Compute variances
% -----------------------------------------------------------------------------
  [var_sol_primal] = stoch_variancex(u_gal,P);    % Primal solution's variance
  [var_sol_dual]   = stoch_variancex(z_gal,P);    % Dual solution's variance

% -----------------------------------------------------------------------------
% Compute energy norms of Galerkin solutions
% -----------------------------------------------------------------------------
  [b_ref_primal] = stoch_matvecx(u_gal,G,Knbc);
  energy_primal  = sqrt(u_gal' * b_ref_primal);   % Primal solution's energy norm

  [b_ref_dual] = stoch_matvecx(z_gal,G,Knbc);
  energy_dual  = sqrt(z_gal' * b_ref_dual);       % Dual solution's energy norm
   
% -----------------------------------------------------------------------------
% Compute G(u)=G(u_gal) at current iteration
% -----------------------------------------------------------------------------  
% Note that B(u,z) = G(u), with u being the primal solution and z being the dual solution.
% Hence, G(u) = B(u,z) = u' * A * z;
  G_ugal = u_gal' * stoch_matvecx(z_gal,G,Knbc);  %=b_ref_dual
  
% -----------------------------------------------------------------------------
% Print data
% ----------------------------------------------------------------------------- 
  fprintf('<strong>Linear solver statistics:</strong>\n');
  fprintf('   Total ndof:         %g\n',length(uminres));%length(u_gal));
  fprintf('   Minimum eigenvalue: %5.3f\n',emin(end));
  fprintf('<strong>Stochastic parameters:</strong>\n');
  fprintf('   Active parameters:  %g\n',noarv);
  fprintf('   Polynomial degree: %2i\n',polyd);
  fprintf('<strong>Primal solution:</strong>\n');
  fprintf('   Maximum mean value: %8.3e\n',max(u_gal(1:nvtx)));      
  fprintf('   Maximum variance:   %8.3e\n',max(var_sol_primal));
  fprintf('   Energy norm:        %8.4e\n',energy_primal);
  fprintf('<strong>Dual solution:</strong>\n');
  fprintf('   Maximum mean value: %8.4e\n',max(z_gal(1:nvtx)));      
  fprintf('   Maximum variance:   %8.4e\n',max(var_sol_dual));  
  fprintf('   Energy norm:        %8.4e\n',energy_dual);
  fprintf('<strong>Goal-functional:</strong>       %8.4e\n',G_ugal);

% end scriptfile