%STOCH_DATA2PGFPLOTS3D creates .dat files to 3D plot using pgfplots package in latex 
%
% The function creates three .dat files:
% - meshevt.dat containing the evt matrix;
% - meshcoord.dat containing the xy matrix and a vector of zeros;
% - meshcoordfun.dat containing the xy matrix and the function to be plotted.
%
% Files are saved to: gohome/datafiles.
%
% The script works if in the workspace there are evt, xy, and the function
% which has to be saved. By function, we mean, for example, x_gal, var_sol,
% u_gal, and so on. Instructions to use these data file for plotting using
% pgfplots package are given below.
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  gohome; cd datafiles;

% ----------------------------------------------------------------------------
% Save element-map data (evt)
% ----------------------------------------------------------------------------
  fid = fopen('meshevt.dat','w');
  if fid == -1, error('Error opening file!\n'); end  
  fprintf(fid,'%d\t%d\t%d\n',(evt-1)');
  fclose(fid);
% NOTE that we write evt-1 as pgfplots needs nodes to start from 0

% ----------------------------------------------------------------------------
% Save coordinates (xy) to plot meshes
% ----------------------------------------------------------------------------
% In order to plot the meshes, we save the xy data structures containing
% nodes' coordinates and a vector of zeros, so that meshes are implicitly
% depicted as a function equal to 0 (to be viewed from top)
  datatriang = [xy, zeros(size(xy,1),1)];
  save meshcoord.dat datatriang -ASCII; 
  
% ----------------------------------------------------------------------------
% Save solutions, means, variances etc.
% ---------------------------------------------------------------------------- 
% For example:
% - x_gal mean;
% - var_sol variance;
% - u_gal primal solution (mean);
% - z_gal dual solution (mean);
% - var_sol_primal variance of primal solution;
% - var_sol_dual variance of dual solution...
  datafun = [xy, x_gal(1:size(xy,1))];
  save meshcoordfun.dat datafun -ASCII;
  
% ----------------------------------------------------------------------------
% INSTRUCTIONOS: how to use .dat files in pgfplots
% ----------------------------------------------------------------------------
% In the .tex file, with pgfplots2D plots of meshes and 3D plots of functions 
% can be produced in the follwing way.
% 
% EXAMPLE: PLOT OF SOME FUNCTION ---------------------------------------------
% %%%%%%%%%%% In the preamble
% \usepackage{pgfplots}
% \pgfplotsset{compat = 1.14}
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% \begin{tikzpicture} 
% \begin{axis}[
% width=6cm, 
% height=6cm,
% view={40}{28}, 
% % some colormap here, e.g.: colormap/bluered,%winter%viridis
% ymajorgrids=true, 
% xmajorgrids=true, 
% grid style=dashed, 
% % change ztick, e.g.: ztick={0,0.05,0.10,0.15,0.20}, zticklabel style={/pgf/number format/.cd,fixed},
% ]
% \addplot3 [patch,fill=white,opacity=0.9,patch table={path-to-meshevt.dat}] file {path-to-meshcoordfun.dat};
% \end{axis}
% \end{tikzpicture}
% ----------------------------------------------------------------------------
%
% EXAMPLE: PLOT OF A MESH ----------------------------------------------------
% %%%%%%%%%%% In the preamble
% \usepackage{pgfplots}
% \pgfplotsset{compat = 1.14}
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% \begin{tikzpicture} 
% \begin{axis}[
% width = 6cm, height=6cm,
% view={0}{90}, % to view the plot from above
% colormap/bluered,
% ticks=none
% ]
% \addplot3 [patch,fill=white,opacity=0.9,patch table={path-to-meshevt.dat}] file {path-to-meshcoord.dat};
% \end{axis}
% \end{tikzpicture}
% ----------------------------------------------------------------------------

% end scriptfile