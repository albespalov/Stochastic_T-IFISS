function [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%STOCH_EIGEL_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%   
% [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%   
% input:
%            x     x coordinate vector
%            y     y coordinate vector 
%          nel     number of elements  
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion (6-fields structure or zero)
%
% output:
%  [dadx,dady]     derivatives (gradient) of the stochastic coefficient
%       
% This expansion is discussed in:
% Eigel, Gittelson, Schwab, Zander, Adaptive stochastic FEM, Comput. Methods 
% Appl. Mech. Engrg. 270:247-269, 2014.
%
% This function is a copy of original SIFISS function (DJS; 1 April 2015).
% 
% See also STOCH_EIGEL_COEFF
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Initialisation
  dadx = zeros(nel,norv+1);
  dady = zeros(nel,norv+1);

% Set da_0/dx and da_0/dy
  dadx(:,1) = zeros(nel,1);
  dady(:,1) = zeros(nel,1);

% Set decay rate of stochastic coefficients
  sdecay = KL_DATA.decay;
  if sdecay == 1
      % Slow decay
      sigma = 2; alpha=0.547;
  else
      % Fast decay
      sigma = 4; alpha=0.832;
  end

% Set da_m/dx and da_m/dy
  for m = 1:norv
      km          = floor(-0.5e0+sqrt(0.25e0+2*m));
      beta_x      = m - km*(km+1)/2; 
      beta_y      = km-beta_x;
      dadx(:,m+1) = - 2*pi*beta_x*alpha / (m^(sigma)) * sin(2*pi*beta_x*x) .* cos(2*pi*beta_y*y);
      dady(:,m+1) = - 2*pi*beta_y*alpha / (m^(sigma)) * cos(2*pi*beta_x*x) .* sin(2*pi*beta_y*y);
  end
  
end % end function