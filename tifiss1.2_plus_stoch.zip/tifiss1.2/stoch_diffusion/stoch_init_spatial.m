%STOCH_INIT_SPATIAL generates spatial grid
%
% The domains currently available are the square, L-shaped, and crack domains.
%
% Variables returned are:
%       dom_type      domain type (used by SRECALL)
%            evt      element mapping matrix
%             xy      vertex coordinate matrix 
%        eboundt      element boundary mapping matrix
%          bound      boundary vertices vector
%     totalnodes      total vertices vector
%       interior      interior vertices vector
%            eex      element connectivity array
%            tve      edge location array
%            els      elementwise edge lengths
%
% Function(s) called: square_domain
%                     p1grid
%                     ell_domain
%                     ell_domain_unstructured
%                     crack_domain
%                     adjust_unstruct_mesh
%                     plot_mesh
%                     tedgegen
%                     p1grid_detail_space
%                     
%   TIFISS scriptfile: LR; 24 January 2019
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% -------------------------------------------------------------------------  
% Domain generation 
% -------------------------------------------------------------------------
  fprintf('\n<strong>Grid generation for a </strong>');
  if dom_type == 1
      % ------------------------------------------------------------------
      % Unit square domain (0,1)^2; structured mesh
      % ------------------------------------------------------------------
      fprintf('<strong>unit square domain</strong>\n');
      square_domain_fa(1,1);
      load square_grid;
      [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
         
  elseif dom_type == 2
      % ------------------------------------------------------------------
      % Reference square domain (-1,1)^2; structured mesh
      % ------------------------------------------------------------------
      fprintf('<strong>reference square domain</strong>\n');     
      square_domain_fa(2,0);
      load square_grid; 
      [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
  
  elseif dom_type == 3
      % ------------------------------------------------------------------
      % L-shaped domain (-1,1)^2 \ (-1,0]^2
      % ------------------------------------------------------------------
      fprintf('<strong>L-shaped domain</strong>');
      mesh_type = default('\nStructured/unstructured mesh 1/2 (default 1)',1);
      if mesh_type == 1
          ell_domain_fa;
          load ell_grid;
          [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
      elseif mesh_type == 2
          ell_domain_unstructured_fa;
          load ell_grid;
          % For unstructured meshes reorder the nodes of each element in evt
          [evt,xy,eboundt] = adjust_unstruct_mesh(evt,xy,eboundt);
      else
          error('Invalid mesh type'); 
      end
        
  elseif dom_type == 4
      % ------------------------------------------------------------------
      % Large crack domain (-1,1)^2 \ (-1,0)x{0} (crack on the left)
      % ------------------------------------------------------------------
      fprintf('<strong>crack domain</strong>');
      crack_domain_large;
      load crack_grid;
  end

% Plot the starting mesh
  plot_mesh(evt,xy); 

% Total nodes and interior nodes
  totalnodes = 1:size(xy,1);
  interior = totalnodes(~ismember(totalnodes,bound));
                     
% Compute edge connections for the mesh
  [eex,tve,els] = tedgegen(xy,evt); 
 
% Compute the detail space Y for the initial space X 
  [evtY,xyY,boundY,Ybasis] = p1grid_detail_space(xy,evt);

% end scriptfile  