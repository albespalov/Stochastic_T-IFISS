function [Q_indset] = stoch_detail_indset(indset,polyd,norv,noarv,extra_rv,pm_choice)
%STOCH_DETAIL_INDSET computes the detail index set from the current index set
%
%   [Q_indset] = stoch_detail_indset(indset,polyd,norv,noarv,extra_rv,pm_choice)
%
%   input:
%            indset     index set of polynomial degrees
%             polyd     maximum polynomial degree in the index set
%              norv     maximum number of random variables allowed
%             noarv     number of active random variables
%          extra_rv      number of extra random variables activated in the detail index set
%         pm_choice     method for enriching the polynomial space
%
%   output:
%          Q_indset     'detail' index set
% 
% Function(s) called:   stoch_indset
%                       stoch_adapt_new_indset  
%
% This function is called by STOCH_DIFFPOST_P1_XQ from the non-adaptive driver 
% for the error estimation STOCH_DIFFPOST.
% The function allows the detail index set to be computed from p, M, pM 
% enrichment type.
% 
% See also STOCH_ADAPT_NEW_INDSET, STOCH_GMATRICESX
%
%   TIFISS function: LR; 05 January 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi
                    
% -------------------------------------------------------------------------
% Set the new index set depending on pm_choice
% -------------------------------------------------------------------------
  if pm_choice == 1
      % New index set by increasing the polynomial degree
      [new_indset] = stoch_indset(polyd+1,noarv);
      new_indset = [new_indset,zeros(length(new_indset),norv-noarv)];
      %fprintf('detail space polynomial degree is %d\n',polyd+1);
           
  elseif pm_choice == 2
      % Check that noarv < norv
      if noarv >= norv
          error('Error: increase the total number of random variables!')
      end
      % New index set by increasing the number of active random variables
      [new_indset] = stoch_indset(polyd,noarv+extra_rv);
      new_indset = [new_indset,zeros(length(new_indset),norv-noarv-extra_rv)];
      %fprintf('detail space is based on %d random variables\n',noarv+1);
      
  elseif pm_choice == 3
      % New index set by adding one active random variable and the 
      % 'neighbours' indices to the indices in the current indset
      [new_indset] = stoch_adapt_new_indset(indset,noarv,extra_rv);
      %fprintf('detail space is based on %d random variables and on neighbouring indices\n',noarv+1);
      
  end
  
% Find the 'difference' between the new and original index set
% -------------------------------------------------------------------------
  Q_indset = new_indset(~ismember(new_indset,indset,'rows'),:);
  % this is faster than setdiff(new_indset,indset,'rows');
                                                
end % end fuction                                                             