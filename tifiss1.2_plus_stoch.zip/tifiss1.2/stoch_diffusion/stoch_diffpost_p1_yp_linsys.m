function [yp_elerr,yp_ederr,yp_err_est] = stoch_diffpost_p1_yp_linsys(xy,evt,eboundt,...
                              evtY,xyY,boundY,Ybasis,xgal,G,P,norv,noarv,KL_DATA,subdivPar)
%STOCH_DIFFPOST_P1_YP_LINSYS computes hierarchical YP-estimate solving the associated (fully) assembled linear system
%
% [yp_elerr, yp_ederr, yp_err_est] = stoch_diffpost_p1_yp_linsys(xy,evt,eboundt,...
%                      evtY,xyY,boundY,Ybasis,xgal,G,P,norv,noarv,KL_DATA,subdivPar)
%
% input:
%               xy     vertex coordinate vector  
%              evt     element mapping matrix
%          eboundt     element edge boundary matrix
%             evtY     element mapping matrix for midpoints
%              xyY     vertex coordinate vector for midpoints
%             xgal     stochastic P1 solution vector
%                G     (1 x (noarv+1)) cell of G-matrices
%                P     length of the index set
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%        subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%         yp_elerr     vector of YP element indicators
%         yp_ederr     vector of YP edge indicators
%       yp_err_est     global YP error estimate
%
% V_{YP}-estimator: employs elementwise P1-bubbles for the edge midpoints 
% (for both red and bisec3 uniform sub-division) tensorised with the 
% original set of polynomials.
%
% The function solves the discrete problem for the eYP estimator:
%
%   B0(eYP,v) = F(v) - B(uXP,v),     for all v \in VYP,        (1)
%
% NOTE that given the midpoint-solutions (edge solutions) to problem (1) per 
% each node
% - the midpoint indicators (edge indicators) are computed by square 
%   summation; see below;
% - the element indicators are computed by definition of local B0-norms
%   restricted to single elements.
%
% Function(s) called: stoch_diffpost_p1_yp_detcontrib
%                     stoch_specific_bc
%                      
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nvtx = size(xy,1);      % Number of vertices  (i.e., number of X-basis functions) 
  nyb  = size(Ybasis,1);  % Number of midpoints (i.e., number of Y-basis functions (boudary ones included))
  
% -----------------------------------------------------------------------------
% STEP 1: elementwise contributions from uniform red/bisec3 refinement type
% -----------------------------------------------------------------------------
  [ade,bde,~,fde] = stoch_diffpost_p1_yp_detcontrib(xy,evt,norv,noarv,KL_DATA,subdivPar);

% -----------------------------------------------------------------------------
% STEP2: assembling non-parametric LHS matrix
% -----------------------------------------------------------------------------
  A = sparse(nyb,nyb);
  for i = 1:3
      % Indices for Y-basis
      idxY1 = evtY(:,i);	 
      for j = 1:3
          % Indices for Y-basis
          idxY2 = evtY(:,j);
          % Assembling
          A = A + sparse(idxY1, idxY2, ade(:,i,j), nyb, nyb);
      end
  end
     
% -----------------------------------------------------------------------------                       
% STEP 3: assembling F(v) for all basis \phi_j*P_\nu in VYP
% -----------------------------------------------------------------------------
% Extract elements and associated edges for Y-basis functions
  elems = Ybasis(:,[1,2]);   
  edges = Ybasis(:,[3,4]);
  
% Indices: elements, Y-basis, ones.
% Note the last indices are 'ones' as we need only fde(:,:,1) since the source 
% f is deterministic 
  idx1 = {elems(:,1), edges(:,1), ones(size(elems,1),1)}; 
  idx2 = {elems(:,2), edges(:,2), ones(size(elems,1),1)};

% Summing deterministic contributions (primal problem) 
  ff = fde( sub2ind(size(fde) , idx1{:}) ) + fde( sub2ind(size(fde) , idx2{:}) );
% For a Y-basis on the boundary, we have to halve the contributions since in the 
% above line we doubled the contribution coming from the only boundary element
  ff(boundY) = ff(boundY) ./ 2;
    
% Since the source is deterministic, F(v) = kron(g0,ff) = (ff,0,0,...)', where 
% g0 is the first column of the matrix G0, i.e., g0 = (1,0,0,...)'. 

% Keep F(v) in a nyb-by-P matrix  
  Fv = [ff, sparse(nyb,P-1)];

% -----------------------------------------------------------------------------                                
% STEP 4: assembling B(uXP,v) for all basis \phi_j*P_\nu in VYP
% -----------------------------------------------------------------------------
% The terms B(uXP,v) will be a nyb-by-P vector

% Reshape xgal vector solution in matrix form for efficient kronecker product 
  X = reshape(xgal,nvtx,P);

% Matrix Bx for assembling B(uXP,v) for each v in VYP
  Bx = sparse(nyb,P);
                    
% Loop over random variables
  for m = 0:noarv
      %
      % Allocate memory for current noarv
      Km = sparse(nyb,nvtx);
      %
      % Assembling deterministic matrix
      for kYb = 1:3
          % Indices for Y-basis
          indY = evtY(:,kYb);	 
          for kXb = 1:3
              % Indices for X-basis
              indX = evt(:,kXb);
              % Assembling
              Km = Km + sparse(indY, indX, bde(:, kYb, kXb, m+1), nyb, nvtx);
          end
      end
      %
      % NOTE that if the problem has homogeneous bcs, then such conditions 
      % for the corresponding X-basis on the boundary should be imposed, 
      % i.e, Km(:,bound) = 0. However, this is unnecessary as Km will be
      % multiplied by X which already contains zeros in X-boundary positions.
      %
      % The global Kronecker matrix
      %
      %         [ kron(G{0},K{m}) + sum_m^M kron(G{m},K{m}) ] * x_gal
      %
      % is assembled by summing its component matrix contributions
      %
      %                kron(G{m},K{m}) * x_gal
      %
      % for the current value of m \geq 0. 
      % Efficient assembling avoiding 'kron' for the matrix kron(G{m},K{m}) 
      % saving both memory and time; note that there should be G' but the 
      % G-matrices are symmetric;      
      Bx = Bx + ( Km * X * G{m+1} );
  end        
  
% Global rhs of the error problem: F(v) - B(uXP,v)
  rhs = Fv - Bx;
  
% -----------------------------------------------------------------------------  
% STEP 5: imposing interpolated error as Dirichlet boundary conditions 
% -----------------------------------------------------------------------------                                
  [rhs] = diffpost_nonzerobc(evt,evtY,xy,xyY,boundY,eboundt,A,rhs,P,norv);

% -----------------------------------------------------------------------------
% STEP 6: solving the assembled system (for interior nodes)
% -----------------------------------------------------------------------------
% The final ey_edsol_primal/dual contains the error-solution at each midpoint.
  yp_edsol = zeros(nyb,P);

% Set of interior midpoints 
  interiorY = 1:boundY(1)-1;
   
% Solving the linear systems for interior positions;
% NOTE that there should be G{1}', but G-matrices are symmetric;
  yp_edsol(interiorY,:) = A(interiorY,interiorY) \ rhs(interiorY,:) / G{1};

% Update the error values in boundary-midpoints position
  yp_edsol(boundY,:) = rhs(boundY,:);

% -----------------------------------------------------------------------------  
% STEP 7: computing the edge indicators (midpoint-indicators)
% -----------------------------------------------------------------------------
  yp_ederr = sqrt( sum( yp_edsol.^2, 2) ) ;

% -----------------------------------------------------------------------------
% STEP 8: recover the element indicators from edge indicators
% -----------------------------------------------------------------------------  
  [yp_elerr] = get_yp_errelem(ade,evtY,yp_edsol,P);
  
% -----------------------------------------------------------------------------
% STEP 9: global estimate ||yperr||_B0^2 = B0(yperr,yperr)
% -----------------------------------------------------------------------------
% Primal error problem
  sol = reshape(yp_edsol, nyb*P, 1);
  ff  = reshape(rhs,      nyb*P, 1);
  yp_errest_sq = sol' * ff;
  
% Compute the global estimate ||yperr||_B0 = B0(yperr,yperr)^(1/2)
  yp_err_est = full( sqrt( yp_errest_sq ) );

end  % end function


% -----------------------------------------------------------------------------  
% Child function
% -----------------------------------------------------------------------------     
function [rhs] = diffpost_nonzerobc(evt,evtY,xy,xyY,boundY,eboundt,K,rhs,P,norv)
%Imposes Dirichlet boundary conditions on boundary midpoints
  
  interiorY = 1:boundY(1)-1;

% -----------------------------------------------------------------------------
% Extract boundary elements with boundary edges respectively = 1, 2, and 3
% ----------------------------------------------------------------------------- 
  beled1 = eboundt( eboundt(:,2)==1 , 1);
  beled2 = eboundt( eboundt(:,2)==2 , 1);
  beled3 = eboundt( eboundt(:,2)==3 , 1);
   
% -----------------------------------------------------------------------------
% Extract boundary nodes/midpoints and compute the error
% -----------------------------------------------------------------------------
  node1    = evt ( beled1, [2 3]);   % nodes of the 1st boundary edges (columns 2,3 of evt)
  midp1    = evtY( beled1, 1);       % midpoints on 1st boundary edges (column 1 of evtY)
  [error1] = stoch_interperror_bc(xy,xyY,node1,midp1,norv);
  
  node2    = evt ( beled2, [3 1]);   % nodes of the 2nd boundary edges (columns 3,1 of evt)
  midp2    = evtY( beled2, 2);       % midpoints on 2nd boundary edges (column 2 of evtY)
  [error2] = stoch_interperror_bc(xy,xyY,node2,midp2,norv);
  
  node3    = evt ( beled3, [1 2]);   % nodes of the 3rd boundary edges (columns 1,2 of evt)
  midp3    = evtY( beled3, 3);       % midpoints on 3rd boundary edges (column 3 of evtY)
  [error3] = stoch_interperror_bc(xy,xyY,node3,midp3,norv);
  
% -----------------------------------------------------------------------------
% Vector of interpolated error on boundary midpoints
% -----------------------------------------------------------------------------
  miderrors = sortrows([midp1, error1; midp2, error2; midp3, error3],1);
  detbcY = miderrors(:,2);
  bcY    = [detbcY, zeros(length(detbcY),P-1)];
% Note that we add column of zeros (as bc are non parametric) for consistency 

% -----------------------------------------------------------------------------
% Update the rhs in the interior-midpoint positions
% -----------------------------------------------------------------------------
% We have to do the following:
%
%   rhs(interiorY,:) = rhs(interiorY,:) - kron(G{1},K(interiorY,boundY)) * bcY;
%
% Avoid the assembling of the kron matrix, saving both memory and time: 
% look at Nagy's lecture for efficient kronecker products in this case;
  rhs(interiorY,:) = rhs(interiorY,:) - ( K(interiorY,boundY) * bcY * eye(P) );
% NOTE that this update for the RHS in interior positions is a nIntY-by-P matrix  

% Update the rhs values in boundary-midpoints position with the imposed error
  rhs(boundY,:) = bcY; 

end % end child function
 

% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [error] = stoch_interperror_bc(xy,xyY,bnodesX,bnodeY,norv)
% Impose the error values on boundary midpoints

% Coordinates of the boundary nodes and of boundary edge's midpoints
  allxbd_X = reshape( xy(bnodesX,1), size(bnodesX,1), 2);
  allybd_X = reshape( xy(bnodesX,2), size(bnodesX,1), 2);
  xybd_Y   = xyY(bnodeY, :);
  
% Compute boundary conditions for the given nodes
  [bc_firstNodeX]  = stoch_specific_bc(allxbd_X(:,1), allybd_X(:,1), norv);
  [bc_secondNodeX] = stoch_specific_bc(allxbd_X(:,2), allybd_X(:,2), norv);
  [bc_nodeY]       = stoch_specific_bc(xybd_Y(:,1),   xybd_Y(:,2),   norv);

% Extract the first "non-parametric" column (in case the b.c. are
% non-parametric, i.e., columns from 2 to norv+1 are zeros)
  bc_firstNodeX  = bc_firstNodeX(:,1);  
  bc_secondNodeX = bc_secondNodeX(:,1); 
  bc_nodeY       = bc_nodeY(:,1);

% Interpolated error
  error = bc_nodeY - 0.5 * (bc_firstNodeX + bc_secondNodeX);
  
end % end child function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [yp_elerr] = get_yp_errelem(ade,evtY,yp_ederr,P)
%Recovers elementwise B_0^2 energy norms
  
  nel      = size(evtY,1); % Number of elements
  errloc   = zeros(nel,3);
  elerr_sq = zeros(nel,1);
  
% Loop over modes  
  for mu = 1:P   
      % Rearranging eYP nodal values elementwise
      for imid = 1:3
          errloc(:,imid) = yp_ederr(evtY(:,imid),mu);
      end 
      % Computing elementwise B_0^2 energy norms
      for imid = 1:3          
          for jmid = 1:3
              elerr_sq(:) = elerr_sq(:) + errloc(:,imid) .* ade(:,imid,jmid) .* errloc(:,jmid);
          end  
      end 
  end
  
% B0 energy norms
  yp_elerr = sqrt( elerr_sq );
    
end % end child function 