function [coef,lambda_min,lambda_max] = stoch_est_ritz(H,iH,prob_type)
% STOCH_EST_RITZ determines adaptive stopping criteria for STOCH_EST_MINRES
%  [coef,lambda_min,lambda_max] = stoch_est_ritz(H,ih,prob_type);
%   input
%                H      Lanczos matrix
%               iH      current dimension
%        prob_type      stochastic problem identifier 
%   output
%             coef     stopping criteria coefficient
%      lambda_min      minimum positive eigenvalue 
%      lambda_max      maximim positive eigenvalue 
% 
%   SIFISS function: DJS; 1 April 2015.
% Copyright (c) 2015 Pranjal, D.J. Silvester

checkcode=0;
eHh=sort(eig(H(1:iH,1:iH)));     % Ritz values              
[em,~] = size(eHh);
ieHh=find(eHh<0);
if isempty(ieHh)==0, 
fprintf('\n warning: negative Ritz value computed in stoch_est'); end
%
if checkcode,
% plot  Ritz values
figure(302)
plot(iH*ones(em,1),eHh,'ob');
title('Lanczos Ritz values')
xlabel('iteration number');  ylabel('eigenvalue estimates')
hold on
end
%
ieHh=find(eHh>0); lambda_min=min(eHh(ieHh)); lambda_max=max(eHh(ieHh));
if strncmp(prob_type,'sdiff',5),
coef=1/sqrt(lambda_min);
else, error('Illegal call to function stoch_est_ritz!'), end
return