function v=genindex(norv,p,head)
%GENINDEX builds index sets for multivariable polynomials
% [total_deg] = genindex(norv,p);
%   input
%          norv          number of random variables
%          p             polynomial degree
%   output
%          total_deg     index set for multivariable polynomials of total degree <=p
%
% This is a subroutine extracted from the SPQUAD code by Greg von Winckel
% available from the MATLAB CENTRAL FILE EXCHANGE.
% Note that it recursively calls itself.
%   SIFISS function: CEP; 21 May 2015.
%
% ------------------------------------------------------------------
% Orginal code:
% 
% SPQUAD
%   Computes the sparse grid quadrature abscissae and weights
%   on an orthotope/hyperrectangle using the Clenshaw-Curtis rule.
%
%   [X,W]=SPQUAD(DIM,ORD,AB)
%
%   Input Parameters:
%   DIM - number of dimensions
%   ORD - order of the integration rule
%   BPT - boundary points (Optional. Defaults to [-1,1]^dim)
% 
%   If used, BPT should be a 2 by DIM matrix containing the 
%   endpoints of the hyperrectangle in each column.
%
%   Example usage:
% 
%   f=@(x) (1+x(:,1)).*exp(x(:,2).*x(:,3))+(1+x(:,2)).*exp(x(:,3).*x(:,1))
%   [x,w]=spquad(3,4,[-1 0 2; 1 1 3]);
%   Q=w'*f(x);
%
%   written by Greg von Winckel - March 3, 2008
%   Contact: gregory(dot)von-winckel(at)uni-graz(dot)at

if norv==1
    v = p;
else
    v = cell2mat(arrayfun(@(j) genindex(norv-1, p-j, j), ...
                          (0:p)', 'UniformOutput', false));
end

if nargin>=3
    v = [head+zeros(size(v,1),1) v];
end


