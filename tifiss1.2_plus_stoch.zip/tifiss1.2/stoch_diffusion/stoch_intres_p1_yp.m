function [intres] = stoch_intres_p1_yp(xy,xl_s,yl_s,evt,p1sol,indset,P,G,norv,noarv,KL_DATA,subdivPar)
%STOCH_INTRES_P1_YP computes YP elementwise interior residuals for P1 stochastic Galerkin solution
%
% [intres] = stoch_intres_p1_yp(xy,xl_s,yl_s,evt,p1sol,indset,P,G,norv,noarv,KL_DATA,subdivPar)
%
% input:
%                 xy     vertex coordinate vector
%          xl_s,yl_s     local coordinates of "criss-cross" sub-elements
%                evt     element mapping matrix
%              p1sol     stochastic P1 solution vector
%             indset     index set of polynomial degrees
%                  P     length of the index set
%                  G     (1 x (noarv+1)) cell of G-matrices
%               norv     number of random variables
%              noarv     number of active random variables
%            KL_DATA     data related to KL-expansion
%          subdivPar     red or bisec3 uniform sub-division flag
%
% output: 
%             intres     interior residuals
%
% The function computes the 'internal' residuals of local residual problems:
%
% intres := F(v) + \int_Gamma\int_K div(a(x,y)\grad uXP(x,y))v(x,y) dx dpiy,
%
% Function(s) called:    triangular_gausspoints
%                        subelt_transf
%                        tderiv
%                        stoch_gauss_gradcoeff
%                        stoch_gauss_source
%                        stoch_rhs_multiplier
%
% See also INTRES_P1_WITH_P1
% 
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nvtx = size(xy,1);  % Number of vertices
  nel  = size(evt,1); % Number of elements

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);

% Recover local coordinates and local solution
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3); 
  sl_v = zeros(nel,3*P);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy( evt(:,ivtx), 1);
      yl_v(:,ivtx) = xy( evt(:,ivtx), 2);
      for k = 1:P
          sl_v(:,ivtx + 3*(k-1)) = p1sol(nvtx*(k-1) + evt(:,ivtx));
      end
  end
  
% Allocate memory 
  intres = zeros(nel,3*P);
  bdem   = zeros(nel,4,3,3,noarv+1);
  bde    = zeros(nel,3,3,noarv+1);
  fdem   = zeros(nel,4,3,noarv+1);
  fde    = zeros(nel,3,noarv+1);
  xl_m   = zeros(nel,3);
  yl_m   = zeros(nel,3);
  
% Loop over sub-elements
  for subelt = 1:4
      % Recover local coordinates
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end    
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);       
          [sigptloc,tigptloc] = subelt_transf(sigpt,tigpt,subelt,subdivPar);
          %
          % Evaluate derivatives
          [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigptloc,tigptloc,xl_v,yl_v);
          [jac_m,~,phi_m,~,~] = tderiv(sigpt,tigpt,xl_m,yl_m);
          %
          % Gradient of the diffusion coefficients
          [dcoeffdx_m,dcoeffdy_m] = stoch_gauss_gradcoeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % Source f
          [rhs_m] = stoch_gauss_source(sigpt,tigpt,xl_m,yl_m,norv);
          %
          % Loop over random variables
          for m = 0:noarv
              % Loop over sub-element vertices
              for j = 1:3  
                  % Compute div(a*grad)-contribution = grad(a)*grad(u_h)
                  % Loop over element vertices
                  for i = 1:3  
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * dcoeffdx_m(:,m+1) .* dphidx_v(:,i) .* phi_m(:,j) .* invjac_v(:) .* jac_m(:);
                      bdem(:,subelt,j,i,m+1) = bdem(:,subelt,j,i,m+1) + wght * dcoeffdy_m(:,m+1) .* dphidy_v(:,i) .* phi_m(:,j) .* invjac_v(:) .* jac_m(:);
                  end
                  %
                  % Compute rhs-contribution from the source f
                  fdem(:,subelt,j,m+1) = fdem(:,subelt,j,m+1) + wght * rhs_m(:,m+1) .* phi_m(:,j) .* jac_m(:);
              end
              % end mid-edge hat functions loop
          end
          % end random variables loop
      end
      % end Gauss points loop
  end
% end sub-element loop  

% Manual assembly of sub-element contributions
  if subdivPar == 1
      %
      % Red sub-division
      % 
      for m = 0:noarv
          % First edge
          bde(:,1,1,m+1) = bdem(:,2,3,1,m+1) + bdem(:,3,2,1,m+1) + bdem(:,4,1,1,m+1);
          bde(:,1,2,m+1) = bdem(:,2,3,2,m+1) + bdem(:,3,2,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,1,3,m+1) = bdem(:,2,3,3,m+1) + bdem(:,3,2,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,1,m+1)   = fdem(:,2,3,m+1)   + fdem(:,3,2,m+1)   + fdem(:,4,1,m+1);
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,3,1,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,3,1,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,3,1,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,3,1,m+1)   + fdem(:,4,2,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,4,3,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,4,3,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,4,3,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,1,m+1)   + fdem(:,4,3,m+1);
      end
       
  else
      %
      % Bisec3 sub-division
      % 
      for m = 0:noarv  %norv
          % First edge
          bde(:,1,1,m+1) = bdem(:,3,2,1,m+1) + bdem(:,4,2,1,m+1);
          bde(:,1,2,m+1) = bdem(:,3,2,2,m+1) + bdem(:,4,2,2,m+1);
          bde(:,1,3,m+1) = bdem(:,3,2,3,m+1) + bdem(:,4,2,3,m+1);
          fde(:,1,m+1)   = fdem(:,3,2,m+1)   + fdem(:,4,2,m+1);    
          % Second edge
          bde(:,2,1,m+1) = bdem(:,1,3,1,m+1) + bdem(:,2,1,1,m+1) + bdem(:,3,3,1,m+1) + bdem(:,4,1,1,m+1); 
          bde(:,2,2,m+1) = bdem(:,1,3,2,m+1) + bdem(:,2,1,2,m+1) + bdem(:,3,3,2,m+1) + bdem(:,4,1,2,m+1);
          bde(:,2,3,m+1) = bdem(:,1,3,3,m+1) + bdem(:,2,1,3,m+1) + bdem(:,3,3,3,m+1) + bdem(:,4,1,3,m+1);
          fde(:,2,m+1)   = fdem(:,1,3,m+1)   + fdem(:,2,1,m+1)   + fdem(:,3,3,m+1)   + fdem(:,4,1,m+1);
          % Third edge
          bde(:,3,1,m+1) = bdem(:,1,2,1,m+1) + bdem(:,2,2,1,m+1);
          bde(:,3,2,m+1) = bdem(:,1,2,2,m+1) + bdem(:,2,2,2,m+1);
          bde(:,3,3,m+1) = bdem(:,1,2,3,m+1) + bdem(:,2,2,3,m+1);
          fde(:,3,m+1)   = fdem(:,1,2,m+1)   + fdem(:,2,2,m+1);
      end
  end
  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);
      
% -----------------------------------------------------------------------------  
% Assemble interior residuals from rhs-contributions
% -----------------------------------------------------------------------------
  for m = 0:noarv
      %
      % Assemble interior residual from source f
      ind_m = rhs_ind(1,m+1);
      if ind_m>0
         intres(:,(3*(ind_m-1)+1):(3*ind_m)) = intres(:,(3*(ind_m-1)+1):(3*ind_m)) + fde(:,:,m+1) * beta(1,m+1);
      end
      %
      % Assemble interior residuals from div(a*grad)-contributions
      [nzi,nzj,g] = find(G{m+1});
      for t = 1:length(nzi)
          i = nzi(t); 
          j = nzj(t);
          for ii = 1:3
              for jj = 1:3
                  intres(:,3*(i-1)+ii) = intres(:,3*(i-1)+ii) + (g(t)*bde(:,ii,jj,m+1)) .* sl_v(:,3*(j-1)+jj);
              end
          end
      end   
  end
     
end  % end function