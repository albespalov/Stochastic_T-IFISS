function [amin] = stoch_test_wellposedness_KL(noarv,KL_DATA)
%STOCH_TEST_WELLPOSEDNESS_KL estimates lower bound of the KL-type stochastic diffusion coefficient
%
% [amin] = stoch_test_wellposedness_KL(noarv,KL_DATA)
% 
% input:
%         noarv    number of active random variables
%       KL_DATA    data related to KL-expansion
%
% output:
%          amin    estimated lower bound of the random field for current active parameters
%           
% See also STOCH_TEST_WELLPOSEDNESS_POWELL, STOCH_WELLPOSEDNESS_TEST
%
%   TIFISS function: AB; 31 December 2021
% Copyright (c) 2017 A. Bespalov, L. Rocchi

% Load distribution for random parameters: uniform (1), trunc. Gaussian (2)
  parameter = csvread('parameter_choice.dat');
  distribution = parameter(2);

% Get standard deviation
  sigma = KL_DATA.input(3);

  m = 1:noarv;
  nx = KL_DATA.ev2d_ind(m,1); 
  ny = KL_DATA.ev2d_ind(m,2);

% Get eigenvalues
  lambdas = KL_DATA.ev2d(m);

% Get factors of cos/sin
  alphas_x = KL_DATA.ev_x(nx,3);
  alphas_y = KL_DATA.ev_y(ny,3);

% Compute lower bound of the diffusion coefficient
  if distribution == 1
      % Uniform distribution
      c = sqrt(3.0);    
      meanfield = 1;
  else% distribution == 2
      % Truncated Gaussian distribution
      c = 1.85337;      
      meanfield = 2;
  end

  amin = meanfield - c * sigma * sum(alphas_x .* alphas_y .* sqrt(lambdas'));

end % end function