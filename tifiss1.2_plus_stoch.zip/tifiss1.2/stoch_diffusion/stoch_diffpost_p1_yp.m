function [yp_elerr,yp_err_est] = stoch_diffpost_p1_yp(xy,evt,eboundt,evtY,xyY,...
                   p1sol,eex,tve,els,G,indset,P,norv,noarv,KL_DATA,subdivPar)
%STOCH_DIFFPOST_P1_YP computes hierarchical YP-estimate solving error residuals problems elementwise
%
% [yp_elerr,yp_err_est] = stoch_diffpost_p1_yp(xy,evt,eboundt,evtY,xyY,...
%                         p1sol,eex,tve,els,G,indset,P,norv,noarv,KL_DATA,subdivPar)
%
% input:
%               xy     vertex coordinate vector  
%              evt     element mapping matrix
%          eboundt     element edge boundary matrix 
%             evtY     element mapping matrix for midpoints
%              xyY     vertex coordinate vector for midpoints
%            p1sol     P1 solution vector
%              eex     element connectivity array
%              tve     edge location array
%              els     elementwise edge lengths
%                G     (1 x (noarv+1)) cell of G-matrices
%           indset     index set of polynomial degrees
%                P     length of the index set
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%        subdivPar     red or bisec3 uniform sub-division flag
%
% output:
%         yp_elerr     vector of YP element indicators
%       yp_err_est     global YP error estimate
%
% V_{YP}-estimator: employs elementwise P1-bubbles for the edge midpoints 
% (for both red and bisec3 uniform sub-division) tensorised with the 
% original set of polynomials.
%
% The function solves the discrete problem for the eYP estimator:
%
%   B0(eYP,v) = F(v) - B(uXP,v),     for all v \in VYP,        (1)
%
% using a standard element residual technique to construct the corresponding 
% local residual problems over each element K in the mesh; see [BS16, eq. (5.3)]
%
% References:
%
% [BS16] Bespalov, Silvester, Efficient adaptive stochastic Galerkin methods for 
% parametric operator equations, SIAM J. Sci. Comput., 38(4)A2118-A2140, 2016;
%
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_gauss_coeff
%                      stoch_intres_p1_yp
%                      stoch_edgeres_p1_yp
%                      stoch_diffpost_p1_yp_bc
% 
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nel = size(evt,1);  % Number of elements
    
% Recover local coordinates   
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy( evt(:,ivtx), 1);
      yl_v(:,ivtx) = xy( evt(:,ivtx), 2);
  end
  
% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);

% Initialise local matrices  
  adem = zeros(nel,4,3,3);
  ade  = zeros(nel,3,3);   
  xl_s = zeros(nel,4,3);
  yl_s = zeros(nel,4,3);
  xl_m = zeros(nel,3);
  yl_m = zeros(nel,3);
  
% ----------------------------------------------------------------------------- 
% STEP 1: coordinates of midpoints: four sub-elements
% -----------------------------------------------------------------------------
% First physical mid-edge points
  xedge1(:,1) = 0.5*(xl_v(:,2) + xl_v(:,3));  
  yedge1(:,1) = 0.5*(yl_v(:,2) + yl_v(:,3));
  
% Second physical mid-edge points
  xedge2(:,1) = 0.5*(xl_v(:,1) + xl_v(:,3));   
  yedge2(:,1) = 0.5*(yl_v(:,1) + yl_v(:,3));
  
% Third physical mid-edge points
  xedge3(:,1) = 0.5*(xl_v(:,1) + xl_v(:,2));  
  yedge3(:,1) = 0.5*(yl_v(:,1) + yl_v(:,2));

% Define the local sub-division 
  if subdivPar == 1
      % 
      % Red sub-division
      % 
      % First physical sub-element 
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge3(:);      yl_s(:,2,1) = yedge3(:);
      xl_s(:,2,2) = xl_v(:,2);      yl_s(:,2,2) = yl_v(:,2);
      xl_s(:,2,3) = xedge1(:);      yl_s(:,2,3) = yedge1(:);
      % Third physical sub-element 
      xl_s(:,3,1) = xedge2(:);      yl_s(:,3,1) = yedge2(:);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xl_v(:,3);      yl_s(:,3,3) = yl_v(:,3);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge1(:);      yl_s(:,4,1) = yedge1(:);
      xl_s(:,4,2) = xedge2(:);      yl_s(:,4,2) = yedge2(:);
      xl_s(:,4,3) = xedge3(:);      yl_s(:,4,3) = yedge3(:);    
  else
      %
      % Bisec3 sub-division
      % 
      % First physical sub-element
      xl_s(:,1,1) = xl_v(:,1);      yl_s(:,1,1) = yl_v(:,1);
      xl_s(:,1,2) = xedge3(:);      yl_s(:,1,2) = yedge3(:);
      xl_s(:,1,3) = xedge2(:);      yl_s(:,1,3) = yedge2(:);
      % Second physical sub-element   
      xl_s(:,2,1) = xedge2(:);      yl_s(:,2,1) = yedge2(:);
      xl_s(:,2,2) = xedge3(:);      yl_s(:,2,2) = yedge3(:);
      xl_s(:,2,3) = xl_v(:,2);      yl_s(:,2,3) = yl_v(:,2);
      % Third physical sub-element 
      xl_s(:,3,1) = xl_v(:,2);      yl_s(:,3,1) = yl_v(:,2);
      xl_s(:,3,2) = xedge1(:);      yl_s(:,3,2) = yedge1(:);
      xl_s(:,3,3) = xedge2(:);      yl_s(:,3,3) = yedge2(:);
      % Fourth physical sub-element 
      xl_s(:,4,1) = xedge2(:);      yl_s(:,4,1) = yedge2(:);
      xl_s(:,4,2) = xedge1(:);      yl_s(:,4,2) = yedge1(:);
      xl_s(:,4,3) = xl_v(:,3);      yl_s(:,4,3) = yl_v(:,3);
  end    
  
% ----------------------------------------------------------------------------- 
% STEP 2: left-hand side deterministic contributions of (1)
% ----------------------------------------------------------------------------- 
  for subelt = 1:4   
      % Recoverl local coordinates
      for ivtx = 1:3
          xl_m(:,ivtx) = xl_s(:,subelt,ivtx);
          yl_m(:,ivtx) = yl_s(:,subelt,ivtx);
      end     
      % Loop over Gauss points
      for igpt = 1:nngpt         
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght = wt(igpt);
          %
          % Evaluate derivatives
          [~,invjac_m,~,dphidx_m,dphidy_m] = tderiv(sigpt,tigpt,xl_m,yl_m);
          %
          % Evaluate stochastic diffusion coefficients
          [coeff_v] = stoch_gauss_coeff(sigpt,tigpt,xl_m,yl_m,norv,KL_DATA);
          %
          % Loop over the three mid-edge linear functions
          for j = 1:3
              for i = 1:3
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidx_m(:,i) .* dphidx_m(:,j) .* invjac_m(:);
                  adem(:,subelt,i,j) = adem(:,subelt,i,j) + wght * coeff_v(:,1) .* dphidy_m(:,i) .* dphidy_m(:,j) .* invjac_m(:);
              end
          end
          
      end
      % end of Gauss point loop
  end
% end of subdivided element loop

% -----------------------------------------------------------------------------
% Manual assembly of subelement contributions
% -----------------------------------------------------------------------------
  if subdivPar == 1
      % 
      % Red sub-division: assembling
      % 
      % First edge
      ade(:,1,1) = adem(:,2,3,3) + adem(:,3,2,2) + adem(:,4,1,1);
      ade(:,1,2) = adem(:,3,2,1) + adem(:,4,1,2);
      ade(:,1,3) = adem(:,2,3,1) + adem(:,4,1,3);
      % Second edge
      ade(:,2,1) = adem(:,3,1,2) + adem(:,4,2,1);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,3,1,1) + adem(:,4,2,2);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,4,2,3);  
      % Third edge     
      ade(:,3,1) = adem(:,2,1,3) + adem(:,4,3,1);
      ade(:,3,2) = adem(:,1,2,3) + adem(:,4,3,2);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,1,1) + adem(:,4,3,3);  
  else
      %
      % Bisec3 sub-division: assembling
      % 
      % First edge
      ade(:,1,1) = adem(:,3,2,2) + adem(:,4,2,2);
      ade(:,1,2) = adem(:,3,2,3) + adem(:,4,2,1);
      % ae(:,1,3) = empty
      % Second edge
      ade(:,2,1) = adem(:,3,3,2) + adem(:,4,1,2);
      ade(:,2,2) = adem(:,1,3,3) + adem(:,2,1,1) + adem(:,3,3,3) + adem(:,4,1,1);
      ade(:,2,3) = adem(:,1,3,2) + adem(:,2,1,2);  
      % Third edge     
      % ae(:,3,1) = empty 
      ade(:,3,2) = adem(:,1,2,3) + adem(:,2,2,1);
      ade(:,3,3) = adem(:,1,2,2) + adem(:,2,2,2);
  end 
    
% ----------------------------------------------------------------------------- 
% STEP 3: right-hand side of the linear system (1)
% -----------------------------------------------------------------------------   
% Local rhs of the local residual problems are given by the difference of
%
% intres := F(v) + \int_Gamma\int_K div(a(x,y)\grad uXP(x,y))v(x,y) dx dpiy,
%
% which is the 'internal residual' and
%
% edgeres := (1/2)\int_Gamma\int_{\partial K}a(s,y)Jump(uXP(s,y))v(s,y) dsdpiy,
%
% which is the 'edge residual', for each element K in the mesh.

% Element residual
  [intres] = stoch_intres_p1_yp(xy,xl_s,yl_s,evt,p1sol,indset,P,G,norv,noarv,KL_DATA,subdivPar);
  
% Edge residual: this does not depend on the subdivision chosen
  [edgeres] = stoch_edgeres_p1_yp(xy,evt,eboundt,p1sol,eex,tve,els,P,G,norv,noarv,KL_DATA);
  
  fprintf('   yp estimate: intres = %7.4e;  edgeres = %7.4e\n',norm(intres),norm(edgeres));
  
% Final rhs
  rhs = intres - edgeres;
                  
% -----------------------------------------------------------------------------  
% Impose Dirichlet boundary conditions 
% -----------------------------------------------------------------------------
  [ade,rhs] = stoch_diffpost_p1_yp_bc(ade,rhs,xy,evt,eboundt,evtY,xyY,P,norv);
    
% -----------------------------------------------------------------------------
% STEP 4: solving the system
% -----------------------------------------------------------------------------

% LDLT vectorised factorization
  [ade] = element_ldlt_factorization(ade,nel);

% Solver forward-backward substitutions
  [yp_elerr_sq] = yp_err_solver(ade,rhs,nel,P);
 
% Element-indicators and B0-norm of the estimator ||eYP||_B0
  yp_elerr   = sqrt(yp_elerr_sq);
  yp_err_est = norm(yp_elerr,2);
          
end  % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [yp_err_sq_el] = yp_err_solver(ade,rhs,nel,P)
%Solve the stochastic linear system and returns the elementwise YP error
%indicators squared

% Loop over the stochastic components
  elerr = zeros(3*P,nel);
  for nnp = 1:P
      fde = rhs(:,(nnp-1)*3+1:nnp*3);
      xdx = element_lusolve(ade,fde);
      % The vector elerr contains the solution values over the 3 edge 
      % midpoints for each element
      elerr((nnp-1)*3+1:nnp*3,1:nel) = xdx';
  end
         
% The vector yp_err_sq_el contains the ||eYP(K)||_B0^2 for each K in the mesh
  yp_err_sq_el = zeros(nel,1);
  for svtx = 1:3*P
      yp_err_sq_el(:) = yp_err_sq_el(:) + rhs(:,svtx) .* elerr(svtx,:)';
  end

end % end child function


% ----------------------------------------------------------------------
% Child function
% ----------------------------------------------------------------------
function [ade] = element_ldlt_factorization(ade,nel)
% LDLT factorization of the matrix ade
  
  nn = 3; % number of hat functions per element
  dd = zeros(nel,nn);
  rr = zeros(nel,nn);
  
  for kk = 1:nn-1
      for pp = 1:kk-1
          rr(1:nel,pp) = dd(1:nel,pp).*ade(1:nel,kk,pp);
      end
      dd(1:nel,kk) = ade(1:nel,kk,kk);
      for pp = 1:kk-1
          dd(1:nel,kk) = dd(1:nel,kk) - ade(1:nel,kk,pp).*rr(1:nel,pp);
      end
      for ii = kk+1:nn
          for pp = 1:kk-1
              ade(1:nel,ii,kk) = ade(1:nel,ii,kk) - ade(1:nel,ii,pp).*rr(1:nel,pp);
          end
          ade(1:nel,ii,kk) = ade(1:nel,ii,kk)./dd(1:nel,kk);
      end
  end
  
  for pp = 1:nn-1
      rr(1:nel,pp) = dd(1:nel,pp).*ade(1:nel,nn,pp);
  end
  
  dd(1:nel,nn) = ade(1:nel,nn,nn);
  
  for pp = 1:nn-1
      dd(1:nel,nn) = dd(1:nel,nn) - ade(1:nel,nn,pp).*rr(1:nel,pp);
  end
  
% Overwrite diagonal entries
  for kk = 1:nn
      ade(1:nel,kk,kk) = dd(1:nel,kk);
  end

end % end child function