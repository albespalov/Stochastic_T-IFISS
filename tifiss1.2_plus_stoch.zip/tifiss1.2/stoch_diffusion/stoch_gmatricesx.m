function [G] = stoch_gmatricesx(indset,P,noarv,norv)
%STOCH_GMATRICESX generates stochastic G-matrices
%
%   [G] = stoch_gmatricesx(indset,P,noarv,norv)
%
%   input:
%          indset      index set: a matrix of non-negative integers
%               P      length of the index set
%           noarv      number of active random variables
%            norv      number of random variables
%   output:
%               G      a (1 x (noarv+1)) cell of G-matrices
%
% NOTE: this function is based on the original SIFISS function 
% STOCH_GMATRICES (CEP; 28 May 2015).
% Modifications have been done in order to allocate the G-matrices 
% up to noarv (instead of norv)
%
%   SIFISS function: AB; 05 January 2018
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

% Random variables distribution (new feature by Feng Xu )
  parameter = csvread('parameter_choice.dat');
  distribution = parameter(2);
  if distribution == 2
      % Load beta values (FX)
      beta = csvread('beta_truncated_gaussian.dat');
  end

% Allocate memory
  G = cell(1,noarv + 1); % cell(1,norv+1);
  I = eye(norv,'uint8');

% Set G{1} = G_0 = Identity
  G{1} = speye(P);

% Compute G{2},...,G{noarv+1}
  for m = 1:noarv
      G{m+1} = sparse(P,P);
      % ith row of identity: has 1 in the mth position
      % eps_m = I(m,:);   
      for k = 1:P
          % add one in the mth position of the kth index :
          % then need to find the position of this index (if it exists).
          nu = indset(k,:) + I(m,:);
          nu2 = repmat(nu,P,1);
          [s,n] = max( sum(indset==nu2,2) );
          %n=find(sum(indset==nu2,2)==norv);
          %n=find(ismember(indset,nu,'rows'))
          %here you may want to check whether n is emtpy
          if s == norv    % this means all entries in nth multi-index and nu match.
              %if isempty(n)==0
              if distribution==2
                  G{m+1}(k,n) = sqrt(beta(double(nu(m)))); % FX
              elseif distribution==1
                  G{m+1}(k,n) = double(nu(m)) / ( sqrt(4.0e0*double(nu(m))^2 - 1.0e0) );
              end
              % similarly for -1 in the mth position. Construct by symmetry.
              G{m+1}(n,k) = G{m+1}(k,n);
          end
      end
  end
  
end % end function