%STOCH_ADAPT_DIFF_MAIN solves stochastic diffusion problem using adaptive sGFEM
%
% Main driver for the adaptive sGFEM algorithm.
%
% Spatial domains: square, L-shaped, or crack domain.
% Automatic choice of refinement type: refines according to the largest 
% error reduction estimate for spatial refinement and for individual 
% new indices.
%
% Final outputs are saved to:
% - datafiles/stoch_adapt_final_output.dat;
% - datafiles/stoch_adapt_final_mesh.dat;
%
%   TIFISS scriptfile: MR; 04 June 2021; AB; 29 December 2021
% Copyright (c) 2018 A. Bespalov, L. Rocchi
      
% Initial parameters  
  stoch_adapt_init_param;
   
% Spatial initialisation of the mesh
  stoch_adapt_init_spatial;
  
% Random variables and stochastic coefficients initialisation
  stoch_adapt_init_stoch;
  
% -------------------------------------------------------------------------
% Adaptive Finite Element Loop
% -------------------------------------------------------------------------  
  iter = 0;
  endLoopFlag = 0;
  polenr_or_meshref = 0;    % Mesh-refinement/polynomial-enrichment switch

% Debug: display (or not) the initial data
  iDebugMode = default('\nRun code in debug mode 1/0 (yes/no)? (default no)',0);
  if ~ismember(iDebugMode,[0,1]), error('Choose either 1 or 0!'); end
  if iDebugMode
      stoch_adapt_display_info_debug;
  end
  
% Preallocating memory for dof, error, arv, and energy vectors
  stoch_adapt_update_vectors;
 
  startLoopTime = tic;
  while true
      % Update counter iteration
      iter = iter + 1;
      
      fprintf('\n'); fprintf(num2str(repmat('<strong>-</strong>',1,60))); fprintf('\n');
      fprintf('<strong>Iteration %i\n</strong>',iter);
      fprintf(num2str(repmat('<strong>-</strong>',1,60))); fprintf('\n');

      % -------------------------------------------------------
      % Parametric enrichments or spatial refinements
      % -------------------------------------------------------
      if polenr_or_meshref == 1
          % Polynomial enrichment: updating the index set
          %
          % Checking limit on random variables
          [~,Q_noarv] = find(Q_indset(M_ind,:));
          if (max(Q_noarv) + extra_rv) > norv
              fprintf('<strong>Terminated: limit norv is achieved. Tolerance is not met</strong>\n');
              endLoopFlag = 1;
              iter = iter-1;
              break;
          end
          stoch_pol_enrich;
                                         
      elseif polenr_or_meshref == 2
          % Mesh refinement
          fprintf('\n<strong>Local mesh refinement...</strong>');
          meshRefTime = tic;
          [evt,xy,bound,interior,eboundt] = mesh_ref(MMele,MMedge,evt,xy,bound,evtY,xyY,boundY);
          fprintf('done (%.5f sec)',toc(meshRefTime));
      end
      
      % -------------------------------------------------------
      % Setup and solve   
      % -------------------------------------------------------
      stoch_setup_and_solve;

      % -------------------------------------------------------
      % A posteriori error estimation
      % -------------------------------------------------------
      stoch_adapt_diffpost;
        
      % -------------------------------------------------------
      % Marking step:
      % -------------------------------------------------------
      stoch_adapt_marking;
      
      % Debug: plot current mesh and displaying data
      if iDebugMode
          stoch_adapt_display_info_debug;
      end
           
      % Update vectors
      stoch_adapt_update_vectors;
                  
      % -------------------------------------------------------
      % Checking tolerance and number of iterations
      % -------------------------------------------------------
      if tot_err_est <= err_tol
          % Tolerance reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Tolerance reached!</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
          
      elseif iter == max_iter
          % Maximum number of allowed iterations reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Max number of iterations reached before the tolerance is achieved</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
          
      elseif length(xminres) >= max_dofs
          % Maximum number of allowed dofs overcome
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Max number of dofs reached before the tolerance is achieved</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
          
      end
         
      % -------------------------------------------------------
      % Mesh refinement or polynomial enrichment? 
      % -------------------------------------------------------
      % vartheta variable:
      % vartheta < 1 delays parametric enrichments;
      % vartheta > 1 triggers earlier parametric enrichments.
      % Default value is 1.
      vartheta = 1;
      
      if isequal(algo,1)
          % Version 1: comparing global estimates
          if yp_err_est >= vartheta * xq_err_est
              polenr_or_meshref = 2; % Mesh refinement
          else
              polenr_or_meshref = 1; % Parametric enrichment
          end
           
      else%isequal(algo,2)
          % Version 2: comparing estimates for marked elements/edges and indices
          if yp_err_est_marked >= vartheta * xq_err_est_marked
              polenr_or_meshref = 2; % Mesh refinement
          else
              polenr_or_meshref = 1; % Parametric enrichment
          end
      end
         
  end
% end of while loop 

  endLoopTime = toc(startLoopTime);
   
% Resizing vectors
  stoch_adapt_update_vectors;
  
% Display the final data
  stoch_adapt_display_final_data;
  
% ----------------------------------------------------------------------------- 
% Save output
% -----------------------------------------------------------------------------
% Resize the index set up to active norvs (noarv)
  [~,col] = find(indset);     
  indset = indset(:,1:max(col));
  
  gohome; cd datafiles;
% Final mesh info                   
  save stoch_adapt_final_mesh.mat xy evt bound interior eboundt;
% Update data sot stoch_data file
  save stoch_data -append noarv P;    
% Data from the adaptive loop  
  save stoch_adapt_final_output.mat threshold_ele threshold_ind                   ... 
                                    nel_iter totnvtx_iter intnvtx_iter            ...
                                    dof_iter dofInt_iter indset noarv             ...
                                    cardP_iter cardQ_iter markind_iter arv_iter   ...
                                    index_iter index_init Q_indset M_ind extra_rv ...
                                    error_iter energy_iter                        ...
                                    yperrest_one_iter yperrest_two_iter           ...
                                    xqerrest_one_iter xqerrest_two_iter           ...
                                    Ncum_iter endLoopTime;

% -------------------------------------------------------------------------
% Plots
% -------------------------------------------------------------------------
% Plot final mesh
  plot_mesh(evt,xy,'Final mesh'); 
  
% Convergence plot
  stoch_convplot;
  
% Plot expectation, variance, and YP/XQ-error estimates 
  fprintf('\nPlotting expectation, variance and estimated errors...');
  stoch_plotdata_p1(dom_type,x_gal,var_sol,yp_elerr,xq_elerr,evt,xy);
  fprintf('done\n');
  fprintf('\n-> Output mesh data saved to: datafiles/stoch_adapt_final_mesh.mat');  
  fprintf('\n-> Output data saved to:      datafiles/stoch_adapt_final_output.mat\n');
  fprintf('\nTo compute a reference solution run the script <strong>stoch_refenergy</strong>\n\n');
  
% end scriptfile  