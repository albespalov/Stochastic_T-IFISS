%STOCH_ADAPT_DIFFPOST a posteriori error estimation for the adaptive algorithm
%
% The function implements P1-based error approximation scheme for the stochastic 
% Galerkin FE solution (it works for both Version 1 and Version 2 of the 
% adaptive algorithm) and it includes three types of estimations for the
% spatial component of the error:
%
% 1 - eYP hierarchical estimator (solving elementwise residual problems);
% 2 - eYP hierarchical estimator (solving fully assembled residual problem);
% 3 - 2-level error estimator.
%
% NOTE that it is possible to choose between red and bisec3 uniform  
% sub-divisions for the spatial estimation by changing the variable 'subdivPar'; 
% see STOCH_ADAPT_INIT_PARAM.
%
% The global error estimate is returned in the variable "tot_err_est".
%
% Function(s) called: tedgegen
%                     p1grid_detail_space
%                     stoch_diffpost_p1_yp
%                     stoch_diffpost_p1_yp_linsys
%                     stoch_diffpost_p1_yp_2level
%                     stoch_diffpost_p1_xq
%
% See also STOCH_DIFFPOST
%                                              
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  if pmethod == 1      
      fprintf('\n<strong>A posteriori error estimation for P1 approximations:</strong>\n');
      %
      % If polenr_or_meshref == 1, the parametric enrichment has been 
      % done during the current iteration, so the mesh remained the same;
      if polenr_or_meshref == 2
          % Mesh refinement has been done during the current iteration: 
          % edge connections and edge lengths have to be updated
          % 
          % Update edge connections/lengths
          fprintf('   Updating edge lengths/connections');
          edgeGenTime = tic;
          [eex,tve,els] = tedgegen(xy,evt);
          fprintf(' (%.5f sec)\n',toc(edgeGenTime));
          %
          % Update detail space Y 
          fprintf('   Updating spatial detail space Y');
          detailTime = tic;
          [evtY,xyY,boundY,Ybasis] = p1grid_detail_space(xy,evt);
          fprintf('   (%.5f sec)\n',toc(detailTime));
      end

      % -------------------------------------------------------------------
      % YP error estimation 
      % -------------------------------------------------------------------
      % The estimation is based on the full detail space Y composed of basis
      % functions associated with all edge midpoints. 
      fprintf('<strong>YP-error estimation</strong>\n');
      yptime = tic;         
      if ypestim == 1         
          % Hierarchical eYP estimator: elementwise local residual problems. 
          % Only element indicators returned
          fprintf('   Spatial hierarchical estimator (element residual problems)\n');
          [yp_elerr,yp_err_est] = stoch_diffpost_p1_yp(xy,evt,eboundt,evtY,xyY,x_gal,...
                                  eex,tve,els,G,indset,P,norv,noarv,KL_DATA,subdivPar);

      elseif ypestim == 2
          % Hierarchical eYP estimator: fully assembled residual problems.
          % Both element and edge indicators returned
          fprintf('   Spatial hierarchical estimator (full system)\n');
          [yp_elerr, yp_ederr, yp_err_est] = stoch_diffpost_p1_yp_linsys(xy,evt,eboundt,...
                          evtY,xyY,boundY,Ybasis,x_gal,G,P,norv,noarv,KL_DATA,subdivPar);
                        
      else
          % 2-Level error estimator; both element and edge indicators returned
          fprintf('   Spatial 2-level error estimator\n');
          [yp_elerr,yp_ederr,yp_err_est] = stoch_diffpost_p1_yp_2level(xy,evt,eboundt,...
                         evtY,xyY,boundY,Ybasis,x_gal,G,P,norv,noarv,KL_DATA,subdivPar);                   
      end                        
      fprintf('   YP-error estimation took %.5f sec',toc(yptime)); 

      % -------------------------------------------------------------------
      % XQ error estimator
      % -------------------------------------------------------------------
      fprintf('\n<strong>XQ-error estimation</strong>\n');
      xqTime = tic;
      [Q_indset,GPQ,xq_elerr,xq_err_vec,xq_err_est] = ...
             stoch_adapt_diffpost_p1_xq(xy,evt,bound,x_gal,indset,...
             norv,noarv,extra_rv,KL_DATA,Q_indset,GPQ,polenr_or_meshref);
      fprintf('   XQ-error estimation took %.5f sec',toc(yptime));
               
  %elseif pmethod == 2
  % Not implemented yet...
  end 
  
% ----------------------------------------------------------------------------- 
% Compute total error estimate and print estimates
% ----------------------------------------------------------------------------- 
  tot_err_est = sqrt( xq_err_est^2 + yp_err_est^2 );
  fprintf('\n-> Simplistic YP-estimate of energy error: %10.4e',yp_err_est);
  fprintf('\n-> Simplistic XQ-estimate of energy error: %10.4e',xq_err_est);
  fprintf('\n-> Simplistic estimate of energy error:    <strong>%10.4e</strong>\n',tot_err_est);  
  
% end scriptfile