%STOCH_ADAPT_INIT_STOCH sets up stochastic coefficients and initial index sets for the adaptive loop
%
% Variables returned are:
%
%           norv      maximum number of random variables allowed
%        KL_DATA      data structure for KL exapansion
%          noarv      initial number of active random variables
%          polyd      initial total polynomial degree
%       extra_rv      number of extra random variables activated in the detail index set
%         indset      initial index set P
%       Q_indset      initial detail Q index set
%            GPQ      corresponding GPQ matrices for P and Q index sets
%
% New feature: possibility to select a truncated Gaussian distribution for 
% the random variables - Implementation by Feng Xu (2017)
%
% Function(s) called: stoch_trunc_gauss_coeffx
%                     stoch_kl_eigens
%                     stoch_indset
%                     stoch_adapt_new_indset
%                     stoch_gpqmatrices
% 
% See also STOCH_ADAPT_INIT_PARAM, STOCH_ADAPT_INIT_SPATIAL
%
%   TIFISS scriptfile: AB; 22 December 2021
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  gohome; cd datafiles;

% Maximum number of allowed random variables
  norv = 20;
  
% -----------------------------------------------------------------------------    
% Random variables distribution (will affect G and GPQ matrices later on)
% -----------------------------------------------------------------------------  
  fprintf('\n<strong>Random variables distribution:</strong>\n');
  if rd_type == 1
      % Default distribution for KL random field: truncated Gaussian
      distribution = default('Uniform or truncated Gaussian distribution 1/2? (default is 2)',2);
  else
      distribution = default('Uniform or truncated Gaussian distribution 1/2? (default is 1)',1);
  end
  if distribution == 2
      sigma = default('Standard deviation? (default is 1)',1);
      stoch_trunc_gauss_coeffx(10,1,sigma);
  elseif ~isequal(distribution,1)
      error('Selected distribution for random variables not available!');
  end
 
% -----------------------------------------------------------------------------    
% Initialise the stochastic coefficient parameters
% ----------------------------------------------------------------------------- 
  if rd_type == 0
      % -------------------------------------------------------------------
      % Synthetic random coefficient (see STOCH_COEFF_EXP4)
      % -------------------------------------------------------------------
      fprintf('\n<strong>Synthetic random coefficient expansion:</strong>\n');
      KL_DATA.input = [1,1,0];
      
  elseif (rd_type == 1 && norv > 0)
      % -------------------------------------------------------------------
      % Karhunen-Loeve expansion:
      % Reference: Ghanem, Spanos - Stochastic Finite Elements: a spectral 
      % approach (1991), Springer
      % -------------------------------------------------------------------
      % Check that domain is symmetric w.r.t. the origin
      x_min = min(xy(:,1));   x_max = max(xy(:,1));
      y_min = min(xy(:,2));   y_max = max(xy(:,2));
      if x_min + x_max == 0 && y_min + y_max == 0
          fprintf('\n<strong>Setting up KL expansion data:</strong>\n');
          std_dev  = default('Standard deviation? (default 0.15)',1.5e-01);
          correl_x = default('Correlation length in x-direction? (default 2.0)',2.0e-00);
          correl_y = default('Correlation length in y-direction? (default 2.0)',2.0e-00);
          KL_DATA  = stoch_kl_eigens(x_max,y_max,std_dev,correl_x,correl_y,norv);
      else
          error('The domain must be symmetric with respect to the origin!');
      end
      
  elseif rd_type == 2
      % -------------------------------------------------------------------
      % Eigel expansion: 
      % Reference: Eigel, Gittelson, Schwab, Zander - Adaptive stochastic 
      % Galerkin FEM, Comput. Methods Appl. Mech. Engrg., 270:247-269, 2014 
      % -------------------------------------------------------------------
      fprintf('\n<strong>Eigel synthetic random coefficient expansion:</strong>\n');
      KL_DATA.input = [1,1,0];
      sdecay = default('Slow/fast coefficient decay 1/2 (default slow)',1);
      KL_DATA.decay = sdecay;
      
  elseif rd_type == 3
      % -------------------------------------------------------------------
      % Powell expansion:
      % Reference: Lord, Powell, Shardlow - An introduction to
      % computational stochastic PDEs (2014), Cambridge University Press
      % -------------------------------------------------------------------   
      fprintf('\n<strong>Powell synthetic random coefficient expansion:</strong>\n');
      KL_DATA.input = [1,1,0];
      mu = default('Mean coefficient (default is 1.0)',1.0);
      KL_DATA.mu = mu;
      ell = default('Correlation length coefficient (default is 1.0)',1.0e-00);
      KL_DATA.ell = ell;

  elseif rd_type == 4

      KL_DATA.input = [];

  end
  
% -----------------------------------------------------------------------------  
% Define coarse stochastic approximation  
% -----------------------------------------------------------------------------  
  noarv = default('Number of active random variables? (default is 1)',1);
  if noarv > norv
      error('Oops.. need to increase parameter norv!');
  end
  if noarv > 0
      polyd = default('Total polynomial degree? (default is 1)',1);
      [def_indset] = stoch_indset(polyd,noarv);
      def_indset = [def_indset,zeros(length(def_indset),norv-noarv)];
      indset = def_indset;
  else% if noarv == 0
      def_or_manual = default('Accept initial index (0,0,0,...) yes/no? (1/0) (default 1)',1);
      if def_or_manual
          % The code will start with index (0,0,...) as default
          fprintf('Default starting index: (0,0,0,...)\n');
          indset = uint8(zeros(1,norv));
          polyd = 0;
      else
          indset = input('Insert the initial index set manually: ');
          if ~isequal(nnz(ismember(indset,zeros(1,size(indset,2)),'rows')),1)
              % The index (0,0,...) has not been inserted
              error('The index (0,0,0,...) should be inserted anyway');
          end
          indset = uint8([indset,zeros(size(indset,1),norv-size(indset,2))]);
          % Number of active r.v. and polynomial degree for the 
          % inserted index set          
          noarv = norv - nnz(all(indset == 0,1));
          polyd = max(sum(indset,2));          
      end      
  end

% -----------------------------------------------------------------------------  
% Setup the number of extra random variables activated in the detail index set
% -----------------------------------------------------------------------------
  extra_rv = default('Extra active parameters in detail index sets? (default is 1)',1);  
  
% Save extra_rv and parameters distribution (used by STOCH_GPQMATRICES below)
  csvwrite('parameter_choice.dat',[extra_rv distribution]);
  
% Sort the index set
  indset = sortrows(indset);
  
% Save the first input index set
  index_init = indset;
  
% Length of the index set
  P = size(indset,1);

% Checking that there is enough norv to build Q index set
  if (noarv + extra_rv) > norv
     error('Oops... the detail index set cannot be computed, increase the parameter norv!');
  end

% Computing initial detail 'Q' index set
  [new_indset] = stoch_adapt_new_indset(indset,noarv,extra_rv);
  Q_indset     = new_indset(~ismember(new_indset,indset,'rows'),:);
  
% Computing initial GPQ matrices needed for XQ estimation
  [GPQ] = stoch_gpqmatrices(indset,Q_indset);
  
% -----------------------------------------------------------------------------  
% Save data
% -----------------------------------------------------------------------------
% Save noarv
  save stoch_data.mat rd_type norv noarv P;
  
% Save the data related to KL-expansion
  save stoch_kl_data.mat '-struct' KL_DATA;  
  
% end scriptfile 