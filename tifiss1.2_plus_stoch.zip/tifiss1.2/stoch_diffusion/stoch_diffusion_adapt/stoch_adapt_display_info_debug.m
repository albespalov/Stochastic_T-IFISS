%STOCH_ADAPT_DISPLAY_INFO_DEBUG prints data in the debugging mode
%
% If iDebugMode=1 in the main driver, then the following data is printed:
% - number of vertices;
% - number of elements;
% - number of total dofs;
% - estimated energy error;
% - current P index set;
% - current detail Q index set with associated marked indices (and estimates)
% - current mesh;
%
% Function(s) called: plot_mesh
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

if iter == 0
    %
    % Initial data
    % 
    fprintf('\n* -----------------------------------------------------');
    fprintf('\n<strong>Initial data</strong>');
    fprintf('\n* -----------------------------------------------------');
    fprintf('\nInitial number of vertices:   %d',size(xy,1));
    fprintf('\nInitial number of elements:   %d',size(evt,1));
    fprintf('\nInitial number of total dof:  %d',P*length(interior));
    fprintf('\nInitial index set (%d indices):\n',P);
    [~,col] = find(indset);
    if isempty(col), col = 1; end
    for i = 1:P
        fprintf('  %i  ',indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('Active parameters: %d | polynomial degree: %d\n',noarv,polyd);
    %
    % Printing the initial Q index set
    Q = size(Q_indset,1);  
    [~,col] = find(Q_indset);
    fprintf('Initial Q index set:\n');
    for i = 1:Q
        fprintf('  %i  ',Q_indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('* -----------------------------------------------------\n');
    fprintf('press any key to continue...\n'); 
    pause
    
else
    %
    % Data during the current iteration
    % 
    % Displaying the current mesh
    plot_title = ['Iteration ',num2str(iter)];
    plot_mesh(evt,xy,plot_title);
    
    % Plot also the marked elements
    %plot_title = ['Marked elements (Iter. ',num2str(iter),')'];
    %plotcolor_markedelem(M_ele,evt,xy,0,plot_title);

    fprintf('\n* -----------------------------------------------------');
    fprintf('\n<strong>Current data during iteration %d</strong>',iter);
    fprintf('\n* -----------------------------------------------------');
    fprintf('\nNumber of vertices:     %d',size(xy,1));
    fprintf('\nNumber of elements:     %d',size(evt,1));
    fprintf('\nNumber of total dof:    %d',P*length(interior));
    fprintf('\nEstimated energy error: %2.5e',tot_err_est);
    fprintf('\nCurrent index set (%d indices):\n',P);
    [~,col] = find(indset);
    if isempty(col), col = 1; end
    for i = 1:P
        fprintf('  %i  ',indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('Active parameters: %d | polynomial degree: %d\n',noarv,polyd);
    %   
    % Printing the current Q index set and the corresponding estimators for
    % its indices         
    Q = size(Q_indset,1);  
    [~,col] = find(Q_indset);
    fprintf('Current Q index set and corresponding index estimates:\n');
    for i = 1:Q
        fprintf('  %i  ',Q_indset(i,1:max(col))); fprintf('  0    0  ...');
        fprintf('   <-  %.6f',xq_err_vec(i));
        if ismember(i,M_ind)
            fprintf('  (Marked)');
        end
        fprintf('\n');
    end
    fprintf('* -----------------------------------------------------\n');
    fprintf('press any key to continue...\n'); 
    pause
    
end

% end scriptfile