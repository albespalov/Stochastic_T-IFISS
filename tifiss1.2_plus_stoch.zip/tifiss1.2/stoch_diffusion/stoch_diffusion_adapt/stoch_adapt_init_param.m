%STOCH_ADAPT_INIT_PARAM sets up parameters for adaptive algorithm
%
% The initialised parameters are:
%
%                spde    model problem type (used by SRECALL)
%                algo    algorithm's type (1/2)
%           iPlotConv    plotting switch for stoch_minres convergence
%            max_iter    maximum number of iterations allowed
%            max_dofs    maximum number of degrees of freedom allowed
%           adapt_max    maximum number of pol. enrichments allowed
%          index_iter    cell-array containing new indices of pol. enrichments
%       index_counter    variable counting the polynomial enrichments
%      index_saveiter    iterations's numbers when enrichments occur
%             pmethod    P1 Galerkin approximation
%             err_tol    tolerance
%           subdivPar    red/bisec3 subdivision for spatial error estimation
%             ypestim    a posteriori spatial error estimator type
%         markedgelem    spatial marking type (elements or edges)
%            strategy    marking strategy choice
%       threshold_ele    threshold marking value for elements
%       threshold_ind    threshold marking value for indices
%
% See also STOCH_ADAPT_INIT_SPATIAL, STOCH_ADAPT_INIT_STOCH
%
%   TIFISS scriptfile: AB; 22 December 2021
% Copyright (c) 2017 A. Bespalov, L. Rocchi
  
% Model problem (1 for default diffusion stochastic problems; used by SRECALL)
  spde = 1;
  
% Choosing algorithm here 1/2?  
  algo = default('\nAlgorithm''s version 1/2? (default 2)',2);
  if ~ismember(algo,[1,2]), error('Algorithm type not available!'); end
  
% Plotting switch for stoch_minres convergence (0/1)
  iPlotConv = 0; 
  
% The adaptive algorithm stops when this number of dofs is reached
  max_dofs = 5e7;
  
% Maximum number of allowed iterations
  max_iter = 500;
  
% Set up cell array for the evolving index set and maximum number of
% enrichments
  adaptmax = 500;
  index_iter = cell(1,adaptmax);
  index_counter  = 1;
  index_saveiter = zeros(1,adaptmax);
  
% Spatial approximation is P1 
  pmethod = 1;

% Set the tolerance (it depends on the test problem)
  if pmethod == 1
      if sn==1
          % Large square domain
          err_tol = default('Desired error tolerance (default 8.0e-03)',8.0e-03);
      elseif ismember(sn,[2,3])
          % Square domain
          err_tol = default('Desired error tolerance (default 4.0e-03)',4.0e-03);
      elseif ismember(sn,[4,5,6])
          % L-shaped domain
          err_tol = default('Desired error tolerance (default 1.3e-02)',1.3e-02);
      elseif sn==7
          % Crack domain, Eigel coefficient
          err_tol = default('Desired error tolerance (default 2.0e-02)',2.0e-02);
      elseif sn==8
          % Crack domain, Powell coefficient
          err_tol = default('Desired error tolerance (default 1.0e-02)',1.0e-02);
      else %sn==9
          % Crack domain, Cookie problem
          err_tol = default('Desired error tolerance (default 5.0e-03)',5.0e-03);
      end
  %elseif
  % No adaptivity for P2 solutions yet...
  end
  
% Red/Bisec3 for spatial error estimation 1/2? See:
% Ainsworth, Oden, A posteriori error estimation in finite element analysis, 
% Wiley, 2000 - Figure 5.2 (p. 87) for the basis functions in both cases.
  subdivPar = 2; 
  
% (Spatial) error estimation type (see STOCH_ADAPT_DIFFPOST):
% 1 - eYP hierarchical estimator (elementwise residual problem)
% 2 - eYP hierarchical estimator (assembled system for the residual problem)
% 3 - 2-level error estimator
  fprintf('\nSpatial error estimation type:\n');
  fprintf('   1. hierarchical estimator (elementwise residual problem)\n');
  fprintf('   2. hierarchical estimator (fully assembled system for residual problem)\n');
  fprintf('   3. 2-level estimator\n');
  ypestim = default('(default 3)',3);
  if ~ismember(ypestim,[1,2,3]), error('Spatial estimation type not allowed!'); end
  
% Marking elements or edges 1/2? 
% This depends on the estimation type:
% - ypestim=1   -> only elements can be marked, i.e., markedgelem=1;
% - ypestim=2/3 -> both elements and edges can be marked, i.e.,markedgelem=1/2.
  if isequal(ypestim,1)
      % Marking elements
      markedgelem = 1;
  else%ypestim==2 or 3
      % Choose between elements and edges
      markedgelem = default('\nMarking elements/edges 1/2 (default 2)',2);
      if ~ismember(markedgelem,[1,2]), error('Marking type not allowed!'); end
  end
                   
% Marking threshold parameters for both elements/edges and indices:
% 1 - maximum strategy:
%     large threshold -> small set of marked elements/edges
%     small threshold -> large set of marked elements/edges
% 2 - Doerfler (equilibration) strategy:
%     large threshold -> large set of marked elements/edges
%     small threshold -> small set of marked elements/edges
  strategy      = default('Marking strategy: maximum or equilibration 1/2? (default 2)',2);
  threshold_ele = default('   spatial threshold parameter    (default 0.2)',0.2);
  threshold_ind = default('   parametric threshold parameter (default 0.9)',0.9);
  
% end scriptfile
