% STOCH_DIFFUSION_ADAPT
%
% Files
%   stoch_adapt_diff_main          - solves stochastic diffusion problem using adaptive sGFEM
%   stoch_adapt_diffpost           - a posteriori error estimation for the adaptive algorithm
%   stoch_adapt_diffpost_p1_xq     - computes XQ error estimator for adaptive stochastic P1 Galerkin solution
%   stoch_adapt_display_final_data - prints the data at the end of adaptive loop
%   stoch_adapt_display_info_debug - prints data in the debugging mode
%   stoch_adapt_init_param         - sets up parameters for adaptive algorithm
%   stoch_adapt_init_spatial       - generates a (coarse) spatial grid for the adaptive loop
%   stoch_adapt_init_stoch         - sets up stochastic coefficients and initial index sets for the adaptive loop
%   stoch_adapt_marking            - spatial and parametric marking for the adaptive algorithm
%   stoch_adapt_new_indset         - computes the augmented index set of 'neighbouring' indices
%   stoch_adapt_update_vectors     - preallocation, update, and resizing of vectors in the adaptive loop
