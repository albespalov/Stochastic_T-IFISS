%STOCH_ADAPT_MARKING spatial and parametric marking for the adaptive algorithm
% 
% The function implements the marking step for both element/edges and
% indices. In particular, the spatial marking allows to mark either the
% elements or the edges according to the variable 'markedgelem' below; 
% see also STOCH_ADAPT_INIT_PARAM.
%
% Also, the function computes the YP and XQ estimates associated with the set of 
% marked elements/edges and indices 
%
% Function(s) called: marking_strategy_fa 
%                     get_all_marked_elem
%                     
%   TIFISS scriptfile: AB; 15 August 2019
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  fprintf('\n<strong>Marking step (spatial and parametric):</strong>');
  
% ----------------------------------------------------------------------------    
% Spatial marking step
% ----------------------------------------------------------------------------
  if markedgelem == 1
      % Marking elements
      markElemTime = tic;
      [Mele] = marking_strategy_fa(yp_elerr,strategy,threshold_ele);
      %
      % Overall set of marked elements and edges
      [MMele,MMedge] = get_all_marked_elem(Ybasis,evtY,Mele,markedgelem);
      % 
      fprintf('\n   marked %d elements out of total %d',length(Mele),size(evt,1));
      fprintf('\n   <strong>%d</strong> overall marked elements out of total %d',length(MMele),size(evt,1));
      fprintf(' (%.5f sec)',toc(markElemTime));
      %
      % Estimate due to marked elements
      yp_err_est_marked = norm( yp_elerr(MMele), 2);
      
  else% markedgelem == 2
      % Marking edges
      markEdgeTime = tic;
      [Medge] = marking_strategy_fa(yp_ederr,strategy,threshold_ele);
      %
      % Overall set of marked edges and elements
      [MMele,MMedge] = get_all_marked_elem(Ybasis,evtY,Medge,markedgelem);
      %      
      fprintf('\n   marked %d edges out of total %d',length(Medge),length(yp_ederr));
      fprintf('\n   <strong>%d</strong> overall marked edges out of total %d',length(MMedge),length(yp_ederr));
      fprintf(' (%.5f sec)',toc(markEdgeTime));
      %
      % Estimate due to marked edges
      yp_err_est_marked = norm( yp_ederr(MMedge), 2);
  end  
      
% ----------------------------------------------------------------------------    
% Parametric marking 
% ----------------------------------------------------------------------------         
  markIndTime = tic;
  [M_ind] = marking_strategy_fa(xq_err_vec,strategy,threshold_ind); 
  fprintf('\n   <strong>%d</strong> overall marked indices out of total %d',length(M_ind),length(xq_err_vec));
  fprintf(' (%.5f sec)',toc(markIndTime)); 

% Estimate due to marked indices  
  xq_err_est_marked = norm( xq_err_vec(M_ind), 2);
  
% Print estimates  
  fprintf('\n-> YP-estimate (spatial marking):    <strong>%10.4e</strong>',yp_err_est_marked);  
  fprintf('\n-> XQ-estimate (parametric marking): <strong>%10.4e</strong>\n',xq_err_est_marked);
  
% end scriptfile