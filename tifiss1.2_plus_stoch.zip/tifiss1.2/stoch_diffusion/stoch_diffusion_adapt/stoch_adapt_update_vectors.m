%STOCH_ADAPT_UPDATE_VECTORS preallocation, update, and resizing of vectors in the adaptive loop
%
% Vectors considered and returned are:
%           dof_iter    vector of overall dofs (including boundary nodes)
%        dofInt_iter    vector of overall dofs (excluding boundary nodes)
%           nel_iter    vector of number of elements
%       totnvtx_iter    vector of overall nodes (including boundary nodes)
%       intnvtx_iter    vector of interior nodes
%         cardP_iter    vector of cardinality of P index sets
%         cardQ_iter    vector of cardinality of Q index sets
%           arv_iter    vector of number of active parameters
%       markind_iter    vector of marked indices
%         error_iter    vector of total estimated errors
%        energy_iter    vector of energy norms of the Galerkin solutions
%  yperrest_one_iter    vector of global YP estimates
%  yperrest_two_iter    vector of YP-estimates for marked elements/edges
%  xqerrest_one_iter    vector of global XQ estimates
%  xqerrest_two_iter    vector of XQ-estimates for marked indices
%          Ncum_iter    vector of "costs", i.e., cumulative overall dofs (dofInt_iter)
%
% NOTE that the variable 'endLoopFlag' can be equal to 1 or 0, meaning that the 
% adaptive loop is finished or not, respectively. In particular:
% - endLoopFlag = 1, vectors are resised up to the last non empty value; 
% - endLoopFlag = 0, vectors are preallocated (if iter==0) or updated (if iter>0).
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  if endLoopFlag% == 1
      % The adaptive loop finished and the vectors are resized (eliminating empty locations)
      dof_iter                    = dof_iter(1:iter);
      dofInt_iter                 = dofInt_iter(1:iter);
      nel_iter                    = nel_iter(1:iter);
      totnvtx_iter                = totnvtx_iter(1:iter);
      intnvtx_iter                = intnvtx_iter(1:iter);
      cardP_iter                  = cardP_iter(1:iter);
      cardQ_iter                  = cardQ_iter(1:iter);
      arv_iter                    = arv_iter(1:iter);
      markind_iter                = markind_iter(1:iter);
      error_iter                  = error_iter(1:iter);
      energy_iter                 = energy_iter(1:iter);
      yperrest_one_iter           = yperrest_one_iter(1:iter);
      yperrest_two_iter           = yperrest_two_iter(1:iter);
      xqerrest_one_iter           = xqerrest_one_iter(1:iter);
      xqerrest_two_iter           = xqerrest_two_iter(1:iter);
      Ncum_iter                   = cumsum(dofInt_iter);
      
  else % if endLoopFlag == 0
      % It is either the 0-th iteration or tolerance han not been reached yet
      % (the adatpvie loop is still running)
      if iter == 0 % Preallocation      
          dof_iter                = zeros(1,max_iter);
          dofInt_iter             = zeros(1,max_iter);
          nel_iter                = zeros(1,max_iter);
          totnvtx_iter            = zeros(1,max_iter);
          intnvtx_iter            = zeros(1,max_iter);
          cardP_iter              = zeros(1,max_iter);
          cardQ_iter              = zeros(1,max_iter);
          arv_iter                = zeros(1,max_iter);
          markind_iter            = zeros(1,max_iter);
          error_iter              = zeros(1,max_iter);
          energy_iter             = zeros(1,max_iter);
          yperrest_one_iter       = zeros(1,max_iter);
          yperrest_two_iter       = zeros(1,max_iter);
          xqerrest_one_iter       = zeros(1,max_iter);
          xqerrest_two_iter       = zeros(1,max_iter);
        
      else% if iter > 0
          % Update vectors with current data      
          dof_iter(iter)          = length(x_gal);
          dofInt_iter(iter)       = length(xminres);
          nel_iter(iter)          = size(evt,1);
          totnvtx_iter(iter)      = size(xy,1);
          intnvtx_iter(iter)      = length(interior);
          cardP_iter(iter)        = size(indset,1);
          cardQ_iter(iter)        = size(Q_indset,1);
          arv_iter(iter)          = noarv;
          markind_iter(iter)      = length(M_ind);
          error_iter(iter)        = tot_err_est;
          energy_iter(iter)       = energy;
          yperrest_one_iter(iter) = yp_err_est;
          yperrest_two_iter(iter) = yp_err_est_marked;
          xqerrest_one_iter(iter) = xq_err_est;
          xqerrest_two_iter(iter) = xq_err_est_marked;
      end
  end
  
% end scriptfile