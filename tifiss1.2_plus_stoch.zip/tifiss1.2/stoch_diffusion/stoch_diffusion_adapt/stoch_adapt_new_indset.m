function [B] = stoch_adapt_new_indset(A,noarv,extra_rv)
%STOCH_ADAPT_NEW_INDSET  computes the augmented index set of 'neighbouring' indices
% [indset_augmented] = stoch_adapt_new_indset(indset,noarv,extra_rv);
%   input
%          noarv              the number of active random variables
%          indset             given index set (a matrix with non-negative integer components)
%        extra_rv             number of extra random variables acivated in the detail index set
%   output
%          indset_augmented   augmented index set
%
%   S-IFISS function: AB; 13 June 2017
% Copyright (c) 2014 A. Bespalov, C.E. Powell, D.J. Silvester

% dimensions of A
  [P,norv] = size(A);

% check that noarv < norv
  if noarv >= norv, error('error: increase the number of random variables!'), end

  I = eye(noarv + extra_rv,'uint8');

% augment I with zero columns on the right to match size(A,2)
  I = [I,zeros(noarv + extra_rv,norv - noarv - extra_rv)];

  B = A;

% Find new entries of the index set for each row of A
  for i = 1 : P
      B = [B;A(i*ones(1,noarv + extra_rv),:) + I];
  end

% Cancel duplicating rows in B
  B = unique(B(1:size(B,1),:),'rows');

end

