function [amin] = stoch_test_wellposedness_powell(norv,noarv,mu,corrlen)
%STOCH_TEST_WELLPOSEDNESS_POWELL estimates lower bound of the Powell stochastic diffusion coefficient
%
% [amin] = stoch_test_wellposedness_powell(norv,noarv,mu,corrlen)
%
% input:
%         norv      maximum number of random variables allowed
%        noarv      initial number of active random variables
%           mu      mean value
%      corrlen      correlation length
%
% output:
%         amin      estimated lower bound of the random field for current active parameters
%
% See also STOCH_TEST_WELLPOSEDNESS_KL, STOCH_WELLPOSEDNESS_TEST
%
%   TIFISS function: AB; 31 December 2021
% Copyright (c) 2018 A. Bespalov, L. Rocchi
    
  ind = 0:1:norv-1;
  nu1 = (0.5) * exp(-pi * ind.^2 .* corrlen^2);
  nuij = nu1' * nu1;
  
% Find 1D indices and compute the largest 2D eigs
  nu2D = zeros(1,noarv);
  for m = 1:noarv
      [maxcol,indrow] = max(nuij);
      [eigmax,jj]     = max(maxcol);
      ii = indrow(jj);
      nu2D(m) = eigmax;
      nuij(ii,jj) = 0.0;
  end
   
% Lower bound Coefficient  
  amin = mu - sum( sqrt(nu2D) * 2 ) / sqrt(3);
  %a = mu - sqrt(3) * sum( sqrt(nu2D) * 2 );
  
end % end function