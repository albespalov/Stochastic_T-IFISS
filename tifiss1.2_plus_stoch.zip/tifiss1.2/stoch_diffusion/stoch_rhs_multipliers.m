function [rhs_ind,b] = stoch_rhs_multipliers(indset,P,norv)
%STOCH_RHS_MULTIPLIERS generates the vector of non-zero multipliers for the RHS of linear system
%   [rhs_ind,b] = stoch_rhs_multipliers(indset,P,norv);
%   input
%          indset     index set
%          P          length of the index set
%          norv       number of random variables
%   output
%          rhs_ind    polynomial degrees for which the RHS-entries in the linear system are non-zero
%          b          corresponding multipliers for the RHS-entries in the linear system
%
%   SIFISS function: DJS; 26 March 2015.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

  rhs_ind = zeros(1,norv+1);
if  norv>=2^8,
error('Oops.. norv is too high for uint8 arithmetic!'), end
  I = eye(norv,'uint8');
  if norv>1,rhs_ind(1,1) = find(ismember(indset,zeros(1,norv),'rows')); end
  b(1,1) = 1.0e0;
  for m=1:norv
      eps_m = I(m,:);
      aux_m = ismember(indset,eps_m,'rows');
      if nnz(aux_m)==0
         rhs_ind(1,m+1) = 0;
         b(1,m+1)=0;
         else
         rhs_ind(1,m+1) = find(aux_m);
         b(1,m+1)=1.0e0/sqrt(3.0e0);
      end
  end
  return
