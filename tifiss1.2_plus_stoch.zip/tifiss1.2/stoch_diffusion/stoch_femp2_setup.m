function [K,F] = stoch_femp2_setup(xyp2,evtp2,indset,P,norv,noarv,KL_DATA)
%STOCH_FEMP2_SETUP assembled P2 stochastic coefficient matrix generator
%
% [K,F] = stoch_femp2_setup(xyp2,evtp2,indset,P,norv,noarv,KL_DATA)
%
% input:
%             xyp2     vertex coordinate vector for P2 grid   
%            evtp2     element mapping matrix for P2 grid
%           indset     index set of polynomial degrees
%                P     length of the index set
%             norv     number of random variables
%            noarv     number of active random variables
%          KL_DATA     data related to KL-expansion
%
% output:
%                K     cell structure with noarv matrices 
%                F     rhs vector
%
% Function(s) called:  triangular_gausspoints, 
%                      tderiv
%                      tqderive
%                      stoch_gauss_source
%                      stoch_gauss_coeff
%                      stoch_rhs_multipliers
% 
% See also STOCH_FEMP1_SETUP
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nvtx = size(xyp2,1);  % Number of vertices + midpoints
  nel  = size(evtp2,1); % Number of elements
 
% Allocate memory   
  ade = zeros(nel,6,6,noarv+1);
  fde = zeros(nel,6,noarv+1);
  F   = zeros(nvtx*P,1);
  
% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt); 

% Recover local coordinates
  xl_v = zeros(nel,3);
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xyp2(evtp2(:,ivtx),1);
      yl_v(:,ivtx) = xyp2(evtp2(:,ivtx),2); 
  end
 
% Loop over Gauss points
  for igpt = 1:nngpt
      sigpt = s(igpt);
      tigpt = t(igpt);
      wght  = wt(igpt);
      %
      % Evaluate derivatives, RHS, and coefficients
      [jac,invjac,~,~,~]  = tderiv(sigpt,tigpt,xl_v,yl_v);
      [psi,dpsidx,dpsidy] = tqderiv(sigpt,tigpt,xl_v,yl_v);
      [rhs]   = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,norv);
      [coeff] = stoch_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
      %
      % Loop over active random variables
      for m = 0:noarv  %norv
          % Loop over basis functions
          for j = 1:6
              for i = 1:6
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff(:,m+1) .* dpsidx(:,i) .* dpsidx(:,j) .* invjac(:);           
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff(:,m+1) .* dpsidy(:,i) .* dpsidy(:,j) .* invjac(:);
              end
              % Contributions from the RHS
              fde(:,j,m+1) = fde(:,j,m+1) + wght * rhs(:,m+1) .* psi(:,j) .* jac(:);
          end
      end
  end
% end of Gauss point loop

% Cell structure to hold matrices K_1,...,K_{noarv}
  K = cell(1,noarv+1);  %norv+1);
  
% Compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);
   
% Perform assembly of global matrices and source vector
  for m = 0:noarv
      % Initialise global deterministic matrix and rhs vector
      ad = sparse(nvtx,nvtx);
      fd = zeros(nvtx,1);
      for krow = 1:6
          nrow = evtp2(:,krow);	 
          for kcol = 1:6
              ncol = evtp2(:,kcol);	  
              ad = ad + sparse(nrow,ncol,ade(:,krow,kcol,m+1),nvtx,nvtx);
          end
          for els = 1:nel
              fd(nrow(els),1) = fd(nrow(els),1) + fde(els,krow,m+1);
          end
          %fd(nrow,1) = fd(nrow,1) + fde(:,krow,m+1);
      end
      %
      % Save assembled matrix in the cell structure
      K{m+1} = ad;
      %
      % Assemble the rhs vector
      ind_m = rhs_ind(m+1);
      if ind_m > 0
         F((nvtx*(ind_m-1)+1):(nvtx*ind_m),1) = fd(:,1) * beta(1,m+1);
      end
  end

end  % end function