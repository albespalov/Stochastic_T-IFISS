function [bc] = stoch_specific_bc(xbd,ybd,norv)
%STOCH_ZERO_BC zero boundary condition 
%   
% [bc] = stoch_specific_bc(xbd,ybd,norv)
%
% input:
%        xbd     x boundary coordinate vector
%        ybd     y boundary coordinate vector 
%       norv     number of random variables
%
% output:
%         bc     boundary conditions
%
% NOTE that this is a copy of original SIFISS function (DJS; 22 January 2013) 
%
%   TIFISS function: AB; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  bc = [zeros(size(xbd)),zeros(length(xbd),norv)];

end % end function
