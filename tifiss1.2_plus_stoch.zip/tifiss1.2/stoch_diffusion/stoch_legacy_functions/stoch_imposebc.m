function [K,fgal,x_gal,dupl_intern] = stoch_imposebc(Knbc,fnbc,xy,bound,indset,P,norv,noarv)
%STOCH_IMPOSEBC imposes Dirichlet boundary condition for stochastic problem
%   [K,f,x_gal,dupl_intern] = stoch_imposebc(Knbc,fnbc,xy,bound,indset,P,norv,noarv);
%   input
%          Knbc          input cell structure (before bc's imposed)
%          f           input rhs vector
%          xy          vertex coordinate vector
%          bound       boundary vertex vector
%          indset      index set of polynomial degrees
%          P           length of the index set
%          norv        number of random variables
%          noarv       number of active random variables
%   output
%          K           output cell structure (with bc's imposed)
%          fgal        output rhs vector
%          x_gal       template solution vector (with bc's imposed)
%          dupl_intern boundary condition interior dof map
%
%   calls functions stoch_specific_bc, stoch_rhs_multipliers
%   SIFISS function: DJS; 27 July 2015.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester
  showbc=0; %=1; % show Dirichlet boundary condition  
  dimk=length(Knbc);  [nK, dummy] = size(Knbc{1});
  if dimk ~= norv+1, error('incompatible cell dimensions'), end
  nvtx = length(xy); 
  if nK ~= nvtx, error('incompatible dimensions'), end
  matr_dim=length(fnbc);
  nbd=length(bound);
  nint=nvtx-nbd;
%
% deterministic problem boundary mapping
  nodes=[1:nvtx]'; 
  intern=setdiff(nodes,bound);
  dupl_nodes=1:matr_dim;
  dupl_bound=zeros(nbd*P,1);
  for k = 1:P
      l = nvtx*(k-1)*ones(nbd,1);
      dupl_bound((k-1)*nbd+1:k*nbd,1) = l+bound;
  end
  dupl_intern=setdiff(dupl_nodes,dupl_bound);

% compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);

% set boundary condition
  xbd=xy(bound,1); ybd=xy(bound,2);
  bc = zeros(nbd*P,1);
  temp_bc = stoch_specific_bc(xbd,ybd,norv);
  for m=0:norv
      ind_m = rhs_ind(1,m+1);
      if ind_m>0
         bc((nbd*(ind_m-1)+1):(nbd*ind_m),1) = temp_bc(:,m+1)*beta(1,m+1)*(sqrt(2))^noarv;
      end
  end
% CAREFUL with beta(*,*) and sqrt(...) factors above; 
% things will change if BCs have more stochastic components!
% 
% sanity check for tensor product structure below
% only the first nbd entries in vector bc can be nonzero
  if P>1,
     check = find(bc(nbd+1,:)); 
     if ~isempty(check), error('Oops: check BC logic!'), end
  end
  detbc=bc(1:nbd);

% debug
% check boundary condition
if showbc,
fprintf('\n\n check boundary condition\n')
disp([xy(bound,1), xy(bound,2), detbc])
end


% generate the G-matrices
G = stoch_gmatrices(indset,P,norv);

% construct output structure
K = cell(1,norv+1);
 
fgal=fnbc(dupl_intern);
% loop over the component matrices
for dim = 1:dimk
    Kk=Knbc{dim}; Gk=G{dim}; gk=Gk(:,1); 
    start = nint*(dim-1); % not needed       
    kindex = find(gk); % could avoid kron below using index to active K matrix 
    fgal = fgal - kron(gk,Kk(intern,bound))*detbc;
    K{dim} = Kk(intern,intern);
end
  
% initialize the solution template vector 
  x_gal=zeros(matr_dim,1);
  x_gal(dupl_bound)=bc;

return
