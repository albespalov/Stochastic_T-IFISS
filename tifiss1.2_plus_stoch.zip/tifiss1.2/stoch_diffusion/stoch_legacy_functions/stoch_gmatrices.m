function G = stoch_gmatrices(indset,P,norv)
%STOCH_GMATRICES generates stochastic G-matrices
%   G = stoch_gmatrices(indset,P,norv);
%   input
%          indset     index set: a matrix of non-negative integers
%          P          length of the index set
%          norv       number of random variables
%   output
%          G          a (1 x (norv+1)) cell of G-matrices
%
%   SIFISS function: CEP; 28 May 2015
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

% CEP: more efficient version. Allows to compute matrices for
% noarv=20 and p=4 in a few minutes (rather than hours).
% calls to 'ismember' removed but structure of code unchanged.


% initialisation
  G = cell(1,norv+1);
  I = eye(norv,'uint8');

% set G_0 = Identity
  G{1} = speye(P);

% compute G_1,...,G_{norv}
  for m=1:norv
      G{m+1} = sparse(P,P);
      % ith row of identity: has 1 in the mth position
      eps_m = I(m,:);
      for k=1:P
          % add one in the mth position of the kth index :
          % then need to find the position of this index (if it exists).
          nu = indset(k,:) + I(m,:);
          nu2=repmat(nu,P,1);
          [s,n]=max(sum(indset==nu2,2));
          %n=find(sum(indset==nu2,2)==norv);
          %n = find(ismember(indset,nu,'rows'))
         % here you may want to check whether n is emtpy
         if s==norv % this means all entries in nth multi-index and nu match.
             %if isempty(n)==0
             G{m+1}(k,n) = double(nu(m))/(sqrt(4.0e0*double(nu(m))^2-1.0e0));
             % similarly for -1 in the mth position. Construct by symmetry. 
          G{m+1}(n,k) = G{m+1}(k,n);
         end
      end
  end

