function [Agal,fgal,x_gal,dupl_intern] = stoch_nonzerobc(a,f,xy,bound,indset,P,norv,noarv)
%STOCH_NONZEROBC imposes Dirichlet boundary condition for stochastic problem
%   [Agal,fgal] = stoch_nonzerobc(A,f,xy,bound,indset,P,norv,noarv);
%   input
%          A          stiffness matrix
%          f          rhs vector
%          xy         vertex coordinate vector
%          bound      boundary vertex vector
%          indset     index set of polynomial degrees
%          P          length of the index set
%          norv       number of random variables
%          noarv      the number of active random variables
%   output
%          Agal       stiffness matrix
%          fgal       rhs vector
%
%   calls function stoch_specific_bc
%   SIFISS function: DJS; 17 March 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

  matr_dim=length(f);
  nvtx = length(xy); nbd=length(bound);
  nint=nvtx-nbd;
  null_col=sparse(matr_dim,nbd*P);
  null_row=sparse(nbd*P,matr_dim);

  dupl_nodes=1:matr_dim;
  dupl_bound=zeros(nbd*P,1);
  for k = 1:P
      l = nvtx*(k-1)*ones(nbd,1);
      dupl_bound((k-1)*nbd+1:k*nbd,1) = l+bound;
  end
  dupl_intern=setdiff(dupl_nodes,dupl_bound);

% compute rhs-multipliers
  [rhs_ind,beta] = stoch_rhs_multipliers(indset,P,norv);

% set boundary condition
  xbd=xy(bound,1); ybd=xy(bound,2);
  bc = zeros(nbd*P,1);
  temp_bc = stoch_specific_bc(xbd,ybd,norv);
  for m=0:norv
      ind_m = rhs_ind(1,m+1);
      if ind_m>0
         bc((nbd*(ind_m-1)+1):(nbd*ind_m),1) = temp_bc(:,m+1)*beta(1,m+1)*(sqrt(2))^noarv;
      end
  end
%% CAREFUL with beta(*,*) and sqrt(...)-factors above; things will change if b.c. have more stochastic components !

  Agal=a(dupl_intern,1:matr_dim);
  fgal=f(dupl_intern);
  fgal = fgal - Agal(:,dupl_bound)*bc;
  Agal=Agal(:,dupl_intern);

  x_gal=zeros(matr_dim,1);
  x_gal(dupl_bound)=bc;

return
