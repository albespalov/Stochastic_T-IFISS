function [var_x] = stoch_variance(x_gal,P,noarv)
%STOCH_VARIANCE computes the variance of the stochastic solution
%   var_x = stoch_variance(x_gal,P,noarv);
%   input
%          x_gal      coefficient vector for the stochastic solution
%          P          length of the index set
%          noarv      the number of active random variables
%   output
%          var_x      vector of values of the variance (at the mesh points)
%
%   SIFISS function: DJS; 17 March 2013.
% Copyright (c) 2013 A. Bespalov, C.E. Powell, D.J. Silvester

  nvtx = length(x_gal)/P;

% transforming x into (nvtx)-by-(P)-matrix
  x_matr = reshape(x_gal,nvtx,P);

  var_x = zeros(nvtx,1);
  for k = 2:P
      var_x(:) = var_x(:) + (x_matr(:,k)) .* (x_matr(:,k));
  end
  var_x(:) = var_x(:) ./ (2.0e0^noarv);

end % end function