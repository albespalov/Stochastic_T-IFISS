function [elerr_p,err_est] = stoch_diffpost_p1_bc_yp(elerror,aez,fez,...
                             xy,evt,eboundt,P,norv)
%STOCH_DIFFPOST_P1_BC_YP postprocesses YP-error estimator at boundary elements
%
%   [elerr_p,err_est] = stoch_diffpost_p1_bc_yp(elerror,aez,fez,...
%                                               xy,evt,eboundt,P,norv)
%
%   input:
%          elerror      elementwise error estimate (without bc imposition) 
%              aez      elementwise Poisson problem matrices
%              fez      elementwise rhs vectors
%               xy      vertex coordinate vector  
%              evt      element mapping matrix
%          eboundt      element edge boundary matrix 
%                P      length of the index set
%             norv      number of random variables
%
%   output:
%          elerr_p      elementwise error estimate
%          err_est      global error estimate 
%
% This function is based on the original TIFISS function DIFFPOST_P1_BC 
% (QL; 17 April 2011)
%
% Function(s) called:   stoch_localbc_yp
% 
%   TIFISS function: AB; 05 January 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  x = xy(:,1); 
  y = xy(:,2);
  nel = size(evt,1);
  lev = [evt,evt(:,1),evt(:,2)];
  
% Recovering the elementwise B0-norm for the spatial estimator eYP  
  elerr_p = elerror .* elerror;
  
  fprintf('   boundary correction...');
  
% Recompute contributions from elements with Dirichlet boundaries
  nboundelem = size(eboundt,1);
  ebdy = zeros(nel,1);
  edge = zeros(nel,1);
  
% Isolate boundary elements
  for j = 1:nboundelem
      elem = eboundt(j,1);
      ebdy(elem) = ebdy(elem) + 1; 
      edge(elem) = eboundt(j,2);
  end  
       
% If there are not elements with 2 boundary edges, skip this part
  if ~isempty(ebdy(ebdy==2))
      % Elements with 2 edges on the boundary
      % -------------------------------------------------------------------
      k2 = find(ebdy==2);         % Elements with 2 boundary edges
      nel2b = length(k2);         % Number of elements with 2 boundary edges 
      errelem_loc = zeros(1,3*P);
      fe_loc = zeros(1,3*P);
      % Loop over 2 boudary edge elements
      for el = 1:nel2b
          el2e = k2(el);
          edges = eboundt(eboundt(:,1) == el2e,2);
          % Set up local original matrix and local coordinates
          ae = squeeze(aez(el2e,:,:));
          xl = x(lev(el2e,:));
          yl = y(lev(el2e,:));
          for mod = 1:P
              col = 1+3*(mod-1):(3*mod);
              % Set up original rhs vector 
              fe = fez(el2e,col)';
              % Impose interpolated error as Dirichlet bc
              [bae,fe] = stoch_localbc_yp(ae,fe,edges,xl,yl,norv);  %localbc_p(ae,fe,edges,xl,yl); 
              % Solve local problem
              errelem_loc(1,col) = bae\fe;
              fe_loc(1,col) = fe;
          end
          elerr_p(el2e) = errelem_loc*fe_loc';
      end    
  end
  
 
% Elements with 1 edge on the boundary
% -------------------------------------------------------------------------
  k1 = find(ebdy==1);        % Elements with 1 boundary edge
  nel1b = length(k1);        % Number of elements with 1 boundary edge    
  errelem_loc = zeros(1,3*P);
  fe_loc = zeros(1,3*P); 
% Loop over 1 boundary edge elements
  for el = 1:nel1b
      el1e = k1(el);    
      edges = eboundt(eboundt(:,1)==el1e,2);
      % Set up local original matrix and local coordinates
      ae = squeeze(aez(el1e,:,:));
      xl = x(lev(el1e,:));
      yl = y(lev(el1e,:));
      for mod = 1:P
          col = 1+3*(mod-1):(3*mod);
          % Set up original rhs vector 
          fe = fez(el1e,col)';
          % Impose interpolated error as Dirichlet boundary condition
          [bae,fe] = stoch_localbc_yp(ae,fe,edges,xl,yl,norv);               
          % Solve local problem
          errelem_loc(1,col) = bae\fe;
          fe_loc(1,col) = fe;
      end
      elerr_p(el1e) = errelem_loc*fe_loc'; 
  end       
  
% Final updated error  
% -------------------------------------------------------------------------
  elerr_p = sqrt(elerr_p);
  err_est = norm(elerr_p,2);
  
  fprintf('done\n');
  fprintf('   estimated energy error after bc:  <strong>%10.4e</strong>\n',err_est);
 
end  % end function