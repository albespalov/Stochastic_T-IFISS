% STOCH_DIFFUSION
%
% Files
%   citation_stoch_tifiss           - citation information
%   genindex                        - builds index sets for multivariable polynomials
%   helpme_stoch_diffusion          - stochastic diffusion problem interactive help
%   m_sdiff                         - stochastic scalar problem exact mean based preconditioner
%   srecall                         - query the current stochastic problem in the workspace
%   stoch_convplot                  - plots the computed error estimates versus the overall number of dof
%   stoch_data2pgfplots             - creates .dat files to be read by pgfplots latex package
%   stoch_data2pgfplots3D           - creates .dat files to 3D plot using pgfplots package in latex 
%   stoch_detail_indset             - computes the detail index set from the current index set
%   stoch_diff_main                 - solves stochastic diffusion problems on square, L-shaped, or crack domain
%   stoch_diffpost                  - a posteriori error estimation for single-runs
%   stoch_diffpost_p1_xq            - computes XQ error estimator for stochastic P1 solution
%   stoch_diffpost_p1_yp            - computes hierarchical YP-estimate solving error residuals problems elementwise
%   stoch_diffpost_p1_yp_2level     - computes YP 2-level error estimator for stochastic Galerkin P1 solution
%   stoch_diffpost_p1_yp_bc         - imposes Dirichlet boundary conditions on boundary midpoints
%   stoch_diffpost_p1_yp_detcontrib - elementwise deterministic contributions in the spatial YP estimation
%   stoch_diffpost_p1_yp_linsys     - computes hierarchical YP-estimate solving the associated (fully) assembled linear system
%   stoch_edgeres_p1_yp             - computes YP edge residuals for P1 stochastic Galerkin solution
%   stoch_eff_indices               - computes the effectivity indices given a reference solution's energy norm
%   stoch_est_minresx               - MINRES solver with discretization error estimation for stochastic diffusion problems
%   stoch_est_minresy               - MINRES solver with discretization error estimation for stochastic diffusion problems
%   stoch_est_ritz                  - determines adaptive stopping criteria for STOCH_EST_MINRES
%   stoch_femp1_setup               - assembled P1 stochastic coefficient matrix generator
%   stoch_femp2_setup               - assembled P2 stochastic coefficient matrix generator
%   stoch_gauss_coeff               - evaluates stochastic coefficient at Gauss point
%   stoch_gauss_gradcoeff           - evaluates gradient of the stochastic coefficient at Gauss point
%   stoch_gauss_source              - evaluates stochastic source at Gauss point
%   stoch_gmatricesx                - generates stochastic G-matrices
%   stoch_gpqmatrices               - generates stochastic G-matrices for two input index sets
%   stoch_imposebcx                 - imposes Dirichlet boundary conditions for stochastic problem
%   stoch_indset                    - fast computation of total degree index set
%   stoch_init_spatial              - generates spatial grid
%   stoch_init_stoch                - sets up stochastic coefficients and the index set P
%   stoch_intres_p1_yp              - computes YP elementwise interior residuals for P1 stochastic Galerkin solution
%   stoch_kl_eigens                 - computes KL eigenvalues for the covariance function
%   stoch_matvecx                   - efficient matvec for sum of kronecker product matrices
%   stoch_p1fluxjmps                - vectorised edge jumps of P1 stochastic Galerkin solution
%   stoch_plotdata_p1               - plots solution, variance and YP/XQ-estimates for P1 approximations
%   stoch_plotdata_p2               - plots solution and variance for P2 approximations
%   stoch_pol_enrich                - adds marked indices to the current index set (polynomial enrichment)
%   stoch_refenergy                 - computes the reference solution and its energy
%   stoch_rhs_multipliers           - generates the vector of non-zero multipliers for the RHS of linear system
%   stoch_setup_and_solve           - sets up and solves the sGFEM linear system
%   stoch_specific_bc               - STOCH_ZERO_BC zero boundary condition 
%   stoch_specific_coeff            - STOCH_EIGEL_COEFF synthetic stochastic diffusion coefficient
%   stoch_specific_gradcoeff        - STOCH_EIGEL_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%   stoch_specific_rhs              - STOCH_UNIT_RHS unit deterministic RHS forcing function
%   stoch_test_wellposedness_KL     - estimates lower bound of the KL-type stochastic diffusion coefficient
%   stoch_test_wellposedness_powell - estimates lower bound of the Powell stochastic diffusion coefficient
%   stoch_trunc_gauss_coeff         - generates coefficients in recurrence relation for truncated gaussian pdf
%   stoch_trunc_gauss_coeffx        - generates coefficients in recurrence relation for truncated gaussian pdf
%   stoch_trunc_gauss_rv            - computes normalization constant for variance of truncated Gaussian random variables
%   stoch_variancex                 - computes the variance of the stochastic solution
%   stoch_wellposedness_test        - estimates the lower bound of stochastic diffusion coefficient
