%STOCH_DATA2PGFPLOTS creates .dat files to be read by pgfplots latex package
% 
% Provide the name of the file and a value for the energy reference solution 
% energyref. In case energyref is not available either because it is not 
% computable or it is not a matter of interest, just put a "fake" value anyway.
% 
% In order to work, this file requires the data produced at the end of
% the adaptive code, which have to be loaded in the workspace; this is the file:
% - stoch_adapt_final_output.mat
%
% The default data file created contains the following columns:
% - iterations                        (iter)
% - overall (internal) dofs           (dofs = #intvtx \times #indset)
% - number of elements                (nels)
% - cumulative Ntotal                 (Ncum = \sum_{\ell=0}^{L} \dim(V_\ell))
% - cardinality of the P index set    (cardP)
% - cardinality of the Q index set    (cardQ)
% - number of marked indices          (markInd)
% - number of active parameters       (arv)
% - computed energy ||xgal||_B        (energy)
% - global estimate                   (error)
% - xq-estimate (global)              (xq_one)
% - xq-estimate (marked indices)      (xq_two)
% - yp-estimate (global)              (yp_one)
% - yp-estimate (marked elems/edges)  (yp_two)
% - "true" energy error               (truerr)
% - effectivity indices               (effindices)
%
% File is save to /datafiles/filename.dat
%
%   TIFISS scriptfile: LR; 09 July 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  gohome, cd datafiles;

% File name
  filename = 'thetaX1.0_thetaP1.0.dat';

% Energy of reference solution (put the right value, or a fake one)
  energyref = 0.47014345057411006;
  
% Compute effectivity indices
  truenergyerr = sqrt( energyref^2 - energy_iter.^2 );  % || uref - uxp ||_B
  effindices   = error_iter ./ truenergyerr;            % estimator / || uref - uxp ||_B 

% Create data structure
  data = [((1:length(dofInt_iter))-1)', ...
          dofInt_iter',                 ... 
          nel_iter',                    ...
          Ncum_iter',                   ...
          cardP_iter',                  ...
          cardQ_iter',                  ...
          markind_iter',                ...
          arv_iter',                    ...
          energy_iter',                 ...
          error_iter',                  ...
          xqerrest_one_iter',           ...
          xqerrest_two_iter',           ...
          yperrest_one_iter',           ...
          yperrest_two_iter',           ...
          truenergyerr',                ...
          effindices'];
      
% Open file
  fid = fopen(filename,'w');
  if fid == -1, error('Error opening file!\n'); end        
% Save data
  fprintf(fid,'iter\t dofs\t nels\t Ncum\t cardP\t cardQ\t markInd\t arv\t energy\t error\t xq_one\t xq_two\t yp_one\t yp_two\t truerr\t effindices\n');
  fprintf(fid,'%d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\t %.9f\n',data');
% Close file
  fclose(fid);

% end scriptfile