function [var_x] = stoch_multilevel_variance(meshesP,nvtxP,x_gal,P)
%STOCH_MULTILEVEL_VARIANCE computes the variance of the stochastic solution
%
% [var_x] = stoch_multilevel_variance(meshesP,nvtxP,x_gal,P)
%
% input:
%     meshesP    cell array containing mesh data for all indices
%       nvtxP    vector containing the number of vertices of each mesh
%       x_gal    coefficient vector for the stochastic solution
%           P    length of the index set
%
% output:
%       var_x    vector of values of the variance
%                (at the vertices of the mesh associated with the 0-index)
%
%   TIFISS scriptfile: MR; 15 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri
  
  aux = cumsum(nvtxP);
  
% Compute variance
  var_x = zeros(nvtxP(1),1);
  for n = 2:P
      first_index = aux(n-1)+1;
      last_index = aux(n);
      coeff_n = griddata(meshesP{n}.xy(:,1),meshesP{n}.xy(:,2),x_gal(first_index:last_index),meshesP{1}.xy(:,1),meshesP{1}.xy(:,2));
      var_x = var_x + coeff_n.^2;
  end

end % end function