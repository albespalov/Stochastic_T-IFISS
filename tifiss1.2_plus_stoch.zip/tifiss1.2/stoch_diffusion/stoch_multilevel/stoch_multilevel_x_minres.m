function [x,resvec,info] = stoch_multilevel_x_minres(afun,mfun,f,maxit,tol,nout)
% STOCH_MULTILEVEL_X_MINRES iteratively solves symmetric indefinite systems with eigenvalue tracking
%
% [x,resvec,info] = stoch_multilevel_x_minres(afun,mfun,f,maxit,tol,nout);
%
% input:
%         afun         action of matrix (anonymous function)
%         mfun         action of preconditioner (anonymous function)
%            f         RHS vector
%        maxit         max number of iterations
%          tol         stopping tolerance
%         nout         output switch
%
% output:
%         x            iterative solution
%         resvec       vector of residual errors
%         info         computed eigenvalue estimates
%
% The function calls function HARMONIC_RITZ_X and the inbuilt MATLAB
% functions ITERAPP and ITERCHK.
%
%   X-IFISS function: DJS; 24 September 2019.
% Copyright (c) 2019 A. Bespalov, C.E. Powell, D.J. Silvester

  if (nargin<6)
      nout = 0;
  end
  checkcode = nout;

  fprintf('Call to STOCH_MULTILEVEL_xMINRES ...\n')
  [atype,afun,afcnstr] = iterchk(afun);
  if strcmp(atype,'matrix')
      error('Oops.. need function handle definition of afun')
  end
  [mtype,mfun,mfcnstr] = iterchk(mfun);
  if strcmp(mtype,'matrix')
      error('Oops.. need function handle definition of mfun')
  end
  
  rhs = f;
  x0 = zeros(size(rhs));
  na = length(f);
  n = na;

  Lambda_minus = [nan,nan,nan];
  lambda_minus = [nan,nan,nan];
  Lambda_plus = [nan,nan,nan];
  lambda_plus = [nan,nan,nan];
  b = rhs;
  x = x0;

% matrix-vector product
% res0 = b-Agal*x;
  res0 = b - iterapp('mtimes',afun,atype,afcnstr,x);
  res = zeros(n,1);
% preconditioning step
% res(1:na) = Ahandle(res0(1:na),aparams);
  res(1:na) = iterapp('mldivide',mfun,mtype,mfcnstr,res0(1:na));
  arr = sqrt(res0'*res); 
  erro = arr;
  resvec(1) = arr;
  errpde(1) = nan;

  R = zeros(4,1);

% Q contains rotations. c_k, s_k could be stored instead
  cc = zeros(2,1);
  ss = zeros(2,1);

% Lanczos vectors
  w0=zeros(n,1);

% Auxiliary vectors for updating solution
  p0 = zeros(n,1);
  p = zeros(n,1);
  v = res/arr; 
  w = res0/arr;
  F = arr*speye(2,1);
  i=0;
  tstart = cputime;
   
  while (i<maxit && erro>tol) % start of iteration loop
      i=i+1;
      i1=i+1;
    % Matrix-vector product
    % w1 = Agal*v;
      w1 = iterapp('mtimes',afun,atype,afcnstr,v);
      p1 = v;
      if i>1
          H(i-1,i) = H(i,i-1);
          w1 = w1 - w0*H(i-1,i);
      end
      H(i,i) = v'*w1;
      w1 = w1 - w*H(i,i);

    % Apply left precond P using P inner product for V
    % v(1:na,1) = Ahandle(w1(1:na),aparams);
      v(1:na,1)= iterapp('mldivide',mfun,mtype,mfcnstr,w1(1:na));
      H(i+1,i) = sqrt(v'*w1);
      if (H(i+1,i)~=0.)
          v=v/H(i+1,i);
          w1=w1/H(i+1,i);
      else
          return
      end

      if i>2
        % compute the ritz values
          lambda = harmonic_ritz_x(H,i);
          Lambda_minus = [Lambda_minus,lambda(1)];
          lambda_minus = [lambda_minus,lambda(2)];
          lambda_plus = [lambda_plus,lambda(3)];
          Lambda_plus = [Lambda_plus,lambda(4)];
      end

    % Apply previous rotations
      if i==1
          R(3) = H(1,1);
      end
      if i==2
          R(2:3,1) = GG*[H(1:i,i)];
          GGold = GG(:,2);
      end
      if i>2
          R(1,1) = GGold(1)*H(i-1,i);
          R(2,1) = GGold(2)*H(i-1,i);
          R(2:3,1) = GG*[R(2);H(i,i)];
          GGold = GG(:,2);
      end

    % Determine and apply new rotations
      nrm = sqrt(R(3)^2+H(i1,i)^2);
      GG(1,1) = abs(R(3))/nrm;
      GG(1,2) = R(3)/abs(R(3))*conj(H(i1,i))/nrm;
      GG(2,1) = -conj(GG(1,2));
      GG(2,2) = GG(1,1);
      R(3) = GG(1,:)*[R(3);H(i1,i)];
      F(1:2) = GG*F(1:2);

    % Update approx solution
      p1 = (p1 - p0*R(1)-p*R(2))/R(3);
      x  = x + p1*F(1);
      F(1:2) = [F(2);0];
      w0 = w;
      w = w1;
      p0 = p;
      p = p1;
      erro = full(abs(F(1)));
      resvec = [resvec,erro];
    
  end % end of iteration loop

  etoc = cputime - tstart;
  fprintf('Bingo!')
  fprintf(' Convergence in %3i iterations (%.5f sec)\n',i,etoc);
  info = [Lambda_minus(i),Lambda_minus(i),lambda_plus(i),Lambda_plus(i)];

  if checkcode
      fprintf('\n Eigenvalue estimates ..')
      fprintf('\n    k      lambda      Lambda \n')
      for its = 4:i+1
          fprintf('%5i %11.4f %11.4f\n',its-1,lambda_plus(its-1),Lambda_plus(its-1));
      end
      fprintf('\n')
      fprintf('Total CPU time was %9.4e seconds\n',etoc)
  end
  info = [info,i+1]; % number of iterations

end