%STOCH_MULTILEVEL_DISPLAY_INFO_DEBUG prints data in the debugging mode
%
% If iDebugMode=1 in the main driver, then the following data is printed:
% - current P index set;
% - current detail Q index set with associated marked indices
%   (and estimates);
% - information about the current meshes
%   (with associated number of marked elements/edges);
% - number of total dofs;
% - estimated energy error.
%
%   TIFISS scriptfile: MR; 22 September 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

if iter == 0
    %
    % Initial data
    % 
    fprintf('\n* -----------------------------------------------------');
    fprintf('\n<strong>Initial data</strong>');
    fprintf('\n* -----------------------------------------------------');
    fprintf('\nInitial index set (%d indices):\n',P);
    [~,col] = find(indset);
    if isempty(col), col = 1; end
    for i = 1:P
        fprintf('  %i  ',indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('Active parameters: %d | polynomial degree: %d\n',noarv,polyd);
    %
    % Printing the initial Q index set
    Q = size(Q_indset,1);  
    [~,col] = find(Q_indset);
    fprintf('Initial Q index set:\n');
    for i = 1:Q
        fprintf('  %i  ',Q_indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('Initial mesh (assigned to all indices):',P);
    fprintf('\n  Number of vertices:   %d',size(mesh0.xy,1));
    fprintf('\n  Number of elements:   %d',size(mesh0.evt,1));
    fprintf('\n  Number of total dof:  %d',P*length(mesh0.interior));
    fprintf('\n* -----------------------------------------------------\n');
    fprintf('press any key to continue...\n'); 
    pause
    
else
    %
    % Data during the current iteration
    %    
    fprintf('\n* -----------------------------------------------------');
    fprintf('\n<strong>Current data during iteration %d</strong>',iter);
    fprintf('\n* -----------------------------------------------------');
    fprintf('\nCurrent index set (%d indices):\n',P);
    [~,col] = find(indset);
    if isempty(col), col = 1; end
    for i = 1:P
        fprintf('  %i  ',indset(i,1:max(col))); fprintf('  0    0  ...\n');
    end
    fprintf('Active parameters: %d | polynomial degree: %d\n',noarv,polyd);
    %   
    % Printing the current Q index set and the corresponding estimators for
    % its indices         
    Q = size(Q_indset,1);  
    [~,col] = find(Q_indset);
    fprintf('Current Q index set and corresponding index estimates:\n');
    for i = 1:Q
        fprintf('  %i  ',Q_indset(i,1:max(col))); fprintf('  0    0  ...');
        fprintf('   <-  %.6f',xq_err_vec(i));
        if ismember(i,M_ind)
            fprintf('  (Marked)');
        end
        fprintf('\n');
    end
    % Printing information about the spatial discretization
    fprintf('Current meshes:\n',P);
    for i = 1:P
        fprintf('  Mesh %i: %d vertices, %d elements, ',...
            i,size(meshesP{i}.xy,1),size(meshesP{i}.evt,1));
        if markedgelem == 1 % marking elements
            fprintf('%d marked elements\n',size(MsetP{i},1));
        else % marking indices
            fprintf('%d marked edges\n',size(MsetP{i},1));
        end
    end    
    fprintf('Number of total dof:    %d',length(x_gal));
    fprintf('\nEstimated energy error: %2.5e',tot_err_est);
    fprintf('\n* -----------------------------------------------------\n');
    fprintf('press any key to continue...\n'); 
    pause
    
end

% end scriptfile