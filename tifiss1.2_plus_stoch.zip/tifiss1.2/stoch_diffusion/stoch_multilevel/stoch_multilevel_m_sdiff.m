function x_it  = stoch_multilevel_m_sdiff(x,K,nintP)
%STOCH_MULTILEVEL_M_SDIFF implements the action of the mean based preconditioner
%
% x_it = stoch_multilevel_m_sdiff(x,K,nintP)
%
% input
%         x    operand for preconditioning operator
%         K    cell structure containing the stifness matrices 
%     nintP    vector containing the number of interior indices of each mesh
%
% output
%      x_it    result of the preconditioning operation
%
%   TIFISS function: MR; 10 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Initialization
  [p,~,~] = size(K);
  r=x;
  rn0=norm(r);

% -------------------------------------------------------------------------  
% Solve the system
% -------------------------------------------------------------------------

  for i_ind = 1:p
      nint = nintP(i_ind);
      start = sum(nintP(1:(i_ind-1)));
    % Extract the mean stiffness matrix
      Amean = K{i_ind,i_ind,1};
    % Fast (LU factorisation) solver using LUPQ
      [L,U,PP,QQ] = lu(Amean);
      L=PP\L; U = U/QQ;
      r(start+1:start+nint) = U\(L\x(start+1:start+nint));
  end

  x_it=r;

end % end function


