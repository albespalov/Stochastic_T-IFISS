function [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(mesh1,mesh2)
%STOCH_MULTILEVEL_MESH_INTERSECTION finds intersection of two meshes
%
% [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(mesh1,mesh2)
% 
% input:
%            mesh1     first mesh  
%            mesh2     second mesh
%
% output:
%           T1toT2     vector of length Nelem1, T1toT2(i) = j \neq 0 if the
%                      element i of mesh1 is contained in the element j of
%                      mesh2. T1toT2(i) = 0 if there is no element of mesh2
%                      containing the element i of mesh1
%     T2toT1strict     vector of length Nelem2, T2toT1strict(i) = j \neq 0
%                      if the the element i of mesh2 is STRICTLY contained
%                      in the element j of mesh1. T2toT1strict(i) = 0 if
%                      there is no element of mesh1 containing the element
%                      i of mesh2
%
% The algorithm implemented in this function is discussed in [BPR21, Algorithm 9]
%
% Reference:
% [BPR21] Bespalov, Praetorius, Ruggeri, Two-Level a Posteriori Error Estimation
% for Adaptive Multilevel Stochastic Galerkin Finite Element Method,
% SIAM/ASA J. Uncertain. Quantif., 9(3), 1184-1216, 2021.
%
%   TIFISS function: MR; 3 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Number of elements
  nel1  = size(mesh1.evt,1);
  nel2  = size(mesh2.evt,1);
  nel0  = max(mesh1.T0ancestor); % initial mesh
    
% Recover local coordinates (mesh1)
  xl_v1 = zeros(nel1,3);
  yl_v1 = zeros(nel1,3);
  for ivtx = 1:3
      xl_v1(:,ivtx) = mesh1.xy( mesh1.evt(:,ivtx), 1);
      yl_v1(:,ivtx) = mesh1.xy( mesh1.evt(:,ivtx), 2); 
  end
  % Recover local coordinates (mesh2)
  xl_v2 = zeros(nel2,3);
  yl_v2 = zeros(nel2,3);
  for ivtx = 1:3
      xl_v2(:,ivtx) = mesh2.xy( mesh2.evt(:,ivtx), 1);
      yl_v2(:,ivtx) = mesh2.xy( mesh2.evt(:,ivtx), 2); 
  end
  
  % Inizialization of the output
  T1toT2 = zeros(nel1,1);
  T2toT1strict = zeros(nel2,1);
  
  for j=1:nel0 % loop over all elements T_j of mesh0

    % determine elements of mesh1 and mesh2 which have T_1 as T0-ancestor
      candidates1 = find(mesh1.T0ancestor == j);
      candidates2 = find(mesh2.T0ancestor == j);

    % number of descendants of T_j in mesh1 (there exists at least 1)
      nCand1 = length(candidates1);
    
      for i=1:nCand1 % loop over all elements T_i of candidates1
          
        % among the elements in candidates2, determine those with level <= level(T_i)
        % (note that this set might be empty, e.g., if mesh2 is a refinement of mesh1)
          selectedCandidates2 = candidates2(  mesh2.level(candidates2) <= mesh1.level(candidates1(i))  );
      
        % compute the barycentric coordinates of center of mass of T_i wrt all
        % selected candidates of mesh2
          jac = (yl_v2(selectedCandidates2,2)-yl_v2(selectedCandidates2,3)).*(xl_v2(selectedCandidates2,1)-xl_v2(selectedCandidates2,3)) ...
                  + (xl_v2(selectedCandidates2,3)-xl_v2(selectedCandidates2,2)).*(yl_v2(selectedCandidates2,1)-yl_v2(selectedCandidates2,3));
          lambda1 = ((yl_v2(selectedCandidates2,2)-yl_v2(selectedCandidates2,3)).*(mesh1.centerOfMass(candidates1(i),1)-xl_v2(selectedCandidates2,3)) ...
                  + (xl_v2(selectedCandidates2,3)-xl_v2(selectedCandidates2,2)).*(mesh1.centerOfMass(candidates1(i),2)-yl_v2(selectedCandidates2,3)))./jac;
          lambda2 = ((yl_v2(selectedCandidates2,3)-yl_v2(selectedCandidates2,1)).*(mesh1.centerOfMass(candidates1(i),1)-xl_v2(selectedCandidates2,3)) ...
                  + (xl_v2(selectedCandidates2,1)-xl_v2(selectedCandidates2,3)).*(mesh1.centerOfMass(candidates1(i),2)-yl_v2(selectedCandidates2,3)))./jac;
          lambda3 = 1-lambda1-lambda2;

        % among the selected candidates of mesh2, determine the element which
        % contains T_i
          intersection = selectedCandidates2(  ( (lambda1>0) + (lambda2>0) + (lambda3>0) ) == 3  );
    
        % If such an element exists (and there exists at most one), then assign
        % it to T_i in T1toT2.
        % Otherwise there are some elements of candidates\selectedCandidates in
        % mesh2 (at least two), which are strictly contained in T_i
        % In this case we determine them by checking the baricentric
        % coordinates of their centers of mass and assign T_i to them in T2toT1strict
          if ~isempty(intersection)
              T1toT2(candidates1(i)) = intersection;
          else
              nonSelectedCandidates2 = setdiff(candidates2,selectedCandidates2);
              jac = (yl_v1(candidates1(i),2)-yl_v1(candidates1(i),3))*(xl_v1(candidates1(i),1)-xl_v1(candidates1(i),3)) ...
                   + (xl_v1(candidates1(i),3)-xl_v1(candidates1(i),2))*(yl_v1(candidates1(i),1)-yl_v1(candidates1(i),3));
              lambda1 = ((yl_v1(candidates1(i),2)-yl_v1(candidates1(i),3))*(mesh2.centerOfMass(nonSelectedCandidates2,1)-xl_v1(candidates1(i),3)) ...
                       + (xl_v1(candidates1(i),3)-xl_v1(candidates1(i),2))*(mesh2.centerOfMass(nonSelectedCandidates2,2)-yl_v1(candidates1(i),3)))./jac;
              lambda2 = ((yl_v1(candidates1(i),3)-yl_v1(candidates1(i),1))*(mesh2.centerOfMass(nonSelectedCandidates2,1)-xl_v1(candidates1(i),3)) ...
                       + (xl_v1(candidates1(i),1)-xl_v1(candidates1(i),3))*(mesh2.centerOfMass(nonSelectedCandidates2,2)-yl_v1(candidates1(i),3)))./jac;
              lambda3 = 1-lambda1-lambda2;
              intersection = nonSelectedCandidates2(  ( (lambda1>0) + (lambda2>0) + (lambda3>0) ) == 3  );
              T2toT1strict(intersection) = candidates1(i);
          end
          
      end % end loop over all elements T_i of candidates1

  end % end loop over all elements T_j of mesh0

end  % end function