function [nonzeroG] = stoch_multilevel_compute_nonzeroG(G)
%STOCH_MULTILEVEL_COMPUTE_NONZEROG determines nonzero entries of G-matrices
%(for which stifness matrices should be computed)
%
% [nonzeroG] = stoch_multilevel_compute_nonzeroG(G)
%
% input:
%               G      a (1 x (noarv+1)) cell of G-matrices
% output: 
%        nonzeroG      a (1 x (noarv+1)) cell of matrices
%
% For each m, nonzeroG{m} is a nnz-by-2 matrix, where nnz is 1/2 of the
% number of nonzero entries of G_m, which contains the indices of the
% nonzero entries of G_m.
%
% See also STOCH_GMATRICES
%
%   TIFISS function: AB; 3 January 2022
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  M = size(G,2); % noarv+1;
  nonzeroG = cell(size(G));

  for m=1:M
      [i,j] = find(G{m});
    % Indices of the nonzero entries of G_m
      temp = [i,j];
    % Remove duplicates due to symmetry of the matrix
      [~,idx] = unique(sort(temp,2),'rows','stable');
      nonzeroG{m} = temp(idx,:);
  end

end % end function