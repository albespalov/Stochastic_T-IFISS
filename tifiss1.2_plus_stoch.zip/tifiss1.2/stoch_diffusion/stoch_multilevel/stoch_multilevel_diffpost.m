%STOCH_MULTILEVEL_DIFFPOST performs a posteriori error estimation for the adaptive algorithm
%
% The script implements P1-based a posteriori error estimation for the
% stochastic Galerkin FE approximation.
% The estimation of the spatial component of the error is based on the
% 2-level error estimator

% NOTE that it is possible to choose between red and bisec3 uniform  
% sub-divisions for the spatial estimation by changing the variable 'subdivPar'; 
% see STOCH_ADAPT_INIT_PARAM.
%
% The global error estimate is returned in the variable "tot_err_est".
%
% Function(s) called: stoch_gpqmatrices
%                     stoch_multilevel_compute_nonzeroG
%                     stoch_multilevel_diffpost_p1_yp_2level
%                     stoch_multilevel_diffpost_p1_xq
%
% See also STOCH_ADAPT_DIFFPOST
%
%   TIFISS scriptfile: MR; 24 September 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  fprintf('\n<strong>ESTIMATE</strong>');

  estTime = tic;

  if pmethod == 1      
      fprintf('\n<strong>A posteriori error estimation for P1 approximations:</strong>\n');
      
    % ---------------------------------------------------------------------
    % YP error estimation 
    % ---------------------------------------------------------------------
    % The estimation is based on the full detail space Y composed of basis
    % functions associated with all edge midpoints. 
      fprintf('<strong>YP-error estimation</strong>\n');
      yptime = tic;
    % Compute 2-level error estimator
    % (both element and edge indicators returned)
      fprintf('   Spatial 2-level error estimator\n');      
      [yp_elerr,yp_ederr,yp_err_est] = stoch_multilevel_diffpost_p1_yp_2level(meshesP,nvtxP,...
                         x_gal,G,nonzeroG,norv,noarv,KL_DATA,subdivPar);      
      fprintf('   YP-error estimation took %.5f sec',toc(yptime));      
      
    % ---------------------------------------------------------------------
    % XQ error estimator
    % ---------------------------------------------------------------------
      if polenr_or_meshref ~= 2 % If parametric enrichment has occurred
        % Compute new G-matrices for P and Q index set (of size Q-by-P)
          [GPQ] = stoch_gpqmatrices(indset,Q_indset);
    % else
        % The old ones can be used
      end 
      fprintf('\n<strong>XQ-error estimation</strong>\n');
      xqtime = tic;
    % Determine the pair of indices in P x Q with nonzero associated
    % coefficients in the GPQ matrices
      nonzeroGPQ = stoch_multilevel_compute_nonzeroG(GPQ);
    % Compute parametric error estimate
      [xq_err_vec,xq_err_est] = stoch_multilevel_diffpost_p1_xq(x_gal,indset,meshesP,nvtxP,...
                                                                        Q_indset,meshesQ,GPQ,nonzeroGPQ,...
                                                                        norv,KL_DATA);
      fprintf('   XQ-error estimation took %.5f sec',toc(xqtime));
    % Parametric elementwise error estimates are not meaningful anymore in
    % the multilevel setting (one should have one such vector for each
    % parameter)
      xq_elerr = 0;
      
% elseif pmethod == 2
    % Not implemented yet...

  end
  
% -------------------------------------------------------------------------
% Compute total error estimate and print estimates
% -------------------------------------------------------------------------
  tot_err_est = sqrt( xq_err_est^2 + yp_err_est^2 );
  fprintf('\n-> Simplistic YP-estimate of energy error: %10.4e',yp_err_est);
  fprintf('\n-> Simplistic XQ-estimate of energy error: %10.4e',xq_err_est);
  fprintf('\n-> Simplistic estimate of energy error:    <strong>%10.4e</strong>\n',tot_err_est);  
  fprintf('Totale ESTIMATE time = %.5f sec\n',toc(estTime));
  
% end scriptfile