%STOCH_MULTILEVEL_INIT_SPATIAL generates a (coarse) spatial grid for the adaptive loop
% 
% The domains currently available are the square, L-shaped, and crack domains.
%
% Variables returned are:
%       dom_type      domain type (used by SRECALL)
%          mesh0      structure containing initial mesh
%
% Function(s) called: square_domain_ml
%                     p1grid
%                     ell_domain_ml
%                     ell_domain_unstructured_ml
%                     crack_domain_large_ml
%                     adjust_unstruct_mesh
%                     plot_mesh
%                     tedgegen
%                     p1grid_detail_space
%                     stoch_multilevel_center_of_mass
%
% See also STOCH_MULTILEVEL_INIT_PARAM, STOCH_MULTILEVEL_INIT_STOCH
%
%   TIFISS scriptfile: AB; 26 November 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Initialization of the initial mesh
mesh0 = struct('xy',         [],   ...
               'evt',        [],   ...
               'interior',   [],   ...
               'bound',      [],   ...
               'level',      [],   ...
               'T0ancestor', [],   ...
               'centerOfMass', [], ...
               'eboundt',    [],   ...
               'els',        [],   ...
               'eex',        [],   ...
               'tve',        [],   ...
               'xyY',        [],   ...
               'evtY',       [],   ...
               'boundY',     [],   ...
               'Ybasis',     []);

% -------------------------------------------------------------------------  
% Domain generation 
% -------------------------------------------------------------------------
  fprintf('\n<strong>Coarse grid generation for a </strong>');
  if dom_type == 1
      % ------------------------------------------------------------------
      % Unit square domain (0,1)^2; structured mesh
      % ------------------------------------------------------------------
      fprintf('<strong>unit square domain</strong>\n');
      square_domain_ml(1,1);
      load square_grid;
      [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
         
  elseif dom_type == 2
      % ------------------------------------------------------------------
      % Reference square domain (-1,1)^2; structured mesh
      % ------------------------------------------------------------------
      fprintf('<strong>reference square domain</strong>\n');
      square_domain_ml(2,0);
      load square_grid; 
      [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
  
  elseif dom_type == 3
      % ------------------------------------------------------------------
      % L-shaped domain (-1,1)^2 \ (-1,0]^2
      % ------------------------------------------------------------------
      fprintf('<strong>L-shaped domain</strong>');
      mesh_type = default('\nStructured/unstructured mesh 1/2 (default 1)',1);
      if mesh_type == 1
          ell_domain_ml;
          load ell_grid;
          [evt,eboundt] = p1grid(xy,mv,bound,mbound,0);
      elseif mesh_type == 2
          ell_domain_unstructured_ml;
          load ell_grid;
          % For unstructured meshes reorder the nodes of each element in evt
          [evt,xy,eboundt] = adjust_unstruct_mesh(evt,xy,eboundt);
      else
          error('Invalid mesh type'); 
      end
        
  elseif dom_type == 4
      % ------------------------------------------------------------------
      % Large crack domain (-1,1)^2 \ (-1,0)x{0} (crack on the left)
      % ------------------------------------------------------------------
      fprintf('<strong>crack domain</strong>');
      crack_domain_large_ml;
      load crack_grid;
  end

% Plot the starting mesh
  plot_mesh(evt,xy,'Initial mesh'); 

% Total nodes and interior nodes
  totalnodes = 1:size(xy,1);
  interior = totalnodes(~ismember(totalnodes,bound));

% Element refinement levels
  level = zeros(size(evt,1),1);
  
% Compute edge connections for the initial (coarse) mesh
  [eex,tve,els] = tedgegen(xy,evt); 
  
% Compute the detail space Y for the initial space X 
  [evtY,xyY,boundY,Ybasis] = p1grid_detail_space(xy,evt);

% Save all data for the initial mesh into the preallocated structure
  mesh0.xy = xy;
  mesh0.evt = evt;
  mesh0.interior = interior';
  mesh0.bound = bound;
  mesh0.level = level;
  mesh0.T0ancestor = [1:size(evt,1)]';
  mesh0.centerOfMass = stoch_multilevel_center_of_mass(xy,evt);
  mesh0.eboundt = eboundt;
  mesh0.els = els;
  mesh0.eex = eex;
  mesh0.tve = tve;
  mesh0.xyY = xyY;
  mesh0.evtY = evtY;
  mesh0.boundY = boundY;
  mesh0.Ybasis = Ybasis;

% Clear unused variables
  clear xy evt interior bound level eboundt els eex tve xyY evtY boundY ...
      Ybasis totalnodes stretch x y outbc mv mesh_type mbound ...
      grid_type x y T0ancestor

% end scriptfile