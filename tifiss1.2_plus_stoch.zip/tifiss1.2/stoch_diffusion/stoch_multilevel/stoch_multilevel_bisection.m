function [evt,level,T0ancestor] = stoch_multilevel_bisection(MMelem,MMedge,markEdge,evt,evtY,level,T0ancestor)
%STOCH_MULTILEVEL_BISECTION performs bisections of marked elements/edges 
%
% [evt,level,T0ancestor] = stoch_multilevel_bisection(MMelem,MMedge,markEdge,evt,evtY,level,T0ancestor)
%
% input:
%         MMelem      vector of (overall) marked elements
%         MMedge      vector of (overall) marked edges to be refined
%       markEdge      marked edge-midpoint-position vector
%            evt      element mapping matrix (before refinement)
%           evtY      element mapping matrix for midpoints (before refinement)
%          level      level vector (before refinement)
%     T0ancestor      T0ancestor vector (before refinement)
%
% output: 
%            evt      element mapping matrix (after refinement)
%          level      level vector (after refinement)
%     T0ancestor      T0ancestor vector (after refinement)
%
% The function extends the T-IFISS function BISECTION.
%
%   TIFISS function: MR; 4 June 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Extract marked elements according to the refinement type 1/2/3
  refxelem = sum( ismember( evtY(MMelem,:) , MMedge) , 2);
  Mone     = sort( MMelem( refxelem == 1 ) );                                     % Elements marked for 1 bisection
  Mtwo     = MMelem( refxelem == 2 );                                             % Elements marked for 2 bisections
  Mthree   = sort( MMelem( refxelem == 3 ) );                                     % Elements marked for 3 bisections
        
% -----------------------------------------------------------------------------
% STEP 1: refine elements marked for 1 bisection (green refinement)
% -----------------------------------------------------------------------------

  vtx      = evt(Mone,:);                                                         % Nodes of elements in Mone
  newnodes = full( markEdge( evtY(Mone,2) ) );                                    % Midpoints of longest edges of Mone

% Refine elements
  firstChild  = [Mone, vtx(:,2), newnodes, vtx(:,1)];                             % Top child elements
  secondChild = [Mone, vtx(:,3), newnodes, vtx(:,2)];                             % Bottom child elements

% Save elements
  newrows_one = [firstChild, secondChild];       
  newrows_one = reshape(newrows_one',4,2*length(Mone))';
% Save levels
  newlevel_one = [newrows_one(:,1), level(newrows_one(:,1))+1]; % level increased by 1
% Save T0 ancestors (inherited by parents)
  newT0ancestor_one = [newrows_one(:,1), T0ancestor(newrows_one(:,1))];
  
% Transform the new rows per each child in a cell array: it will be length(Mone) 
% long and each cell is a 2-by-4 matrix (where 2 is due to the 2 children)
  cell_one = mat2cell(newrows_one, 2*ones(1,size(newrows_one,1)/2), 4);
% Do the same for the levels of each child: it will be length(Mone) 
% long and each cell is a 2-by-2 matrix (where the first 2 is due to the 2 children)
  levelcell_one = mat2cell(newlevel_one, 2*ones(1,size(newrows_one,1)/2), 2);
% Do the same also for the T0 ancestors
  T0ancestorcell_one = mat2cell(newT0ancestor_one, 2*ones(1,size(newrows_one,1)/2), 2);
  
% -----------------------------------------------------------------------------
% STEP 2: refine elements marked for 2 bisections (blue refinement)
% -----------------------------------------------------------------------------

% Separate the elements marked for blue-left from those marked for blue-right 
% refinement. NOTE that: 
% - blue-left refinement means that (also) the 1st element's edge is bisected
% - blue-right refinement means that (also) the 3rd element's edge is bisected
  checkleft    = repmat( [1 1 0] , [size(Mtwo),1] );
  checkright   = repmat( [0 1 1] , [size(Mtwo),1] );
  markEdgesxel = ismember( evtY(Mtwo,:) , MMedge);
  Mtwoleft     = Mtwo( sum( abs(markEdgesxel - checkleft)  , 2) == 0 );           % Marked elements for blue-left refinement
  Mtworight    = Mtwo( sum( abs(markEdgesxel - checkright) , 2) == 0 );           % Marked elements for blue-right refinement
  Mtwoleft     = sort( Mtwoleft  );
  Mtworight    = sort( Mtworight );
  
% Allocate an empty vector for all children space
  [firstChildLeft,  secondChildLeft,  thirdChildLeft ,...
   firstChildRight, secondChildRight, thirdChildRight] = deal([]); 
  
  if ~isempty(Mtwoleft) 
      vtxLeft     = evt(Mtwoleft,:);                                              % Nodes of elements in Mtwoleft 
      leNodeLeft  = full( markEdge( evtY(Mtwoleft,2) ) );                         % Midpoints of longest edges of Mtwoleft's elements
      mrkNodeLeft = full( markEdge( evtY(Mtwoleft,1) ) );                         % Midpoints of 1st edges of Mtwoleft's elements
    % Left-Blue refinement
      firstChildLeft  = [Mtwoleft, vtxLeft(:,2),  leNodeLeft, vtxLeft(:,1)];      % Top child elements (largest child)
      secondChildLeft = [Mtwoleft, vtxLeft(:,2), mrkNodeLeft,   leNodeLeft];      % Middle child elements
      thirdChildLeft  = [Mtwoleft,   leNodeLeft, mrkNodeLeft, vtxLeft(:,3)];      % Bottom child elements
  end
  
  if ~isempty(Mtworight)
      vtxRight     = evt(Mtworight,:);                                            % Nodes of elements in Mtworight
      leNodeRight  = full( markEdge( evtY(Mtworight,2) ) );                       % Midpoints of longest edges of Mtworigth's elements
      mrkNodeRight = full( markEdge( evtY(Mtworight,3) ) );                       % Midpoints of 3rd edges of Mtworight's elements
    % Right-Blue refinement
      firstChildRight  = [Mtworight, vtxRight(:,1), mrkNodeRight,   leNodeRight]; % Top child elements
      secondChildRight = [Mtworight,   leNodeRight, mrkNodeRight, vtxRight(:,2)]; % Middle child elements
      thirdChildRight  = [Mtworight, vtxRight(:,3),  leNodeRight, vtxRight(:,2)]; % Bottom child elements (largest child)
  end
  
% Save elements  
  newrows_two_left  = [firstChildLeft,  secondChildLeft,  thirdChildLeft];
  newrows_two_left  = reshape(newrows_two_left',4,3*length(Mtwoleft))';
  newrows_two_right = [firstChildRight, secondChildRight, thirdChildRight];
  newrows_two_right = reshape(newrows_two_right',4,3*length(Mtworight))';

% Save levels
% For firstChildLeft and thirdChildRight the level should be increased by
% 1, while for the other four children it should be increased by 2
  newlevel_two_left = [newrows_two_left(:,1), level(newrows_two_left(:,1))+repmat([1;2;2],length(Mtwoleft),1)];
  newlevel_two_right = [newrows_two_right(:,1), level(newrows_two_right(:,1))+repmat([2;2;1],length(Mtworight),1)];

% Save T0 ancestors (inherited by the parents)
  newT0ancestor_two_left  = [newrows_two_left(:,1),  T0ancestor(newrows_two_left(:,1))];
  newT0ancestor_two_right = [newrows_two_right(:,1), T0ancestor(newrows_two_right(:,1))];

% Transform the new rows per each child in cells array: they will be length(Mtwoleft) 
% and length(Mtworight) long and each cell would be a 3-by-4 matrix 
% (where 3 is due to the 3 children)
  cell_two_left  = mat2cell(newrows_two_left,  3*ones(1,size(newrows_two_left,1)/3),  4);
  cell_two_right = mat2cell(newrows_two_right, 3*ones(1,size(newrows_two_right,1)/3), 4);

% Do the same for the levels of each child: they will be length(Mtwoleft) and
% length(Mtworight) long and each cell is a 3-by-2 matrix (where 3 is due to the 3 children)
  levelcell_two_left = mat2cell(newlevel_two_left, 3*ones(1,size(newrows_two_left,1)/3), 2);
  levelcell_two_right = mat2cell(newlevel_two_right, 3*ones(1,size(newrows_two_right,1)/3), 2);

% Do the same for the T0 ancestors
  T0ancestorcell_two_left = mat2cell(newT0ancestor_two_left, 3*ones(1,size(newrows_two_left,1)/3), 2);
  T0ancestorcell_two_right = mat2cell(newT0ancestor_two_right, 3*ones(1,size(newrows_two_right,1)/3), 2);

% -----------------------------------------------------------------------------             
% STEP 3: refine elements marked for 3 bisections (bisec3 refinement)
% -----------------------------------------------------------------------------

  vtx           = evt(Mthree,:);                                                  % Nodes of elements in Mthree
  leNode        = full( markEdge( evtY(Mthree,2) ) );                             % Midpoints of longest edges of Mthree
  mrkNodeLeft   = full( markEdge( evtY(Mthree,1) ) );                             % Midpoints of 1st edges of Mthree
  mrkNodeRight  = full( markEdge( evtY(Mthree,3) ) );                             % Midpoints of 3rd edges of Mthree
  
% Refine elements
  firstChild    = [Mthree, vtx(:,1), mrkNodeRight,   leNode];                     % Top child elements
  secondChild   = [Mthree,   leNode, mrkNodeRight, vtx(:,2)];                     % First middle child elements
  thirdChild    = [Mthree, vtx(:,2),  mrkNodeLeft,   leNode];                     % Second middle child elements
  fourthChild    = [Mthree,   leNode,  mrkNodeLeft, vtx(:,3)];                    % Bottom child elements

% Save elements
  newrows_three = [firstChild, secondChild, thirdChild, fourthChild];
  newrows_three = reshape(newrows_three',4,4*length(Mthree))';
% Save levels
  newlevel_three = [newrows_three(:,1), level(newrows_three(:,1))+2]; % level increased by 2
% Save T0 ancestors (inherited by parents)
  newT0ancestor_three = [newrows_three(:,1), T0ancestor(newrows_three(:,1))];

% Transform the new rows per each child in a cell array: it will be length(Mthree) 
% long and each cell would be a 4-by-4 matrix (where 4 is due to the 4 children)
  cell_three = mat2cell(newrows_three, 4*ones(1,size(newrows_three,1)/4), 4);
% Do the same for the levels of each child: it will be length(Mthree) 
% long and each cell is a 4-by-2 matrix (where 4 is due to the 4 children)
  levelcell_three = mat2cell(newlevel_three, 4*ones(1,size(newrows_three,1)/4), 2);
% The same for the T0 ancestors
  T0ancestorcell_three = mat2cell(newT0ancestor_three, 4*ones(1,size(newrows_three,1)/4), 2);

% -----------------------------------------------------------------------------
% STEP 4: create the new element mapping matrix
% -----------------------------------------------------------------------------    

% New elements are inserted in the current evt in the following way.
% Suppose the 23rd element was marked for 2 refinements. This will produce 3 
% children. Then, the 23rd row in evt should be deleted and 3 new rows 
% corresponding to the 3 children will take its place. The 3 children will 
% stay on the 23rd, 24th, and 25th row. 
% Accordingly, the old 24th row will become the 26th row.
% The insertion explained above is done by transforming the evt matrix in a cell array

% Create a cell containing the rows of evt (element)
  evt = [(1:size(evt,1))', evt];
  evtcell = mat2cell(evt, ones(1,size(evt,1)), 4);
% Do the same for the level vector
  levelcell = mat2cell([(1:size(evt,1))', level], ones(1,size(evt,1)), 2);
% Do the same for the T0 ancestors vector
  T0ancestorcell = mat2cell([(1:size(evt,1))', T0ancestor], ones(1,size(evt,1)), 2);

% Update elements with the new rows of all children that have to be inserted
  evtcell( Mone )      = cell_one(:);
  evtcell( Mtwoleft )  = cell_two_left(:);
  evtcell( Mtworight ) = cell_two_right(:);
  evtcell( Mthree )    = cell_three(:);
% Do the same for the level vector
  levelcell( Mone )      = levelcell_one(:);
  levelcell( Mtwoleft )  = levelcell_two_left(:);
  levelcell( Mtworight ) = levelcell_two_right(:);
  levelcell( Mthree )    = levelcell_three(:);
% Do the same for the T0 ancestors
  T0ancestorcell( Mone )      = T0ancestorcell_one(:);
  T0ancestorcell( Mtwoleft )  = T0ancestorcell_two_left(:);
  T0ancestorcell( Mtworight ) = T0ancestorcell_two_right(:);
  T0ancestorcell( Mthree )    = T0ancestorcell_three(:);
  
% Convert the cell to matrix
  evt = cell2mat( evtcell );  
  evt = evt(:,[2 3 4]);
% Do the same for the level vector
  level = cell2mat( levelcell );
  level = level(:,2);
% Do the same for the T0 ancestors
  T0ancestor = cell2mat( T0ancestorcell );
  T0ancestor = T0ancestor(:,2);

end % end function