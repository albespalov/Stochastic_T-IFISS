% STOCH_MULTILEVEL
%
% Files
%   crack_domain_large_ml                  - large crack domain (crack on the left) structured grid generator (for adaptive multilevel SGFEM)
%   ell_domain_ml                          - L-shaped domain structured grid generator (for adaptive multilevel SGFEM)
%   ell_domain_unstructured_ml             - L-shaped domain unstructured grid generator (for adaptive multilevel SGFEM)
%   harmonic_ritz_x                        - computes harmonic ritz values within X_MINRES
%   iterapp                                - allows to apply matrix operator to vector and error gracefully
%   iterchk                                - checks arguments to iterative methods.
%   square_domain_ml                       - square domain grid generator (for adaptive multilevel SGFEM)
%   stoch_multilevel_bisection             - performs bisections of marked elements/edges 
%   stoch_multilevel_center_of_mass        - computes the centers of mass of the elements of a mesh
%   stoch_multilevel_compute_nonzeroG      - determines nonzero entries of G-matrices
%   stoch_multilevel_convplot              - plots the computed error estimates versus the overall number of dof
%   stoch_multilevel_diff_main             - solves stochastic diffusion problem using adaptive multilevel SGFEM
%   stoch_multilevel_diffpost              - performs a posteriori error estimation for the adaptive algorithm
%   stoch_multilevel_diffpost_p1_xq        - computes XQ error estimator for adaptive multilevel stochastic P1 Galerkin solution
%   stoch_multilevel_diffpost_p1_yp_2level - computes YP 2-level error estimator for multilevel stochastic Galerkin P1 solution
%   stoch_multilevel_display_final_data    - prints the data at the end of adaptive loop
%   stoch_multilevel_display_info_debug    - prints data in the debugging mode
%   stoch_multilevel_eff_indices           - computes the effectivity indices using a precomputed reference energy
%   stoch_multilevel_femp1_setup           - assembles P1 stiffness matrices and the rhs vector needed by the SGFEM
%   stoch_multilevel_gpc_coefficient       - plots a gpc coefficient of the stochastic Galerkin solution
%   stoch_multilevel_imposebc              - imposes Dirichlet boundary conditions for stochastic problem
%   stoch_multilevel_init_param            - sets up parameters for adaptive algorithm
%   stoch_multilevel_init_spatial          - generates a (coarse) spatial grid for the adaptive loop
%   stoch_multilevel_init_stoch            - sets up stochastic coefficients and initial index sets for the adaptive loop
%   stoch_multilevel_m_sdiff               - implements the action of the mean based preconditioner
%   stoch_multilevel_marking               - performs spatial and parametric marking for the adaptive algorithm
%   stoch_multilevel_matvec                - implements the action of matrix-vector product for multilevel stochastic Galerkin matrices
%   stoch_multilevel_mesh_intersection     - finds intersection of two meshes
%   stoch_multilevel_mesh_ref              - performs mesh refinement based on longest-edge bisection (LEB) algorithm
%   stoch_multilevel_mesh_unif_ref         - performs uniform mesh refinement by bisec3
%   stoch_multilevel_plotdata              - plots solution and variance for P1 approximations
%   stoch_multilevel_pol_enrich            - performs polynomial enrichment and updates the mesh structures accordingly
%   stoch_multilevel_refenergy             - computes the reference solution and its energy
%   stoch_multilevel_setup_and_solve       - sets up and solves the SGFEM linear system
%   stoch_multilevel_update_vectors        - preallocates, updates, and resizes the output vectors in the adaptive loop
%   stoch_multilevel_variance              - computes the variance of the stochastic solution
%   stoch_multilevel_x_minres              - iteratively solves symmetric indefinite systems with eigenvalue tracking
