function [effindices] = stoch_multilevel_eff_indices(sn,errors,energies,varargin)
%STOCH_MULTILEVEL_EFF_INDICES computes the effectivity indices using a precomputed reference energy
%
% [effindices] = stoch_eff_indices(sn,errors,energies,varargin)
%
% input: 
%                sn   test problem identificator
%            errors   vector of computed global errors
%          energies   vector of energies norms of the Galerkin solutions
%             iplot   (optional) plot switch for the effectivity indices 0/1
%
% output:
%        effindices   vector of effectivity indices
%
% The effectivity indices are calculated via the formula:
%   effindices = errors / sqrt(refenergy^2 - energies^2)
% using the precomputed refenergy for each test problem
%
% See also STOCH_REFENERGY, STOCH_EFF_INDICES, STOCH_MULTILEVEL_REFENERGY
%
%   TIFISS function: AB; 3 January 2022
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  if nargin == 4
      iplot = varargin{1};
  else%if nargin < 4
      iplot = 0;
  end

% -----------------------------------------------------------------------------  
% Reference energies (precomputed for each test problem)
% -----------------------------------------------------------------------------  
  if sn == 1
      % Large square domain; KL expansion
      refenergy = 0.280484817867763;
      ref_dof = 958055;
  elseif sn == 2
      % Unit square domain; Eigel coefficient
      refenergy = 0.190117;
      ref_dof = 1081665;
  elseif sn == 3
      % Unit square domain; Powell coefficient
      refenergy = 0.190356177622232;
      ref_dof = 1287453;
  elseif sn == 4
      % L-shaped domain domain; synthetic coefficient
      refenergy = 0.464229669084879;
      ref_dof = 1092437;
  elseif sn == 5
      % L-shaped domain domain; Eigel coefficient
      refenergy = 0.47014853671327;
      ref_dof = 2932782;
  elseif sn == 6
      % L-shaped domain domain; Powell coefficient
      refenergy = 0.469772394444577;
      ref_dof = 1373061;
  elseif sn == 7
      % Large crack domain; Eigel coefficient
      refenergy = 0.579340010423284;
      ref_dof = 1389837;
  elseif sn == 8
      % Large crack domain; Powell coefficient
      refenergy = 0.283825462483537;
      ref_dof = 1661243;
  elseif sn == 9
      % Unit square domain; Finite expansion; Cookie problem
      refenergy = 1.89863647563607e-01;
      ref_dof = 3441281;
  end
  
  fprintf('\nUsing the precomputed reference solution with dof = %i...',ref_dof);
  pause(1);

% -----------------------------------------------------------------------------  
% Effectivity indices  
% -----------------------------------------------------------------------------  
  effindices = errors ./ sqrt( refenergy^2 - energies.^2 );

% -----------------------------------------------------------------------------  
% Plot
% -----------------------------------------------------------------------------  
  if iplot == 1  
      fontSizeAxes = 14;
      iter = length(errors);
      figure;
      semilogy(1:iter,effindices(1:iter),'-bo','Linewidth',1.5,'MarkerSize',10);
      hold on; grid on;
      axis([1 iter 0.6 1]);
      xlabel('iteration','FontSize',fontSizeAxes);
      ylabel('effectivity index','FontSize',fontSizeAxes);
      % Setup axis and window's dimension and position 
      set(gca,'YMinorTick','on','YTickMode','manual','YMinorGrid','off',...
              'GridLineStyle','--','FontSize',fontSizeAxes);      
      set(gcf,'units','normalized','Position',[0.25 0.2 0.55 0.65]);
  end
  
end % end function