function [xq_inderr,xq_err_est] = stoch_multilevel_diffpost_p1_xq(p1sol,indset,meshesP,nvtxP,...
                                         Q_indset,meshesQ,GPQ,nonzeroGPQ,norv,KL_DATA)
%STOCH_MULTILEVEL_DIFFPOST_P1_XQ computes XQ error estimator for adaptive multilevel stochastic P1 Galerkin solution
%
% [xq_inderr,xq_err_est] = stoch_multilevel_diffpost_p1_xq(p1sol,indset,...
%               meshesP,nvtxP,Q_indset,meshesQ,GPQ,nonzeroGPQ,norv,KL_DATA)
%                                       
% input:
%            p1sol    stochastic P1 solution vector
%           indset    index set of polynomial degrees
%          meshesP    cell array containing mesh data for all indices
%            nvtxP    vector containing the number of vertices of each mesh
%         Q_indset    current 'detail' index set
%          meshesQ    cell array containing mesh data for all detail indices
%              GPQ    current cell of GPQ-matrices
%       nonzeroGPQ    cell array containing nonzero entries of GPQ-matrices
%             norv    number of admissible random variables
%          KL_DATA    data related to KL-expansion
%
% output:
%           xq_inderr    vector of XQ index indicators (for each \mu \in Q_indset)
%          xq_err_est    global XQ energy error estimate
%
% The function solves the discrete formulations for the eXQ error indicator
%
%   B0(e_\mu,v) = F(v P_\nu) - B(uXP,v P_\nu)     for all v \in V_0    (1)
%
% for all indices \mu in Q.
% The error estimation strategy has been originally proposed in [BS16].
% Here, we consider its adaptation proposed in [BPS21] for multilevel sGFEM,
% where the underlying finite element space is the one associated with the
% initial mesh.
%
% References: 
% [BS16] Bespalov, Silvester, Efficient adaptive stochastic Galerkin methods for
% parametric operator equations, SIAM J. Sci. Comput., 38(4), A2127-A2128, 2016.
% [BPR21] Bespalov, Praetorius, Ruggeri, Two-Level a Posteriori Error Estimation
% for Adaptive Multilevel Stochastic Galerkin Finite Element Method,
% SIAM/ASA J. Uncertain. Quantif., 9(3), 1184-1216, 2021.
%
% Function(s) called: stoch_multilevel_mesh_intersection
%                     triangular_gausspoints
%                     tderiv
%                     stoch_gauss_coeff
% 
%   TIFISS function: MR; 4 June 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% -------------------------------------------------------------------------
% STEP 1: Set up
% -------------------------------------------------------------------------

% Length of the index set
  P = size(indset,1);
% Length of Q_indset
  Q = size(Q_indset,1);   

% Initialization
  xq_inderr = zeros(Q,1);
  
% Setting the effective number of active random variables needed for computation
  new_noarv = size(GPQ,2) - 1;  

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
% Gauss points and weights on the reference element
  [s,t,wt] = triangular_gausspoints(nngpt);
  
% Allocate cell array to hold the (in general rectangular) matrices
  K = cell(Q,P,new_noarv+1);
    
  for m = 0:new_noarv % loop over active random variables
 
      nmatrices = size(nonzeroGPQ{m+1},1); % number of matrices that need computing
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroGPQ{m+1}(b_index,1);
          j_ind = nonzeroGPQ{m+1}(b_index,2);
     
        % Get mesh data
          meshI = meshesQ{i_ind};
          nvtxI = size(meshI.xy,1);  % Number of vertices of mesh1
          nelI  = size(meshI.evt,1); % Number of elements of mesh1
      
        % Recover local coordinates (mesh I)
          xl_vI = zeros(nelI,3);
          yl_vI = zeros(nelI,3);
          for ivtx = 1:3
              xl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 1);
              yl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 2); 
          end  
        % xl_v (resp., yl_v) is a nel-by-3 matrix, whose i-th row contains
        % the x (resp., y) coordinates of the 3 vertices of the i-th element

        % Initialization vector containing integrals of coefficients
          intCoeffI = zeros(nelI,1);
         
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacI,invjacI,~,dphidxI,dphidyI] = tderiv(sigpt,tigpt,xl_vI,yl_vI);
              dphidxI = dphidxI.*invjacI;
              dphidyI = dphidyI.*invjacI;
              [coeffI] = stoch_gauss_coeff(sigpt,tigpt,xl_vI,yl_vI,norv,KL_DATA);
            % Build vector with elementwise integrals of the coefficients
              intCoeffI(:) = intCoeffI(:) + wght * coeffI(:,m+1) .* jacI(:); 
  
          end % end of loop over Gauss points
      
        % Get mesh data
          meshJ = meshesP{j_ind};
          nvtxJ = size(meshJ.xy,1);  % Number of vertices of mesh2
          nelJ  = size(meshJ.evt,1); % Number of elements of mesh2
   
        % Recover local coordinates (mesh J)
          xl_vJ = zeros(nelJ,3);
          yl_vJ = zeros(nelJ,3);
          for ivtx = 1:3
              xl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 1);
              yl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 2); 
          end

        % Initialization vector containing integrals of coefficients
          intCoeffJ = zeros(nelJ,1);
          
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacJ,invjacJ,~,dphidxJ,dphidyJ] = tderiv(sigpt,tigpt,xl_vJ,yl_vJ);
              dphidxJ = dphidxJ.*invjacJ;
              dphidyJ = dphidyJ.*invjacJ;
              [coeffJ] = stoch_gauss_coeff(sigpt,tigpt,xl_vJ,yl_vJ,norv,KL_DATA);
            % Build vector with elementwise integrals of the coefficients
              intCoeffJ(:) = intCoeffJ(:) + wght * coeffJ(:,m+1) .* jacJ(:);  
 
          end % end of loop over Gauss points

        % Build the vectors containing the information about mesh intersection
          [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(meshI,meshJ);
          
        % Allocate memory for local stiffness matrices
          adeI = zeros(nelI,3,3);
          adeJ = zeros(nelJ,3,3);

        % Building local stiffness matrices

          for k_elemI = 1:nelI
              if T1toT2(k_elemI)~=0
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeI(k_elemI,i,j) = intCoeffI(k_elemI)*(dphidxI(k_elemI,i)*dphidxJ(T1toT2(k_elemI),j) ...
                                                          + dphidyI(k_elemI,i) * dphidyJ(T1toT2(k_elemI),j));
                      end
                  end
              end
          end

          for k_elemJ = 1:nelJ
              if T2toT1strict(k_elemJ)~=0
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeJ(k_elemJ,i,j) = intCoeffJ(k_elemJ)*(dphidxI(T2toT1strict(k_elemJ),i)*dphidxJ(k_elemJ,j) ...
                                                         + dphidyI(T2toT1strict(k_elemJ),i) * dphidyJ(k_elemJ,j));
                      end
                  end
              end
          end
  
        % Assembly of global matrices
        
          ad = sparse(nvtxI,nvtxJ);

          aux = find(T1toT2>0);
        % Here aux contains the indices of elements of meshI which are
        % contained into an element of meshJ.
          for krow = 1:3
              nrow = meshI.evt(aux,krow);
              for kcol = 1:3
                  ncol = meshJ.evt(T1toT2(aux),kcol);
                  ad = ad + sparse(nrow,ncol,adeI(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end

          aux = find(T2toT1strict>0);
        % Here aux contains the indices of elements of meshJ which are
        % strictly contained into an element of meshI.
          for krow = 1:3
              nrow = meshI.evt(T2toT1strict(aux),krow);
              for kcol = 1:3
                  ncol = meshJ.evt(aux,kcol);
                  ad = ad + sparse(nrow,ncol,adeJ(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end
          
          K{i_ind,j_ind,m+1} = ad;
          
      end % end loop over the relevant indices
      
  end
    
  for q_ind=1:Q
      xy = meshesQ{q_ind}.xy;
      evt = meshesQ{q_ind}.evt;
      bound = meshesQ{q_ind}.bound;
  
      nvtx = size(xy,1);    % Number of vertices
      nel  = size(evt,1);   % Number of elements
     
    % Initialise local deterministic matrices and local coordinates
      ade = zeros(nel,3,3);

    % Recover local coordinates
      xl_v = zeros(nel,3);
      yl_v = zeros(nel,3);
      for ivtx = 1:3
          xl_v(:,ivtx) = xy( evt(:,ivtx), 1);
          yl_v(:,ivtx) = xy( evt(:,ivtx), 2); 
      end
  
      for igpt = 1:nngpt
          sigpt = s(igpt);
          tigpt = t(igpt);
          wght = wt(igpt);
    
          % Evaluate derivatives and coefficients
          [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigpt,tigpt,xl_v,yl_v);
          [coeff_v] = stoch_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
    
          % Element-wise stiffness matrices
          for j = 1:3
              for i = 1:3
                  ade(:,i,j) = ade(:,i,j) + wght * coeff_v(:,1) .* dphidx_v(:,i) .* dphidx_v(:,j) .* invjac_v(:);
                  ade(:,i,j) = ade(:,i,j) + wght * coeff_v(:,1) .* dphidy_v(:,i) .* dphidy_v(:,j) .* invjac_v(:);
              end
          end
      end
  
      % Deterministic block K_0 of the full matrix on the lhs
      K0 = sparse(nvtx,nvtx);
      for krow = 1:3
          nrow = evt(:,krow);	 
          for kcol = 1:3
              ncol = evt(:,kcol);	  
              K0 = K0 + sparse(nrow,ncol,ade(:,krow,kcol),nvtx,nvtx);
          end
      end
      
    % -----------------------------------------------------------------------------
    % Imposing Dirichlet boundary condition
    % -----------------------------------------------------------------------------
    % Note that these are zeros if bcs are non-parametric (deterministic)
    % and, as always assumed, (0,0,0,...) is not in Q_indset; this means the bcs 
    % matrix contains zero-columns from the 2nd to norv+1 column.
    % In this case, it suffices to put zero on boundary rows/columns, put 1 in
    % the corresponding diagonal entries, and set the RHS to zero in boundary 
    % positions, no matter whether bcs were homogeneous or not (here, we are in VXQ).
      K0(bound,:) = 0.0;
      K0(:,bound) = 0.0;
      K0(bound,bound) = speye(length(bound),length(bound));
  
    % -------------------------------------------------------------------------
    % STEP 4: assembling RHS of (1)
    % -------------------------------------------------------------------------
      
      ff = zeros(nvtx,1);
      Bx = zeros(nvtx,1);
      
    % Note that F(v) = 0 since f is deterministic and, as always assumed,
    % the index (0,0,...,0) is not in Q_indset  
      ff(bound)  = 0.0;

    % Assemble the vector Bx = b(u_gal,v_XQ)
      for m = 1:new_noarv % loop over active random variables
                          % (m=0 is skipped because GPQ{1} is zero)

          nmatrices = size(nonzeroGPQ{m+1},1); % number of matrices that have been computed
     
          for b_index=1:nmatrices
         
              i_ind = nonzeroGPQ{m+1}(b_index,1);
              if i_ind == q_ind
                  j_ind = nonzeroGPQ{m+1}(b_index,2);
                  nvtx_j = nvtxP(j_ind);
                  start_j = sum(nvtxP(1:(j_ind-1)));
                  Bx = Bx + GPQ{m+1}(i_ind,j_ind) * K{i_ind,j_ind,m+1} * p1sol(start_j+1:start_j+nvtx_j);
              end
            
          end
          
      end
      
      ff = ff - Bx;
      ff(bound,:)  = 0.0;
      xq_errgal = K0\ff;
      xq_inderr(q_ind) = sqrt(xq_errgal'*(K0*xq_errgal));
          
  end
         
  xq_err_est = norm(xq_inderr,2);
      
end % end function