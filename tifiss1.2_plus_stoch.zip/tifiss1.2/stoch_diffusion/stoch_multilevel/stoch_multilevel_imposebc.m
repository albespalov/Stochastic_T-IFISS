function [K,fgal,x_gal,dupl_intern] = stoch_multilevel_imposebc(Knbc,fnbc,nonzeroG,meshesP,nvtxP,nbndP,noarv)
%STOCH_MULTILEVEL_IMPOSEBC imposes Dirichlet boundary conditions for stochastic problem
%
% [K,fgal,x_gal,dupl_intern] = stoch_multilevel_imposebc(Knbc,fnbc,nonzeroG,meshesP,nvtxP,nbndP,noarv)
%
% input:
%                Knbc   input cell structure (before bc's imposed)
%                fnbc   input rhs vector (before bc's imposed)
%            nonzeroG   cell array containing nonzero entries of G-matrices
%             meshesP   cell array containing mesh data for all indices
%               nvtxP   vector containing the number of vertices of each mesh
%               nbndP   vector containing the number of boundary vertices of each mesh
%               noarv   number of active random variables
%
% output:
%                  K    output cell structure (with bc's imposed)
%               fgal    output rhs vector (with bc's imposed)
%              x_gal    template solution vector (with bc's imposed)
%        dupl_intern    boundary condition interior dof map
%
% Function(s) called:   stoch_rhs_multipliers
%                       stoch_specific_bc
%
% This function is based on the TIFISS function for single-level sGFEM
% STOCH_IMPOSEBCX (LR; 22 June 2018), which in turn is based on the
% original SIFISS function STOCH_IMPOSEBC (DJS; 27 July 2015).
%
% Note that the current implementations supports only homogeneous Dirichlet
% boundary conditions
%
%   TIFISS function: MR; 10 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri
  
% Number of indices in index set
  P = length(meshesP);

% Preallocate memory  
  x_gal = zeros(size(fnbc));
  dupl_nodes = (1:length(fnbc))';
    
% Create dupl_intern
  dupl_bound = zeros(sum(nbndP),1);
  for i_ind=1:P
      mesh = meshesP{i_ind};
      l = sum(nvtxP(1:(i_ind-1)))*ones(nbndP(i_ind),1);
      dupl_bound(sum(nbndP(1:(i_ind-1)))*ones(nbndP(i_ind),1) + (1:nbndP(i_ind))') = l + mesh.bound;
  end
  dupl_intern = dupl_nodes(~ismember(dupl_nodes,dupl_bound));

% Impose BCs on the RHS vector
  fgal = fnbc(dupl_intern);
  
% Impose BCs on stiffness matrices
  K = cell(P,P,noarv+1);
  
  for dim = 1:noarv+1 % loop over active random variables
 
      nmatrices = size(nonzeroG{dim},1); % number of matrices that need computing
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroG{dim}(b_index,1);
          j_ind = nonzeroG{dim}(b_index,2);
         
          nodesI = (1:nvtxP(i_ind))';
          boundI = meshesP{i_ind}.bound;
          internI = nodesI(~ismember(nodesI,boundI));
         
          nodesJ = (1:nvtxP(j_ind))';
          boundJ = meshesP{j_ind}.bound;
          internJ = nodesJ(~ismember(nodesJ,boundJ));
         
          Kk = Knbc{i_ind,j_ind,dim};
          K{i_ind,j_ind,dim} = Kk(internI,internJ);
         
          if dim>1
              Kk = Knbc{j_ind,i_ind,dim};
              K{j_ind,i_ind,dim} = Kk(internJ,internI);
          end
         
      end
     
  end
  
end % end function