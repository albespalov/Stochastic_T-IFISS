%STOCH_MULTILEVEL_SETUP_AND_SOLVE sets up and solves the SGFEM linear system
%
% Variables computed and returned are:
%               G     stochastic G-matrices
%           x_gal     stochastic Galerkin solution
%         var_sol     variance of the stochastic Galerkin solution
%          energy     energy norm of the stochastic Galerkin solution
%
% Function(s) called: stoch_gmatricesx
%                     stoch_multilevel_compute_nonzeroG
%                     stoch_multilevel_femp1_setup
%                     stoch_multilevel_imposebc
%                     stoch_multilevel_matvec
%                     stoch_multilevel_m_sdiff
%                     stoch_multilevel_variance
%                     stoch_multilevel_x_minres (or pcg)
%
%   TIFISS scriptfile: AB; 3 January 2022
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  fprintf('\n<strong>SOLVE</strong>');
  
  solveTime = tic;
  
% Generate the G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);

% Determine the triplets (i_ind,j_ind,m) for which G_m(i_ind,j_ind) is nonzero.
% Only the corresponding G-matrices should be computed.
  [nonzeroG] = stoch_multilevel_compute_nonzeroG(G);

% Number of stiffness matrices that must be effectively computed
  nAssembledK = size(vertcat(nonzeroG{:}),1);
  
% -------------------------------------------------------------------------  
% Setup matrices for P1 discretisation
% -------------------------------------------------------------------------

  fprintf('\n<strong>Setting up stochastic P1 diffusion matrices...</strong>');

  if pmethod == 1
      
      setupmat = tic;
    % Generate stiffness matrices and right-hand side
      [Knbc,fnbc] = stoch_multilevel_femp1_setup(meshesP,nvtxP,nonzeroG,norv,noarv,KL_DATA);
    % Impose boundary conditions
      [K,fnew,x_gal,dupl_intern] = stoch_multilevel_imposebc(Knbc,fnbc,nonzeroG,meshesP,nvtxP,nbndP,noarv);
      fprintf(' done (%.5f sec)\n',toc(setupmat));

  elseif pmethod == 2
      
      error('P2 not available!');

  end
      
% -------------------------------------------------------------------------  
% Solve the system
% -------------------------------------------------------------------------

% solving the system iteratively without assembling the full system matrix
  afun = @(x) stoch_multilevel_matvec(x,G,nonzeroG,K,nintP);
  mfun = @(x) stoch_multilevel_m_sdiff(x,K,nintP);
% call MINRES solver
  fprintf('<strong>MINRES solution of the linear system:</strong>\n'); 
  [xminres,~,info] = stoch_multilevel_x_minres(afun,mfun,fnew,299,1e-9,0);
  itSolver = info(end)-1; % number of iterations in solver

% In order ro use Matlab's built-in PCG solver, replace the last two lines
% by the following two
  %fprintf('<strong>PCG solution of the linear system:</strong>\n');
  %xminres = pcg(afun,fnew,1e-9,299,mfun);

  x_gal(dupl_intern) = xminres;
  
% -------------------------------------------------------------------------  
% Computes energy norm and variance
% -------------------------------------------------------------------------  
% Energy norm ||x_gal||_B
  [b_ref] = stoch_multilevel_matvec(x_gal,G,nonzeroG,Knbc,nvtxP);
  energy  = sqrt(x_gal' * b_ref);
% Variance Var(x_gal)
  [var_sol] = stoch_multilevel_variance(meshesP,nvtxP,x_gal,P);
 
% -------------------------------------------------------------------------  
% Print data
% -------------------------------------------------------------------------
  fprintf('<strong>Linear solver statistics:</strong>\n');
  fprintf('   Total ndof:         %g\n',length(xminres));
  fprintf('<strong>Stochastic parameters:</strong>\n');
  fprintf('   Active parameters:  %g\n',noarv);
  fprintf('   Polynomial degree: %2i\n',polyd);
  fprintf('<strong>Computed solution:</strong>\n');
  fprintf('   Maximum mean value: %8.4e\n',max(x_gal(1:nvtxP(1))));      
  fprintf('   Maximum variance:   %8.4e\n',max(var_sol));
  fprintf('   Energy norm:        %8.4e\n',energy);

fprintf('Totale SOLVE time = %.5f sec\n',toc(solveTime));
  
% end scriptfile     