function [y] = stoch_multilevel_matvec(x,G,nonzeroG,K,nintP)
%STOCH_MULTILEVEL_MATVEC implements the action of matrix-vector product for multilevel stochastic Galerkin matrices
%   
% [y] = stoch_multilevel_matvec(x,G,nonzeroG,K,nintP)
%
% input
%           x    input vector of dimension
%           G    1-by-(noarv+1) cell of G-matrices
%    nonzeroG    cell array containing nonzero entries of G-matrices
%           K    cell structure with the stiffness matrices 
%       nbndP    vector with the number of interior vertices of each mesh
% output
%          y    output vector of dimension (nKi $\times$ nGi)
%
% This function is based on the TIFISS function STOCH_MATVECX
% for single-level sGFEM (LR; 5 January 2018),
% which in turn is based on the original SIFISS function
% STOCH_MATVEC (DJS; 19 January 2013).
% The current function is an extension to the multilevel sGFEM.
%
%   TIFISS function: MR; 5 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  dimG = size(nonzeroG,2);
  
  y = zeros(size(x));

% Loop over the number of matrices

  for dim = 1:dimG % loop over active random variables
 
      nmatrices = size(nonzeroG{dim},1); % number of K-matrices that have been computed
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroG{dim}(b_index,1);
          j_ind = nonzeroG{dim}(b_index,2);
          nint_i = nintP(i_ind);
          start_i = sum(nintP(1:(i_ind-1)));
          nint_j = nintP(j_ind);
          start_j = sum(nintP(1:(j_ind-1)));
          y(start_i+1:start_i+nint_i) = y(start_i+1:start_i+nint_i) + ...
                G{dim}(i_ind,j_ind) * K{i_ind,j_ind,dim} * x(start_j+1:start_j+nint_j);
            
          % for dim>1 also the symmetric matrix entry is nonzero, also the corrisponding
          % contribution to the sum must be considered
            
          if dim>1
                         
              i_ind = nonzeroG{dim}(b_index,2);
              j_ind = nonzeroG{dim}(b_index,1);
              nint_i = nintP(i_ind);
              start_i = sum(nintP(1:(i_ind-1)));
              nint_j = nintP(j_ind);
              start_j = sum(nintP(1:(j_ind-1)));
              y(start_i+1:start_i+nint_i) = y(start_i+1:start_i+nint_i) + ...
                 G{dim}(i_ind,j_ind) * K{i_ind,j_ind,dim} * x(start_j+1:start_j+nint_j);
             
          end

      end
     
  end
  
end % end function