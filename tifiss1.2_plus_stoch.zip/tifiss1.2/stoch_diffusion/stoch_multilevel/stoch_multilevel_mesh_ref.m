function refinedMesh = stoch_multilevel_mesh_ref(coarseMesh,MMele,MMedge)
%STOCH_MULTILEVEL_MESH_REF performs mesh refinement based on longest-edge bisection (LEB) algorithm
%
% refinedMesh = stoch_multilevel_mesh_ref(coarseMesh,MMele,MMedge)
%
% input:
%         MMelem     set of overall marked elements
%         MMedge     set of overall marked edges to be refined
%     coarseMesh     mesh structure (before refinement)
%
% output:
%    refinedMesh     mesh structure (after refinement)
%
% The function performs a mesh refinement based on the Longest Edge Bisection 
% (LEB) as a variant of the Newest Vertex Bisection (NVB) algorithm. The 
% longest edges of the marked elements are marked first (reference edges). 
% Hanging nodes are then avoided by completion steps.
%
% This function extends the TIFISS function MESH_REF (LR; 22 June 2018) to
% handle meshes used by the multilevel code (which contain more fields,
% e.g., the level or the elements' centers of mass).
%
% See also STOCH_MULTILEVEL_MESH_UNIF_REF
%                     
% Function(s) called: p1grid_detail_space
%                     stoch_multilevel_bisection
%                     stoch_multilevel_center_of_mass 
%                     tedgegen
%                     
%   TIFISS function: MR; 22 August 2020
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri                                 
     
% Overall number of edges
  nedg = size(coarseMesh.xyY,1);
    
% Global numbers of the new nodes (midpoints) to be inserted in the mesh
  newNodes = size(coarseMesh.xy,1) + (1:length(MMedge));
  
% Midpoints' global numbers: 
% The following vector 'markEdge' is sparse nedg-by-1 and it contains 
% either 0 in i-th position (if the i-th edge has not been marked)
% or the global number of the midpoint that would be inserted on that edge
  markEdge = sparse(MMedge,1,newNodes,nedg,1);
  
% -----------------------------------------------------------------
% New vertex coordinate matrix xy
% -----------------------------------------------------------------
% Appending the midpoints' coordinates to current xy
  refinedMesh.xy = [coarseMesh.xy; coarseMesh.xyY(MMedge,:)];
  
% -----------------------------------------------------------------
% New element-mapping matrix 
% -----------------------------------------------------------------
% Refinement of marked elements/edges 
  [refinedMesh.evt,refinedMesh.level,refinedMesh.T0ancestor] = stoch_multilevel_bisection(MMele,MMedge,markEdge,coarseMesh.evt,coarseMesh.evtY,coarseMesh.level,coarseMesh.T0ancestor);
   
% -----------------------------------------------------------------
% New interior/boundary nodes and boundary mapping matrix eboundt
% -----------------------------------------------------------------
   
% New boundary nodes
  refinedMesh.bound = [coarseMesh.bound; nonzeros( markEdge(coarseMesh.boundY) )];
  
% New interior vertices vector
  totalnodes = 1:size(refinedMesh.xy,1);
  refinedMesh.interior = totalnodes( ~ismember(totalnodes,refinedMesh.bound) )';

% Update detail space Y
%  fprintf('   Updating spatial detail space Y');
%  detailTime = tic;
  [refinedMesh.evtY,refinedMesh.xyY,refinedMesh.boundY,refinedMesh.Ybasis] = p1grid_detail_space(refinedMesh.xy,refinedMesh.evt);
%  fprintf('   (%.5f sec)\n',toc(detailTime));

% New element boundary mapping matrix eboundt
  [belem,bedge] = find( ismember(refinedMesh.evtY,refinedMesh.boundY) );
  refinedMesh.eboundt = [belem, bedge];

% Update center of mass vector
  refinedMesh.centerOfMass = stoch_multilevel_center_of_mass(refinedMesh.xy,refinedMesh.evt);
  
% Update edge length/connections
%  fprintf('   Updating edge lengths/connections');
%  edgeGenTime = tic;
  [refinedMesh.eex,refinedMesh.tve,refinedMesh.els] = tedgegen(refinedMesh.xy,refinedMesh.evt);
%  fprintf(' (%.5f sec)\n',toc(edgeGenTime));
  
end  % end function
