function [yp_elerr,yp_ederr,yp_err_est] = stoch_multilevel_diffpost_p1_yp_2level(meshesP,nvtxP,x_gal,G,nonzeroG,norv,noarv,KL_DATA,subdivPar)  
%STOCH_MULTILEVEL_DIFFPOST_P1_YP_2LEVEL computes YP 2-level error estimator for multilevel stochastic Galerkin P1 solution
%
% [yp_elerr,yp_ederr,yp_err_est] = stoch_multilevel_diffpost_p1_yp_2level(meshesP,...
%                        nvtxP,x_gal,G,nonzeroG,norv,noarv,KL_DATA,subdivPar)
%
% input:
%          meshesP    cell array containing mesh data for all indices
%            nvtxP    vector containing the number of vertices of each mesh
%            x_gal    stochastic P1 galerkin solution
%                G    1-by-(noarv+1) cell of G-matrices
%         nonzeroG    cell array containing nonzero entries of G-matrices
%             norv    number of random variables
%            noarv    number of active random variables
%          KL_DATA    data related to KL-expansion
%        subdivPar    red or bisec3 uniform sub-division flag
%
%   output: 
%         yp_elerr    cell of YP 2-level element-indicators
%         yp_ederr    cell of YP 2-level edge-indicators
%       yp_err_est    global spatial 2-level error estimate
%
% The error estimation strategy has been proposed for single-level sGFEM
% in [BPRR2019] and extended to multilevel sGFEM in [BPR21].
% The element indicators are recovered by square summing the 3 
% edge indicators per element.
% The current implementation supports only homogeneous Dirichlet boundary
% conditions.
%
% References:
% [BPRR19] Bespalov, Praetorius, Rocchi, Ruggeri, Goal-oriented error estimation 
% and adaptivity for elliptic PDEs with parametric or uncertaint inputs,
% Comput. Methods Appl. Mech. Engrg., 345, 951-982, 2019.
% [BPR21] Bespalov, Praetorius, Ruggeri, Two-Level a Posteriori Error Estimation
% for Adaptive Multilevel Stochastic Galerkin Finite Element Method,
% SIAM/ASA J. Uncertain. Quantif., 9(3), 1184-1216, 2021.
%
% Function(s) called:  stoch_multilevel_mesh_intersection
%                      stoch_multilevel_mesh_unif_ref
%                      tderiv
%                      triangular_gausspoints
%
%   TIFISS function: MR; 4 June 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Length of the index set
  P = size(meshesP,2);

% initialize output
  yp_elerr = cell(1,P);
  yp_ederr = cell(1,P);

% Refine all meshes associated with indices in index set
  unifRefMeshesP = cell(size(meshesP));
  for ind_p=1:P
      unifRefMeshesP{ind_p} = stoch_multilevel_mesh_unif_ref(meshesP{ind_p});
  end
  
% Allocate cell array to hold the (in general rectangular) matrices
  Ktilde = cell(P,P,noarv+1);
% For each pair of indices in the index set there are noarv+1 matrices
% i.e., for all i,j=1,...,P and for all m=1,...,m+1
% Ktilde(i,j,m) denote the matrix K_{m-1} associated with the uniform refinement
% of the mesh of the i-th index and the mesh of the j-th index of the index set

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
% Gauss points and weights on the reference element
  [s,t,wt] = triangular_gausspoints(nngpt);

% Construction of the Ktilde matrices

  for m = 0:noarv % loop over active random variables
 
      nmatrices = size(nonzeroG{m+1},1); % number of matrices that need computing
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroG{m+1}(b_index,1);
          j_ind = nonzeroG{m+1}(b_index,2);
     
        % Get mesh data
          meshI = unifRefMeshesP{i_ind};
          nvtxI = size(meshI.xy,1);  % Number of vertices of mesh1
          nelI  = size(meshI.evt,1); % Number of elements of mesh1
      
        % Recover local coordinates (mesh I)
          xl_vI = zeros(nelI,3);
          yl_vI = zeros(nelI,3);
          for ivtx = 1:3
              xl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 1);
              yl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 2); 
          end
          
        % Initialization vector containing integrals of coefficients
          intCoeffI = zeros(nelI,1);
         
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacI,invjacI,~,dphidxI,dphidyI] = tderiv(sigpt,tigpt,xl_vI,yl_vI);
              dphidxI = dphidxI.*invjacI;
              dphidyI = dphidyI.*invjacI;
              [coeffI] = stoch_gauss_coeff(sigpt,tigpt,xl_vI,yl_vI,norv,KL_DATA);
            % Build vector with elementwise integrals of the coefficients
              intCoeffI(:) = intCoeffI(:) + wght * coeffI(:,m+1) .* jacI(:); 
  
          end % end of loop over Gauss points
      
        % Get mesh data
          meshJ = meshesP{j_ind};
          nvtxJ = size(meshJ.xy,1);  % Number of vertices of mesh2
          nelJ  = size(meshJ.evt,1); % Number of elements of mesh2
   
        % Recover local coordinates (mesh J)
          xl_vJ = zeros(nelJ,3);
          yl_vJ = zeros(nelJ,3);
          for ivtx = 1:3
              xl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 1);
              yl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 2); 
          end

        % Initialization vector containing integrals of coefficients
          intCoeffJ = zeros(nelJ,1);
          
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacJ,invjacJ,~,dphidxJ,dphidyJ] = tderiv(sigpt,tigpt,xl_vJ,yl_vJ);
              dphidxJ = dphidxJ.*invjacJ;
              dphidyJ = dphidyJ.*invjacJ;
              [coeffJ] = stoch_gauss_coeff(sigpt,tigpt,xl_vJ,yl_vJ,norv,KL_DATA);
            % Build vector with elementwise integrals of the coefficients
              intCoeffJ(:) = intCoeffJ(:) + wght * coeffJ(:,m+1) .* jacJ(:);  
 
          end % end of loop over Gauss points
         
        % Build the vectors containing the information about mesh intersection
          [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(meshI,meshJ);
       
        % Allocate memory for local stiffness matrices
          adeI = zeros(nelI,3,3);
          adeJ = zeros(nelJ,3,3);

        % Building local stiffness matrices

          for k_elemI = 1:nelI
              if T1toT2(k_elemI)~=0        
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeI(k_elemI,i,j) = intCoeffI(k_elemI)*(dphidxI(k_elemI,i)*dphidxJ(T1toT2(k_elemI),j) ...
                                                         + dphidyI(k_elemI,i) * dphidyJ(T1toT2(k_elemI),j));
                      end
                  end
              end
          end

          for k_elemJ = 1:nelJ
              if T2toT1strict(k_elemJ)~=0             
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeJ(k_elemJ,i,j) = intCoeffJ(k_elemJ)*(dphidxI(T2toT1strict(k_elemJ),i)*dphidxJ(k_elemJ,j) ...
                                                         + dphidyI(T2toT1strict(k_elemJ),i) * dphidyJ(k_elemJ,j));
                      end
                  end
              end
          end
  
        % Assembly of global matrices
        
          ad = sparse(nvtxI,nvtxJ);
          aux = find(T1toT2>0);
        % Here aux contains the indices of elements of meshI which are
        % contained into an element of meshJ.
          for krow = 1:3
              nrow = meshI.evt(aux,krow);
              for kcol = 1:3
                  ncol = meshJ.evt(T1toT2(aux),kcol);
                  ad = ad + sparse(nrow,ncol,adeI(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end

          aux = find(T2toT1strict>0);
        % Here aux contains the indices of elements of meshJ which are
        % strictly contained into an element of meshI.
          for krow = 1:3
              nrow = meshI.evt(T2toT1strict(aux),krow);
              for kcol = 1:3
                  ncol = meshJ.evt(aux,kcol);
                  ad = ad + sparse(nrow,ncol,adeJ(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end
          
          Ktilde{i_ind,j_ind,m+1} = ad;

      end % end loop over the relevant indices
      
  end

% Construction of the remaining Ktilde matrices
 
  for m = 1:noarv % Loop over active random variables (we start from m=1 here)
 
      nmatrices = size(nonzeroG{m+1},1); % Number of matrices that need computing
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroG{m+1}(b_index,2); % Index 1 and 2 swapped!
          j_ind = nonzeroG{m+1}(b_index,1);
     
        % Get mesh data
          meshI = unifRefMeshesP{i_ind};
          nvtxI = size(meshI.xy,1);  % Number of vertices of mesh1
          nelI  = size(meshI.evt,1); % Number of elements of mesh1
      
        % Recover local coordinates (mesh I)
          xl_vI = zeros(nelI,3);
          yl_vI = zeros(nelI,3);
          for ivtx = 1:3
              xl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 1);
              yl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 2); 
          end

        % Initialization vector containing integrals of coefficients
          intCoeffI = zeros(nelI,1);
         
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacI,invjacI,~,dphidxI,dphidyI] = tderiv(sigpt,tigpt,xl_vI,yl_vI);
              dphidxI = dphidxI.*invjacI;
              dphidyI = dphidyI.*invjacI;
              [coeffI] = stoch_gauss_coeff(sigpt,tigpt,xl_vI,yl_vI,norv,KL_DATA);
              intCoeffI(:) = intCoeffI(:) + wght * coeffI(:,m+1) .* jacI(:); 
  
          end % end of loop over Gauss points
      
        % Get mesh data
          meshJ = meshesP{j_ind};
          nvtxJ = size(meshJ.xy,1);  % Number of vertices of mesh2
          nelJ  = size(meshJ.evt,1); % Number of elements of mesh2
   
        % Recover local coordinates (mesh J)
          xl_vJ = zeros(nelJ,3);
          yl_vJ = zeros(nelJ,3);
          for ivtx = 1:3
              xl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 1);
              yl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 2); 
          end

        % Initialization vector containing integrals of coefficients
          intCoeffJ = zeros(nelJ,1);
          
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacJ,invjacJ,~,dphidxJ,dphidyJ] = tderiv(sigpt,tigpt,xl_vJ,yl_vJ);
              dphidxJ = dphidxJ.*invjacJ;
              dphidyJ = dphidyJ.*invjacJ;
              [coeffJ] = stoch_gauss_coeff(sigpt,tigpt,xl_vJ,yl_vJ,norv,KL_DATA);
              intCoeffJ(:) = intCoeffJ(:) + wght * coeffJ(:,m+1) .* jacJ(:);  
 
          end % end of loop over Gauss points

        % Build the vectors containing the information about mesh intersection
          [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(meshI,meshJ);
          
        % Allocate memory for local stiffness matrices
          adeI = zeros(nelI,3,3);
          adeJ = zeros(nelJ,3,3);

        % Building local stiffness matrices

          for k_elemI = 1:nelI
      
              if T1toT2(k_elemI)~=0
             
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeI(k_elemI,i,j) = intCoeffI(k_elemI)*(dphidxI(k_elemI,i)*dphidxJ(T1toT2(k_elemI),j) ...
                                                     + dphidyI(k_elemI,i) * dphidyJ(T1toT2(k_elemI),j));
                      end
                  end
              end
          end

          for k_elemJ = 1:nelJ
              if T2toT1strict(k_elemJ)~=0
               % Loop over basis functions
                 for i = 1:3
                     for j = 1:3
                         adeJ(k_elemJ,i,j) = intCoeffJ(k_elemJ)*(dphidxI(T2toT1strict(k_elemJ),i)*dphidxJ(k_elemJ,j) ...
                                                     + dphidyI(T2toT1strict(k_elemJ),i) * dphidyJ(k_elemJ,j));
                     end
                 end
              end
          end
  
        % Assembly of global matrices
        
          ad = sparse(nvtxI,nvtxJ);

          aux = find(T1toT2>0);
        % Here aux contains the indices of elements of meshI which are
        % contained into an element of meshJ.
          for krow = 1:3
              nrow = meshI.evt(aux,krow);
              for kcol = 1:3
                  ncol = meshJ.evt(T1toT2(aux),kcol);
                  ad = ad + sparse(nrow,ncol,adeI(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end

          aux = find(T2toT1strict>0);
        % Here aux contains the indices of elements of meshJ which are
        % strictly contained into an element of meshI.
          for krow = 1:3
              nrow = meshI.evt(T2toT1strict(aux),krow);
              for kcol = 1:3
                  ncol = meshJ.evt(aux,kcol);
                  ad = ad + sparse(nrow,ncol,adeJ(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end
          
          Ktilde{i_ind,j_ind,m+1} = ad;

      end % end loop over the relevant indices
      
  end

% We restrict the matrices (for the refined mesh, only the nodes associated with the midpoints are needed)

  for m = 0:noarv % Loop over active random variables

      nmatrices = size(nonzeroG{m+1},1); % Number of matrices that need computing
      
      for b_index=1:nmatrices      
          i_ind = nonzeroG{m+1}(b_index,1);
          j_ind = nonzeroG{m+1}(b_index,2);
          Ktilde{i_ind,j_ind,m+1} = Ktilde{i_ind,j_ind,m+1}((nvtxP(i_ind)+1):end,:);
          if m>0
              Ktilde{j_ind,i_ind,m+1} = Ktilde{j_ind,i_ind,m+1}((nvtxP(j_ind)+1):end,:);
          end
      end
     
  end
      
  for p_ind=1:P
      
      mesh = unifRefMeshesP{p_ind};
      nvtx = size(mesh.xy,1);
      nel  = size(mesh.evt,1); % Number of elements
      mlad = sparse(nvtx,nvtx);
      mlF = zeros(size(mesh.xy,1),1);

    % Recover local coordinates

      xl_v = zeros(nel,3);
      yl_v = zeros(nel,3);
      for ivtx = 1:3
          xl_v(:,ivtx) = mesh.xy( mesh.evt(:,ivtx), 1);
          yl_v(:,ivtx) = mesh.xy( mesh.evt(:,ivtx), 2); 
      end

    % Allocate memory
      mlade = zeros(nel,3,3);
      mlfde = zeros(nel,3);

    % Loop over Gauss points
      for igpt = 1:nngpt

          sigpt = s(igpt);
          tigpt = t(igpt);
          wght  = wt(igpt);
        % Evaluate derivatives, RHS, and coefficient
          [jac,invjac,phi,dphidx,dphidy] = tderiv(sigpt,tigpt,xl_v,yl_v);
          [mlrhs]   = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,norv);
          [coeff] = stoch_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
          
        % Loop over basis functions
          for j = 1:3
              for i = 1:3
                  mlade(:,i,j) = mlade(:,i,j) + wght * coeff(:,1) .* dphidx(:,i) .* dphidx(:,j) .* invjac(:);
                  mlade(:,i,j) = mlade(:,i,j) + wght * coeff(:,1) .* dphidy(:,i) .* dphidy(:,j) .* invjac(:);
              end
            % Contributions from the RHS
              mlfde(:,j) = mlfde(:,j) + wght * mlrhs(:,1) .* phi(:,j) .* jac(:);
          end
      end
            
    % Assembly of global rhs vector
      for krow = 1:3
          nrow = mesh.evt(:,krow);
          for kcol = 1:3
              ncol = mesh.evt(:,kcol);
              mlad = mlad + sparse(nrow,ncol,mlade(:,krow,kcol),nvtx,nvtx);
          end
          for els = 1:nel
              mlF(nrow(els),1) = mlF(nrow(els),1) + mlfde(els,krow);
          end 
      end
      
      mlRhs = mlF((nvtxP(p_ind)+1):end);
    % If the RHS is deterministic we have a Kronecker delta
    % (only the 0 index gives a nonzero contribution)
      if p_ind ~= 1
          mlRhs = zeros(size(mlRhs));
      end
      mlB0phi = full(diag(mlad));
      mlB0phi = mlB0phi((nvtxP(p_ind)+1):end);
      mlB0phi = sqrt(mlB0phi);

    % Assemble the vector Bx = b(u_gal,v_XQ)
      
      mlBx = zeros(size(meshesP{p_ind}.xyY,1),1);      

    % m = 0
      start_p = sum(nvtxP(1:(p_ind-1)));
      nvtx_p = nvtxP(p_ind); 
      mlBx = mlBx + Ktilde{p_ind,p_ind,1}*x_gal(start_p+1:start_p+nvtx_p);
      
    % m = 1,...,M
      for m = 1:noarv % loop over active random variables

          nmatrices = size(nonzeroG{m+1},1); % Number of matrices that have been computed
          
          for b_index=1:nmatrices

              i_ind = nonzeroG{m+1}(b_index,1);
              if i_ind == p_ind
                  j_ind = nonzeroG{m+1}(b_index,2);
                  nvtx_j = nvtxP(j_ind);
                  start_j = sum(nvtxP(1:(j_ind-1)));
                  mlBx = mlBx + G{m+1}(i_ind,j_ind) * Ktilde{i_ind,j_ind,m+1} * x_gal(start_j+1:start_j+nvtx_j);
              end

              i_ind = nonzeroG{m+1}(b_index,2); % Indices 1 and 2 interchanged
              if i_ind == p_ind
                  j_ind = nonzeroG{m+1}(b_index,1);
                  nvtx_j = nvtxP(j_ind);
                  start_j = sum(nvtxP(1:(j_ind-1)));
                  mlBx = mlBx + G{m+1}(i_ind,j_ind) * Ktilde{i_ind,j_ind,m+1} * x_gal(start_j+1:start_j+nvtx_j);
              end
              
          end
  
      end
      
    % Compute the two-level edge error indicators
      yp_ederr{p_ind} = (abs(mlRhs - mlBx))./mlB0phi;
      
    % Error estimates for boundary midpoints = 0
    % (this restricts the use of this function to homogeneous BCs)
      yp_ederr{p_ind}(meshesP{p_ind}.boundY) = 0;

    % From the edge error indicators, we construct the element error indicators
      nel = size(meshesP{p_ind}.evt,1);
      yp_elerr{p_ind} = zeros(nel,1);
      for ell=1:nel
          yp_elerr{p_ind}(ell) = sqrt(sum(yp_ederr{p_ind}(meshesP{p_ind}.evtY(ell,:)).^2));
      end
  
  end
  
% Total error estimate
  yp_err_est = 0;
  for p_ind=1:P
      yp_err_est = yp_err_est + sum(yp_ederr{p_ind}.^2);
  end
  yp_err_est = sqrt(yp_err_est);
  
end % end function