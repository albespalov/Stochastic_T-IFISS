function coms = stoch_multilevel_center_of_mass(xy,evt)
%STOCH_MULTILEVEL_CENTER_OF_MASS computes the centers of mass of the elements of a mesh
%
% coms = stoch_multilevel_center_of_mass(xy,evt)
%
% input:
%              xy      coordinates matrix
%             evt      element matrix
% output: 
%            coms      nel-by-2 matrix containing the coordinates
%                      of the centers of mass of the elements
%
%   TIFISS function: MR; 14 June 2019
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  nel  = size(evt,1);  % number of elements
  coms = zeros(nel,2); % initialization

  for n = 1:3
      coms = coms + xy(evt(:,n),:)/3;
  end

end % end function