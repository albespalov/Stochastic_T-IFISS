function [K,F] = stoch_multilevel_femp1_setup(meshesP,nvtxP,nonzeroG,norv,noarv,KL_DATA)
%STOCH_MULTILEVEL_FEMP1_SETUP assembles P1 stiffness matrices and the rhs vector needed by the SGFEM
%
% [K,F] = stoch_multilevel_femp1_setup(meshesP,nvtxP,nonzeroG,norv,noarv,KL_DATA)
%   
% input:
%          meshesP    cell array containing mesh data for all indices
%            nvtxP    vector containing the number of vertices of each mesh
%         nonzeroG    cell array containing nonzero entries of G-matrices
%             norv    number of random variables
%            noarv    number of active random variables
%          KL_DATA    data related to KL-expansion
%
% output:
%                K    cell structure with P^2*(noarv+1) matrices, where P
%                     denotes the number of indices in indset (which
%                     coincides with the number of meshes in meshesP)
%                F    rhs vector
%
% Note that the function currently works for deterministic right-hand sides
% in the parametric PDE.
% 
% Function(s) called:  triangular_gausspoints
%                      tderiv
%                      stoch_gauss_source
%                      stoch_gauss_coeff
%                      stoch_multilevel_mesh_intersection
%
%   TIFISS function: MR; 22 September 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Number of indices in index set
  P = length(meshesP);

% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
% Gauss points and weights on the reference element
  [s,t,wt] = triangular_gausspoints(nngpt);

% Allocate cell array to hold the (in general rectangular) matrices
  K = cell(P,P,noarv+1);

  for m = 0:noarv % loop over active random variables
 
      nmatrices = size(nonzeroG{m+1},1); % number of matrices that need computing
     
      for b_index=1:nmatrices
         
          i_ind = nonzeroG{m+1}(b_index,1);
          j_ind = nonzeroG{m+1}(b_index,2);
     
        % Get mesh data
          meshI = meshesP{i_ind};
          nvtxI = size(meshI.xy,1);  % Number of vertices of mesh1
          nelI  = size(meshI.evt,1); % Number of elements of mesh1
      
        % Recover local coordinates (mesh I)
          xl_vI = zeros(nelI,3);
          yl_vI = zeros(nelI,3);
          for ivtx = 1:3
              xl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 1);
              yl_vI(:,ivtx) = meshI.xy( meshI.evt(:,ivtx), 2); 
          end     
        % Initialization vector containing integrals of coefficients
          intCoeffI = zeros(nelI,1);
         
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacI,invjacI,~,dphidxI,dphidyI] = tderiv(sigpt,tigpt,xl_vI,yl_vI);
              dphidxI = dphidxI.*invjacI;
              dphidyI = dphidyI.*invjacI;
              [coeffI] = stoch_gauss_coeff(sigpt,tigpt,xl_vI,yl_vI,norv,KL_DATA);
            % Build vector containing integrals of coefficients
              intCoeffI(:) = intCoeffI(:) + wght * coeffI(:,m+1) .* jacI(:); 
  
          end % end of loop over Gauss points
      
        % Get mesh data
          meshJ = meshesP{j_ind};
          nvtxJ = size(meshJ.xy,1);  % Number of vertices of mesh2
          nelJ  = size(meshJ.evt,1); % Number of elements of mesh2
   
        % Recover local coordinates (mesh J)
          xl_vJ = zeros(nelJ,3);
          yl_vJ = zeros(nelJ,3);
          for ivtx = 1:3
              xl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 1);
              yl_vJ(:,ivtx) = meshJ.xy( meshJ.evt(:,ivtx), 2); 
          end
        % Initialization vector containing integrals of coefficients
          intCoeffJ = zeros(nelJ,1);
      
        % Loop over Gauss points
          for igpt = 1:nngpt
              
              sigpt = s(igpt);
              tigpt = t(igpt);
              wght  = wt(igpt);

            % Evaluate derivatives and diffusion coefficient
              [jacJ,invjacJ,~,dphidxJ,dphidyJ] = tderiv(sigpt,tigpt,xl_vJ,yl_vJ);
              dphidxJ = dphidxJ.*invjacJ;
              dphidyJ = dphidyJ.*invjacJ;
              [coeffJ] = stoch_gauss_coeff(sigpt,tigpt,xl_vJ,yl_vJ,norv,KL_DATA);          
            % Build vector with elementwise integrals of the coefficients
              intCoeffJ(:) = intCoeffJ(:) + wght * coeffJ(:,m+1) .* jacJ(:);  
 
          end % end of loop over Gauss points

        % Build the vectors containing the information about mesh intersection
          [T1toT2, T2toT1strict] = stoch_multilevel_mesh_intersection(meshI,meshJ);
          
        % Allocate memory for local stiffness matrices
          adeI = zeros(nelI,3,3);
          adeJ = zeros(nelJ,3,3);

        % Building local stiffness matrices

          for k_elemI = 1:nelI
              if T1toT2(k_elemI)~=0
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeI(k_elemI,i,j) = intCoeffI(k_elemI)*(dphidxI(k_elemI,i)*dphidxJ(T1toT2(k_elemI),j) ...
                                               + dphidyI(k_elemI,i) * dphidyJ(T1toT2(k_elemI),j));
                      end
                  end
              end
          end

          for k_elemJ = 1:nelJ
              if T2toT1strict(k_elemJ)~=0
                % Loop over basis functions
                  for i = 1:3
                      for j = 1:3
                          adeJ(k_elemJ,i,j) = intCoeffJ(k_elemJ)*(dphidxI(T2toT1strict(k_elemJ),i)*dphidxJ(k_elemJ,j) ...
                                               + dphidyI(T2toT1strict(k_elemJ),i) * dphidyJ(k_elemJ,j));
                      end
                  end
              end
          end
  
        % Assembly of global matrices
        
          ad = sparse(nvtxI,nvtxJ);

          aux = find(T1toT2>0);
        % Here aux contains the indices of elements of meshI which are
        % contained into an element of meshJ.
          for krow = 1:3
              nrow = meshI.evt(aux,krow);
              for kcol = 1:3
                  ncol = meshJ.evt(T1toT2(aux),kcol);
                  ad = ad + sparse(nrow,ncol,adeI(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end

          aux = find(T2toT1strict>0);
        % Here aux contains the indices of elements of meshJ which are
        % strictly contained into an element of meshI.
          for krow = 1:3
              nrow = meshI.evt(T2toT1strict(aux),krow);
              for kcol = 1:3
                  ncol = meshJ.evt(aux,kcol);
                  ad = ad + sparse(nrow,ncol,adeJ(aux,krow,kcol),nvtxI,nvtxJ);
              end
          end
          
          K{i_ind,j_ind,m+1} = ad;
      
        % The matrix G_m are symmetric
          if m>0
              K{j_ind,i_ind,m+1} = ad';              
          end
              
          
      end % end loop over the relevant indices
      
  end

% Allocate right-hand side vector
  F = zeros(sum(nvtxP),1);

% The right-hand only sees the mesh associated with the zero index
% By convention, the zero index is the first index of the index set
  meshZero = meshesP{1};
  nel  = size(meshZero.evt,1); % Number of elements

% Recover local coordinates
  xl_v = zeros(nel,3);
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = meshZero.xy( meshZero.evt(:,ivtx), 1);
      yl_v(:,ivtx) = meshZero.xy( meshZero.evt(:,ivtx), 2); 
  end

% Allocate memory
  fde = zeros(nel,3);

% Loop over Gauss points
  for igpt = 1:nngpt

      sigpt = s(igpt);
      tigpt = t(igpt);
      wght  = wt(igpt);

      % Evaluate derivatives, RHS, and coefficient
      [jac,~,phi,~,~] = tderiv(sigpt,tigpt,xl_v,yl_v);
      [rhs] = stoch_gauss_source(sigpt,tigpt,xl_v,yl_v,norv);

    % Loop over basis functions
      for j = 1:3
          fde(:,j) = fde(:,j) + wght * rhs(:,1) .* phi(:,j) .* jac(:);
      end
      
  end

% Assembly of global rhs vector
  for krow = 1:3
      nrow = meshZero.evt(:,krow);
      for els = 1:nel
          F(nrow(els),1) = F(nrow(els),1) + fde(els,krow);
      end 
  end

end  % end function