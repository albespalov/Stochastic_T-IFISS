function refinedMesh = stoch_multilevel_mesh_unif_ref(coarseMesh)
%STOCH_MULTILEVEL_MESH_UNIF_REF performs uniform mesh refinement by bisec3
%
% refinedMesh = stoch_multilevel_mesh_unif_ref(coarseMesh)
%
% input:
%     coarseMesh     mesh structure (before uniform refinement)
%
% output:
%    refinedMesh     mesh structure (after uniform refinement)
%
% Function(s) called: get_all_marked_elem
%                     stoch_multilevel_mesh_ref
%
% See also STOCH_MULTILEVEL_MESH_REF
%                     
%   TIFISS function: MR; 22 August 2020
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri                                 

% Mark all elements of the mesh
  MMedge = [1:size(coarseMesh.xyY,1)]';
  [MMele,MMedge] = get_all_marked_elem(coarseMesh.Ybasis,coarseMesh.evtY,MMedge,2);
% Perform mesh refinement
  refinedMesh = stoch_multilevel_mesh_ref(coarseMesh,MMele,MMedge);
  
end  % end function
