%STOCH_MULTILEVEL_DISPLAY_FINAL_DATA prints the data at the end of adaptive loop
%
% See also STOCH_MULTILEVEL_DISPLAY_INFO_DEBUG
%
%   TIFISS scriptfile: MR; 24 September 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% -----------------------------------------------------------------------------
% Display final data 
% -----------------------------------------------------------------------------
  fprintf('\n<strong>Total elapsed time:</strong>                %.3f sec\n',endLoopTime);
  fprintf('<strong>Total iterations needed:</strong>             %d\n',iter);
  fprintf('<strong>Final estimated energy error:</strong>        %10.4e\n',tot_err_est);
  fprintf('<strong>Final number of degrees of freedom:</strong>  %d\n',length(xminres));
  fprintf('-----------------------------------------');
  
% -----------------------------------------------------------------------------  
% Display the evolution of the index set
% -----------------------------------------------------------------------------
  [~,col] = find(indset);
  
% Find non zero cell entries in the evolved indexset
  idx = find(~cellfun('isempty',index_iter));
  
% Get iteration's numbers when polynomial enrichments occurred  
  iterenrich = index_saveiter(index_saveiter ~= 0);

% Display the unsorted evolved index set  
  fprintf('\n<strong>Evolution of the index set:</strong>\n');
  for i = 1:size(index_init,1)
      fprintf('  %i  ',index_init(i,1:max(col))); fprintf(' ...\n');%fprintf('  0    0  ...\n');  
  end
  lenrep = (max(col)) + ((max(col))-1)*4;   %(max(col)+2) + ((max(col)+2)-1)*4;
  for k = 1:length(idx)     
      fprintf('  '); 
      fprintf(num2str(repmat('-',1,lenrep)));
      fprintf('  iter = %d\n',iterenrich(k)); 
      newindices = index_iter{idx(k)};
      for i = 1:size(newindices,1)
          fprintf('  %i  ',newindices(i,1:max(col))); fprintf(' ...\n');%fprintf('  0    0  ...\n'); 
      end 
  end
  
% -----------------------------------------------------------------------------
% Display the final index set sorted
% -----------------------------------------------------------------------------
  isortind = 1; 
  if isortind
      % Display the sorted final index set
      fprintf('<strong>Sorted final index set:</strong>\n');
      for i = 1:P
          fprintf('  %i  ',indset(i,1:max(col))); fprintf(' ...\n');%fprintf('  0    0  ...\n'); 
      end
  end
  fprintf('-----------------------------------------');
  fprintf('\n<strong>Parametric enrichments: %d</strong>',index_counter - 1);
  fprintf('\n<strong>Index set length:       %d</strong>',P);
  fprintf('\n<strong>Active parameters:      %d</strong>\n',noarv);

% end scriptfile