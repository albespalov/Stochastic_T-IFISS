%STOCH_MULTILEVEL_MARKING performs spatial and parametric marking for the adaptive algorithm
% 
% The function implements the marking step for two marking approaches (combined and
% separate marking) and for both the spatial marking (elements/edges) and
% the parametric marking (multi-indices).
% In particular, the spatial marking allows to mark either the
% elements or the edges according to the variable 'markedgelem' below; 
% see also STOCH_MULTILEVEL_INIT_PARAM.
%
% Also, the function computes the YP and XQ estimates associated with the set of 
% marked elements/edges and indices 
%
% Function(s) called: marking_strategy_fa 
%                     get_all_marked_elem
%                     
%   TIFISS scriptfile: MR; 9 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

  fprintf('\n<strong>MARK</strong>');
  
  if markedgelem == 1 % marking elements
      nEstP = neleP;
      yp_err = yp_elerr;
  else % marking edges
      nEstP = nedgP;
      yp_err = yp_ederr;
  end
  
  MsetP = cell(1,P);
  MMele = MsetP;
  MMedge = MsetP;
  
  cumsumnEstP = cumsum(nEstP);
    
  if marking_type ==1 % combined
            
      fprintf('\n<strong>Combined marking</strong>');
      markTotTime = tic;
      est_vec = vertcat(yp_err{:},xq_err_vec); % vector with all indicators
%       % alternative: vector of all indicators, with spatial indicators weighted by a factor of 20
%      est_vec = vertcat(20*vertcat(yp_err{:}),xq_err_vec);
      subvec_glob2loc = [0, cumsumnEstP];
      subvec_start = subvec_glob2loc+1;
      subvec_end = [cumsumnEstP,size(est_vec,1)];
      marked = marking_strategy_fa(est_vec,strategy,threshold);
      for p_ind = 1:P
        % Set of marked spatial indicators
          MsetP{p_ind} = marked((marked>=subvec_start(p_ind))&(marked<=subvec_end(p_ind)))-subvec_glob2loc(p_ind);
          if size(MsetP{p_ind},1)==0
              MsetP{p_ind} = [];
          end
        % Overall set of marked elements and edges
          [MMele{p_ind},MMedge{p_ind}] = get_all_marked_elem(meshesP{p_ind}.Ybasis,meshesP{p_ind}.evtY,MsetP{p_ind},markedgelem);
      end
      M_ind = marked(marked>cumsumnEstP(P))-subvec_glob2loc(P+1);
      if size(M_ind,1)==0
          M_ind = [];
      end
      markTotTime = toc(markTotTime);
  
  else % separate

      fprintf('\n<strong>Separate marking</strong>');
      markTotTime = tic;
      markMeshTime = tic;
      est_vec = vertcat(yp_err{:}); % vector with all spatial indicators
      subvec_glob2loc = [0, cumsumnEstP(1:end-1)];
      subvec_start = subvec_glob2loc+1;
      subvec_end = cumsumnEstP;
      marked = marking_strategy_fa(est_vec,strategy,threshold_ele);
      for p_ind = 1:P
        % Set of marked spatial indicators
          MsetP{p_ind} = marked((marked>=subvec_start(p_ind))&(marked<=subvec_end(p_ind)))-subvec_glob2loc(p_ind);
          if size(MsetP{p_ind},1)==0
              MsetP{p_ind} = [];
          end
        % Overall set of marked elements and edges
         [MMele{p_ind},MMedge{p_ind}] = get_all_marked_elem(meshesP{p_ind}.Ybasis,meshesP{p_ind}.evtY,MsetP{p_ind},markedgelem);
      end
      markMeshTime = toc(markMeshTime);
      markIndTime = tic;
      M_ind = marking_strategy_fa(xq_err_vec,strategy,threshold_ind);
      markIndTime = toc(markIndTime);
      markTotTime = toc(markTotTime);
  end

% Estimate due to overall marked spatial error indicators (elements or edges)
  yp_err_marked = zeros(1,P);
  if markedgelem == 1 % marking elements
      for p_ind=1:P
          yp_err_marked(p_ind) = norm( yp_elerr{p_ind}(MMele{p_ind}), 2);
      end
  else % markedgelem == 2, i.e., marking edges
      for p_ind=1:P
          yp_err_marked(p_ind) = norm( yp_ederr{p_ind}(MMedge{p_ind}), 2);
      end
  end

  yp_err_est_marked = norm( yp_err_marked, 2);
  
% Estimate due to overall marked indices
  xq_err_est_marked = norm( xq_err_vec(M_ind), 2);
    
% Printing  marking output

  if marking_type ==1 % i.e, combined marking
      fprintf('\nSpatial marking');
     if markedgelem == 1 % marking elements
          for p_ind=1:P
              fprintf('\n    Mesh %d: %d/%d marked elements,', p_ind,size(MsetP{p_ind},1),neleP(p_ind));
              fprintf(' %d/%d overall marked elements', size(MMele{p_ind},1),neleP(p_ind));
          end
          fprintf('\n    <strong>Total: %d/%d marked elements,</strong>',size(vertcat(MsetP{:}),1),sum(neleP));
          fprintf('<strong> %d/%d overall marked elements</strong>',size(vertcat(MMele{:}),1),sum(neleP));
      else % marking edges
          for p_ind=1:P
              fprintf('\n    Mesh %d: %d/%d marked edges,', p_ind,size(MsetP{p_ind},1),nedgP(p_ind));
              fprintf(' %d/%d overall marked edges', size(MMedge{p_ind},1),nedgP(p_ind));
          end
          fprintf('\n    <strong>Total: %d/%d marked edges,</strong>',size(vertcat(MsetP{:}),1),sum(nedgP));
          fprintf('<strong> %d/%d overall marked edges</strong>',size(vertcat(MMedge{:}),1),sum(nedgP));
      end
      fprintf('\nParametric marking');
      fprintf('\n    <strong>%d/%d overall marked indices</strong>',size(M_ind,1),Q);
  
  else % marking_type ==2, i.e, separate marking
      
      fprintf('\nSpatial marking');
      fprintf(' (%.5f sec)',markMeshTime);
      if markedgelem == 1 % marking elements
          for p_ind=1:P
              fprintf('\n    Mesh %d: %d/%d marked elements,', p_ind,size(MsetP{p_ind},1),neleP(p_ind));
              fprintf(' %d/%d overall marked elements', size(MMele{p_ind},1),neleP(p_ind));
          end
          fprintf('\n    <strong>Total: %d/%d marked elements,</strong>',size(vertcat(MsetP{:}),1),sum(neleP));
          fprintf('<strong> %d/%d overall marked elements</strong>',size(vertcat(MMele{:}),1),sum(neleP));
      else % marking edges
          for p_ind=1:P
              fprintf('\n    Mesh %d: %d/%d marked edges,', p_ind,size(MsetP{p_ind},1),nedgP(p_ind));
              fprintf(' %d/%d overall marked edges', size(MMedge{p_ind},1),nedgP(p_ind));
          end
          fprintf('\n    <strong>Total: %d/%d marked edges,</strong>',size(vertcat(MsetP{:}),1),sum(nedgP));
          fprintf('<strong> %d/%d overall marked edges</strong>',size(vertcat(MMedge{:}),1),sum(nedgP));
      end
      fprintf('\nParametric marking');
      fprintf(' (%.5f sec)',markIndTime);
      fprintf('\n    <strong>%d/%d overall marked indices</strong>',size(M_ind,1),Q);
            
  end
  
  fprintf('\nTotal MARK time = %.5f sec',markTotTime);
  
% Print estimates
  fprintf('\nError estimates (marked indicators)');
  fprintf('\n    YP-estimate (overall marked elements/edges): <strong>%10.4e</strong>',yp_err_est_marked);  
  fprintf('\n    XQ-estimate (overall marked indices):        <strong>%10.4e</strong>\n',xq_err_est_marked);
    
% end scriptfile