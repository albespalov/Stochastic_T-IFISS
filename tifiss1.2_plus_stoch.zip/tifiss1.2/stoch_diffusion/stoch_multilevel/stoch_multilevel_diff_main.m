%STOCH_MULTILEVEL_DIFF_MAIN solves stochastic diffusion problem using adaptive multilevel SGFEM
%
% Main driver for the adaptive multilevel sGFEM algorithm.
%
% Final outputs are saved to:
% - datafiles/stoch_multilevel_final_output.dat;
% - datafiles/stoch_multilevel_final_mesh.dat;
%
%   TIFISS scriptfile: AB; 3 January 2022
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Initial parameters
  stoch_multilevel_init_param;

% Spatial initialisation of the mesh
  stoch_multilevel_init_spatial;

% Random variables and stochastic coefficients initialisation
  stoch_multilevel_init_stoch;

% -------------------------------------------------------------------------
% Adaptive Finite Element Loop
% -------------------------------------------------------------------------
  iter = 0;
  endLoopFlag = 0;

% Mesh-refinement/polynomial-enrichment switch
% 1 -> polynomial enrichment (separate marking)
% 2 -> mesh refinement (separate marking)
% 3 -> both (combined marking)
  polenr_or_meshref = 0;

% Debug: display (or not) the initial data
  iDebugMode = default('\nRun code in debug mode 1/0 (yes/no)? (default no)',0);
  if ~ismember(iDebugMode,[0,1]), error('Choose either 1 or 0!'); end
  if iDebugMode
      stoch_multilevel_display_info_debug;
  end

% Preallocating memory for dof, error, arv, and energy vectors
  stoch_multilevel_update_vectors;

  startLoopTime = tic;
  while true
    % Update counter iteration
      iter = iter + 1;

      fprintf('\n'); fprintf(num2str(repmat('<strong>-</strong>',1,60))); fprintf('\n');
      fprintf('<strong>Iteration %i\n</strong>',iter);
      fprintf(num2str(repmat('<strong>-</strong>',1,60))); fprintf('\n');

    % -------------------------------------------------------
    % Parametric enrichments and/or spatial refinements
    % -------------------------------------------------------
      fprintf('\n<strong>REFINE</strong>');

      if polenr_or_meshref == 1 % Polynomial enrichment: updating the index set

            polEnrichTime = tic;
          % Checking limit on random variables
            [~,Q_noarv] = find(Q_indset(M_ind,:));
            if (max(Q_noarv) + extra_rv) > norv
                fprintf('<strong>Terminated: limit norv is achieved. Tolerance is not met</strong>\n');
                endLoopFlag = 1;
                iter = iter-1;
                break;
            end
          % Update index set and detail index set
            stoch_multilevel_pol_enrich;
            fprintf('\nTotal REFINE time = %.5f sec\n',toc(polEnrichTime));

      elseif polenr_or_meshref == 2 % Mesh refinement

          fprintf('\n<strong>Adaptive mesh refinement</strong>');
          meshRefTime = tic;
          for p_ind = 1:P
              if ~isempty(MMele{p_ind})
                  fprintf('\nRefinement of mesh %i...',p_ind);
                  % Refine each mesh
                  meshesP{p_ind} = stoch_multilevel_mesh_ref(meshesP{p_ind},MMele{p_ind},MMedge{p_ind});
                  % Update data
                  nvtxP(p_ind) = size(meshesP{p_ind}.xy,1);
                  nintP(p_ind) = size(meshesP{p_ind}.interior,1);
                  nbndP(p_ind) = size(meshesP{p_ind}.bound,1);
                  nedgP(p_ind) = size(meshesP{p_ind}.xyY,1);
                  neleP(p_ind) = size(meshesP{p_ind}.evt,1);
                  fprintf(' done');
              end
          end
          fprintf('\nTotal REFINE time = %.5f sec\n',toc(meshRefTime));

      elseif polenr_or_meshref == 3 % do both

          fprintf('\n<strong>Adaptive mesh refinement and polynomial enrichment</strong>');
          bothEnrichTime = tic;

        % First, perform mesh refinement
        
          for p_ind = 1:P
              if ~isempty(MMele{p_ind})
                  fprintf('\nRefinement of mesh %i...',p_ind);
                % Refine each mesh
                  meshesP{p_ind} = stoch_multilevel_mesh_ref(meshesP{p_ind},MMele{p_ind},MMedge{p_ind});
                % Update data
                  nvtxP(p_ind) = size(meshesP{p_ind}.xy,1);
                  nintP(p_ind) = size(meshesP{p_ind}.interior,1);
                  nbndP(p_ind) = size(meshesP{p_ind}.bound,1);
                  nedgP(p_ind) = size(meshesP{p_ind}.xyY,1);
                  neleP(p_ind) = size(meshesP{p_ind}.evt,1);
                  fprintf(' done');
              end
          end

        % Then, perform polynomial enrichment
        % Checking limit on random variables
          if ~isempty(M_ind)
              [~,Q_noarv] = find(Q_indset(M_ind,:));
              if (max(Q_noarv) + extra_rv) > norv
                  fprintf('<strong>Terminated: limit norv is achieved. Tolerance is not met</strong>\n');
                  endLoopFlag = 1;
                  iter = iter-1;
                  break;
              end
            % Update index set and detail index set
              stoch_multilevel_pol_enrich;
          end
          
          fprintf('\nTotal REFINE time = %.5f sec\n',toc(bothEnrichTime));
      
      else % It is the first adaptive step (iter = 1)
          
          fprintf('\nNo refinement in the first adaptive step\n');
     
      end

    % -------------------------------------------------------
    % Setup and solve
    % -------------------------------------------------------
      stoch_multilevel_setup_and_solve;

    % -------------------------------------------------------
    % A posteriori error estimation
    % -------------------------------------------------------
      stoch_multilevel_diffpost;

    % -------------------------------------------------------
    % Marking step:
    % -------------------------------------------------------
      stoch_multilevel_marking;

    % Debug: plot current mesh and displaying data
      if iDebugMode
          stoch_multilevel_display_info_debug;
      end

    % Update vectors
      stoch_multilevel_update_vectors;

    % -------------------------------------------------------
    % Checking tolerance and max number of iterations/dofs
    % -------------------------------------------------------
      if tot_err_est <= err_tol
        % Tolerance reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Tolerance reached!</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;

      elseif iter == max_iter
        % Maximum number of allowed iterations reached
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Max number of iterations reached before the tolerance is achieved</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;

      elseif length(xminres) >= max_dofs
        % Maximum number of allowed dofs overcome
          fprintf('\n--------------------------------------------------\n');
          fprintf('<strong>Max number of dofs reached before the tolerance is achieved</strong>\n');
          fprintf('--------------------------------------------------\n');
          endLoopFlag = 1;
          break;
      end

    % -------------------------------------------------------
    % Mesh refinement or polynomial enrichment?
    % -------------------------------------------------------
    % vartheta variable:
    % vartheta < 1 delays parametric enrichments;
    % vartheta > 1 triggers earlier parametric enrichments.
    % Default value is 1.
      vartheta = 1;

      if isequal(marking_type,1) % Combined marking

          polenr_or_meshref = 3; % Mesh refinement AND polynomial enrichment

      else % Separate marking

          if isequal(algo,1)
              % Version 1: comparing global estimates
              if yp_err_est >= vartheta * xq_err_est
                  polenr_or_meshref = 2; % Mesh refinement
              else
                  polenr_or_meshref = 1; % Parametric enrichment
              end

          else %isequal(algo,2)
              % Version 2: comparing estimates for marked elements/edges and indices
              if yp_err_est_marked >= vartheta * xq_err_est_marked
                  polenr_or_meshref = 2; % Mesh refinement
              else
                  polenr_or_meshref = 1; % Parametric enrichment
              end
          end

      end

  end % end of while loop

  endLoopTime = toc(startLoopTime);

% Resizing vectors
  stoch_multilevel_update_vectors;

% Display the final data
  stoch_multilevel_display_final_data;

% -----------------------------------------------------------------------------
% Save output
% -----------------------------------------------------------------------------

% Resize the index set up to active norvs (noarv)
  [~,col] = find(indset);
  indset = indset(:,1:max(col));

  gohome; cd datafiles;
% Update data sot stoch_data file
  save stoch_data -append noarv P;
% Data from the adaptive loop
  save stoch_multilevel_final_output.mat ...
                       nel_iter itSolver_iter totnvtx_iter intnvtx_iter ...
                       dof_iter dofInt_iter indset noarv                ...
                       cardP_iter cardQ_iter markind_iter arv_iter      ...
                       index_iter index_init Q_indset M_ind extra_rv    ...
                       error_iter energy_iter                           ...
                       yperrest_one_iter yperrest_two_iter              ...
                       xqerrest_one_iter xqerrest_two_iter              ...
                       Ncum_iter endLoopTime nAssembledK_iter
  save stoch_multilevel_final_meshes_and_sol.mat meshesP meshesQ x_gal

% -------------------------------------------------------------------------
% Plots
% -------------------------------------------------------------------------

% Plot final mesh associated with the 0-index
  plot_mesh(meshesP{1}.evt,meshesP{1}.xy,'Final mesh associated with the 0-index');

% Convergence plot
  stoch_multilevel_convplot;
  
% Plot expectation and variance
  fprintf('\nPlotting expectation and variance...');
  stoch_multilevel_plotdata(dom_type,meshesP,nvtxP,x_gal,var_sol);
  fprintf('done\n');
  fprintf('\n-> Output mesh data saved to: datafiles/stoch_multilevel_final_meshes_and_sol.mat');
  fprintf('\n-> Output data saved to:      datafiles/stoch_multilevel_final_output.mat\n');

% Computing and plotting effectivity indices using a precomputed reference solution for default inputs
  if (rd_type==1 && distribution==2 && sigma==1 && std_dev==1.5e-01 && correl_x==2.0e-00 && correl_y==2.0e-00) || ...
          (rd_type==2 && distribution==1 && sdecay==1) || ...
          (rd_type==3 && distribution==1 && mu==1.0 && ell==1.0e-00) || ...
          (rd_type==4 && distribution==1) || ...
          (rd_type==0 && distribution==1)
      fprintf('\nPlotting the effectivity indices...');
      [effindices] = stoch_multilevel_eff_indices(sn,error_iter,energy_iter,1);
      fprintf('done\n');
  else
      fprintf('\nTo compute a reference solution run the script <strong>stoch_multilevel_refenergy</strong>\n');
  end
  
  fprintf('\nTo plot the meshes associated with individual indices run e.g. the command\n')
  fprintf('<strong>plot_mesh(meshesP{4}.evt,meshesP{4}.xy,''Final mesh associated with the 4-th index'');</strong>\n\n');

% end scriptfile