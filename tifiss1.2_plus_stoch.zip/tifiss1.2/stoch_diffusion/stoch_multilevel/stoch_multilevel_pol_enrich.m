%STOCH_MULTILEVEL_POL_ENRICH performs polynomial enrichment and updates the mesh structures accordingly
%
% Output:
%
%      index_iter   set of indices that will be added         
%  index_saveiter   iteration whne polynomila enrichment occurs
%          indset   enriched indset
%         meshesP   cell array containing mesh data for all indices in P
%           nvtxP   vector with the number of vertices of each mesh
%           nintP   vector with the number of interior vertices of each mesh
%           nbndP   vector with the number of boundary vertices of each mesh
%           nedgP   vector with the number of edges of each mesh
%           neleP   vector with the number of elements of each mesh
%               P   new length of indset
%         meshesQ   cell array containing mesh data for all indices in Q
%           nvtxQ   vector with the number of vertices of each mesh
%           nintQ   vector with the number of interior vertices of each mesh
%           nbndQ   vector with the number of boundary vertices of each mesh
%           noarv   new number of active random variables
%           polyd   new total polynomial degree
% 
%   TIFISS scriptfile: AB; 3 January 2022
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Print new indices to be added 
  fprintf('\nAugmenting index set by\n');
  [~,col] = find(Q_indset);
  for i = 1:length(M_ind)
      fprintf(' %i  ',Q_indset(M_ind(i),1:max(col)) ); fprintf(' 0   0  ...\n'); 
  end
  
% Saving the new indices and iteration
  if index_counter <= adaptmax
      index_iter{index_counter} = Q_indset(M_ind,:);
      index_saveiter(index_counter) = iter;
  end
  
% Update the index counter
  index_counter = index_counter + 1;

% Build the new indset
  indset = [indset;Q_indset(M_ind,:)];

% Update meshesP (with mesh0 being assigned to the new indices)
  naddedIndices = size(M_ind,1);
  meshesQmarked = cell(1,naddedIndices);
  [meshesQmarked{:}] = deal(mesh0);
  meshesP = [meshesP,meshesQmarked];
% Update vectors accordingly
  nvtxP = [nvtxP,size(mesh0.xy,1)*ones(1,naddedIndices)];
  nintP = [nintP,size(mesh0.interior,1)*ones(1,naddedIndices)];
  nbndP = [nbndP,size(mesh0.bound,1)*ones(1,naddedIndices)];
  nedgP = [nedgP,size(mesh0.xyY,1)*ones(1,naddedIndices)];
  neleP = [neleP,size(mesh0.evt,1)*ones(1,naddedIndices)];
  
% Sort the new indset
  [indset,mesh_indices] = sortrows(indset);
% Sort meshesP accordingly
  meshesP(1,:) = meshesP(1,mesh_indices);
% Sort vectors accordingly
  nvtxP = nvtxP(mesh_indices);
  nintP = nintP(mesh_indices);
  nbndP = nbndP(mesh_indices);
  nedgP = nedgP(mesh_indices);
  neleP = neleP(mesh_indices);
  
% Length of the new index set
  P = size(indset,1);

% Number of active random variables
  noarv = norv - nnz(all(indset == 0,1));
  
% Maximum (total) polynomial degree
  polyd = max(sum(indset,2));

% new Q index set has to be computed
  fprintf('Computing new ''Q'' indset ...');
% Compute Q index set
  [new_indset] = stoch_adapt_new_indset(indset,noarv,extra_rv);
  Q_indset = new_indset(~ismember(new_indset,indset,'rows'),:);
  Q = size(Q_indset,1);
  meshesQ = cell(1,Q);
  [meshesQ{:}] = deal(mesh0);
  nvtxQ = size(mesh0.xy,1)*ones(1,Q);
  nintQ = size(mesh0.interior,1)*ones(1,Q);
  nbndQ = size(mesh0.bound,1)*ones(1,Q);
  
% end scriptfile