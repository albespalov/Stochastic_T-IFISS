function [lambda] = harmonic_ritz_x(H,iH)
% HARMONIC_RITZ_X computes harmonic ritz values within X_MINRES
%
% [lambda] = harmonic_ritz_x(H,iH);
%
%   input:
%                H      Lanczos Matrix
%               iH      current dimension
%   output:
%           lambda      estimated extremal eigenvalues
% 
% The function is called by STOCH_MULTILEVEL_X_MINRES
%   X-IFISS function: MR; 29 December 2021
% Copyright (c) 2010 D.J. Silvester, V. Simoncini

% Ritz values
  eh = sort(eig(H(1:iH,1:iH)));
% Lambda_minus=min(eh); Lambda_plus=max(eh);
  Lambda_minus = 0.0e0;
  Lambda_plus = max(eh);
% harmonic Ritz values
  eHh=sort(eig(H(1:iH+1,1:iH)'*H(1:iH+1,1:iH),H(1:iH,1:iH)'));
% ieHh=find(eHh<0); lambda_minus=max(eHh(ieHh));
  lambda_minus = 0.0e0;
  lambda_plus = min(eHh(eHh>0));
% extremal values
  lambda = [Lambda_minus,lambda_minus,lambda_plus,Lambda_plus];

end