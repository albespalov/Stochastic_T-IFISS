function stoch_multilevel_gpc_coefficient(n,meshesP,nvtxP,sol)
%STOCH_MULTILEVEL_GPC_COEFFICIENT plots a gpc coefficient of the stochastic Galerkin solution
%
% stoch_multilevel_gpc_coefficient(n,meshesP,nvtxP,sol)
%
% input: 
%                n    index of the gpc coefficient to be plotted
%          meshesP    cell array containing mesh data for all indices
%            nvtxP    vector containing the number of vertices of each mesh
%            p1sol    stochastic P1 solution vector
%
%
%   TIFISS function: MR; 22 September 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Mesh where the n-th gpc coefficient resides
  mesh = meshesP{n};

% Determine dofs associated with th n-th gpc coefficient
  last_indices = cumsum(nvtxP);
  last_index = last_indices(n);  
  if n==1
      first_index = 1;
  else
      first_index = last_indices(n-1)+1;
  end
  
% Plot
  figure  
  trimesh(mesh.evt,mesh.xy(:,1),mesh.xy(:,2),sol(first_index:last_index));
  axis square;
  view(330,30);

end % end function