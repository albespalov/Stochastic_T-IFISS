%STOCH_MULTILEVEL_CONVPLOT plots the computed error estimates versus the overall number of dof
%
% This script is based on the TIFISS script STOCH_CONVPLOT (LR; 22 June 2018).
% It is different from that only for the plot title, which provides information
% about the marking type (combined or separate)
%
%   TIFISS scriptfile: MR; 15 October 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Set sizes for legend, axis, markers, and linewidth
  fontSizeLegend = 15;
  fontSizeAxis   = 15;
  markerSizePlot = 13;
  lindeWidthPlot = 1.5;
  
% Colors
  darkBlue   = [0   141 226] ./ 255;
  darkGreen  = [0.0 100 0.0] ./ 255;
  lightGrenn = [0.0 153 0.0] ./ 255;
  brownPeru  = [205 133  63] ./ 255;
  chocolate  = [210 105  30] ./ 255;
   
% Set limit for degrees of freedom
  xLimInf = (3)*10^(1.0);
  xLimSup = (5)*10^(4.0);    
  if sn == 1
      % Square domain (-1,1)^2
      if algo == 0
          yLimInf = min(xqerrest_one_iter);
      else
          yLimInf = (1)*10^(-3.0);
      end
      yLimSup = (1)*10^(-1.0);  
  elseif ismember(sn,[2,3,9]) 
      % Square domain (0,1)^2
      if algo == 0
          yLimInf = min(xqerrest_one_iter);
      else
          yLimInf = (7)*10^(-4.0);
      end
      yLimSup = (7)*10^(-2);     
  elseif ismember(sn,[4,5,6])
      % L-shaped domain
      if algo == 0
          yLimInf = min(xqerrest_one_iter);
      else
          yLimInf = (3)*10^(-3.0);
      end
      yLimSup = (2)*10^(-1.0);
  else
      % Crack domain
      if algo == 0
          yLimInf = min(xqerrest_one_iter);
      else
          yLimInf = (2)*10^(-3.0);
      end
      yLimSup = (2)*10^(-1.0);
  end
  
% ----------------------------------------------------------------------------- 
% Plot
% -----------------------------------------------------------------------------
  figure(120);
  
% Total estimated error - triangles, dark blue
  loglog(dofInt_iter,error_iter,'^-','Color',darkBlue,'Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
  hold on; grid on;
  
  if algo == 1
      % Global YP estimate - circles, green
      loglog(dofInt_iter,yperrest_one_iter,'o-','Color',lightGrenn,'Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
      %
      % Global XQ estimate - squares, red
      loglog(dofInt_iter,xqerrest_one_iter,'rs-','Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
  elseif algo == 2
      % YP estimate for marked elements - circles, green
      loglog(dofInt_iter,yperrest_two_iter,'o-','Color',lightGrenn,'Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
      %
      % XQ estimate for marked indices - squares, red
      loglog(dofInt_iter,xqerrest_two_iter,'rs-','Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
  elseif algo == 0 % combined marking
      % Global YP estimate - circles, green
      loglog(dofInt_iter,yperrest_one_iter,'o-','Color',lightGrenn,'Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
      %
      % Global XQ estimate - squares, red
      loglog(dofInt_iter,xqerrest_one_iter,'rs-','Linewidth',lindeWidthPlot,'MarkerSize',markerSizePlot);
  end
  
% Plot reference rates dof^-1/2 and dof^-1/3
  if ismember(sn,[1,2,3])
      loglog([xLimInf xLimSup],0.3*[xLimInf xLimSup].^(-0.35),'-','Color',darkBlue);
      loglog([xLimInf xLimSup],1.4*[xLimInf xLimSup].^(-0.5),'k--');
  elseif ismember(sn,[4,5,6])
      loglog([xLimInf xLimSup],0.9*[xLimInf xLimSup].^(-0.35),'-','Color',darkBlue);
      loglog([xLimInf xLimSup],3.6*[xLimInf xLimSup].^(-0.5),'k--');
  elseif sn==7
      loglog([xLimInf xLimSup],1.0*[xLimInf xLimSup].^(-0.35),'-','Color',darkBlue);
      loglog([xLimInf xLimSup],4.0*[xLimInf xLimSup].^(-0.5),'k--');    
  else% sn==8
      loglog([xLimInf xLimSup],0.6*[xLimInf xLimSup].^(-0.35),'-','Color',darkBlue);
      loglog([xLimInf xLimSup],1.7*[xLimInf xLimSup].^(-0.5),'k--');
  end

% ----------------------------------------------------------------------------- 
% Axis, grid, title, and legend
% ----------------------------------------------------------------------------- 
  axis([xLimInf xLimSup yLimInf yLimSup]);
  if algo==0
      title('Combined marking','FontSize',fontSizeAxis);
  else
      title(['Separate marking, version ',num2str(algo)],'FontSize',fontSizeAxis);
  end

  xlabel('degrees of freedom $N$','FontSize',fontSizeAxis,'interpreter','latex');
  ylabel('energy error estimates','FontSize',fontSizeAxis,'interpreter','latex');
  if ismember(algo,[0,1])
      hl = legend('total error estimate','YP-estimate (all elements)','XQ-estimate (all indices in Q)','N^{ -0.35}','N^{ -0.5}');   
  elseif algo == 2
      if markedgelem == 1
          hl = legend('total error estimate','YP-estimate (marked elements)','XQ-estimate (marked indices)','N^{ -0.35}','N^{ -0.5}');
      else
          hl = legend('total error estimate','YP-estimate (marked edges)','XQ-estimate (marked indices)','N^{ -0.35}','N^{ -0.5}');
      end
  end
  set(hl,'FontSize',fontSizeLegend);
 
% ----------------------------------------------------------------------------- 
% Setup axis, position, and size of the plot windows
% -----------------------------------------------------------------------------
  set(gca,'XTick',[10^1 10^2 10^3 10^4 10^5 10^6],...
          'XTickMode','manual',...
          'XMinorTick','on', 'YMinorTick','on',...
          'XMinorGrid','off','YMinorGrid','off',...
          'GridLineStyle','--','FontSize',fontSizeAxis);
  set(gcf,'units','normalized','Position',[0.25 0.05 0.55 0.8]);
  hold off;
  
% end scriptfile