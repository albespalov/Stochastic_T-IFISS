function [ae,fe] = stoch_diffpost_p1_yp_bc(ae,fe,xy,evt,eboundt,evtY,xyY,P,norv)
%STOCH_DIFFPOST_P1_YP_BC imposes Dirichlet boundary conditions on boundary midpoints
%
% [ae,fe] = stoch_diffpost_p1_yp_bc(ae,fe,xy,evt,eboundt,evtY,xyY,P,norv)
%
% input:
%          ae    elementwise lhs matrices (without bc imposed)
%          fe    elementwise rhs vectors  (without bc imposed)
%          xy    vertex coordinate vector  
%         evt    element mapping matrix
%     eboundt    element edge boundary matrix
%        evtY    element mapping matrix for midpoints
%         xyY    vertex coordinate vector for midpoints
%           P    length of the index set
%        norv    number of random variables
%
% output:
%          ae    elementwise lhs matrices (with bc imposed)
%          fe    elementwise rhs vectors  (with bc imposed)
%
% Function(s) called: stoch_specific_bc
% 
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi
  
% -----------------------------------------------------------------------------
% Extract boundary elements with boundary edges respectively = 1, 2, and 3
% -----------------------------------------------------------------------------
  beled1 = eboundt( eboundt(:,2)==1 , 1);     nbel1 = length(beled1);
  beled2 = eboundt( eboundt(:,2)==2 , 1);     nbel2 = length(beled2);
  beled3 = eboundt( eboundt(:,2)==3 , 1);     nbel3 = length(beled3);
   
% -----------------------------------------------------------------------------
% Extract boundary nodes/midpoints and compute the error
% -----------------------------------------------------------------------------
  node1    = evt ( beled1, [2 3]);    % nodes of the 1st boundary edges (columns 2,3 of evt)
  midp1    = evtY( beled1, 1);        % midpoints on 1st boundary edges (column 1 of evtY)
  [error1] = interperror_bc(xy,xyY,node1,midp1,norv);
  
  node2    = evt ( beled2, [3 1]);    % nodes of the 2nd boundary edges (columns 3,1 of evt)
  midp2    = evtY( beled2, 2);        % midpoints on 2nd boundary edges (column 2 of evtY)
  [error2] = interperror_bc(xy,xyY,node2,midp2,norv);
  
  node3    = evt ( beled3, [1 2]);    % nodes of the 3rd boundary edges (columns 1,2 of evt)
  midp3    = evtY( beled3, 3);        % midpoints on 3rd boundary edges (column 3 of evtY)
  [error3] = interperror_bc(xy,xyY,node3,midp3,norv);

% -----------------------------------------------------------------------------  
% Update the RHS in internal boundary-element midpoint positions
% -----------------------------------------------------------------------------
% Update rhs for P = 1 (i.e., for index (0,0,...,0))
  feloc = fe(:,1:3);  
  feloc(beled1,[2,3]) = feloc(beled1,[2,3]) - ae(beled1,[2,3],1) .* repmat(error1,1,2);
  feloc(beled2,[1,3]) = feloc(beled2,[1,3]) - ae(beled2,[1,3],2) .* repmat(error2,1,2);
  feloc(beled3,[1,2]) = feloc(beled3,[1,2]) - ae(beled3,[1,2],3) .* repmat(error3,1,2);
% Update
  fe(:,1:3) = feloc;

% For all other indices we put zero as boundary conditions are deterministic
  for nu = 2:P
      % Extract columns [4,5,6], [7,8,9], and so on...
      col = 1+3*(nu-1):(3*nu);
      feloc = fe(:,col);
      feloc(beled1,[2,3]) = feloc(beled1,[2,3]) - ae(beled1,[2,3],1) .* repmat(zeros(nbel1,1), 1, 2);
      feloc(beled2,[1,3]) = feloc(beled2,[1,3]) - ae(beled2,[1,3],2) .* repmat(zeros(nbel2,1), 1, 2);
      feloc(beled3,[1,2]) = feloc(beled3,[1,2]) - ae(beled3,[1,2],3) .* repmat(zeros(nbel3,1), 1, 2);
      % Update
      fe(:,col) = feloc;
  end
  
% -----------------------------------------------------------------------------
% Impose Dirichlet condition on LHS matrix
% -----------------------------------------------------------------------------
% Boundary elements with boundary edge = 1 
  ae(beled1,:,1) = 0.0;
  ae(beled1,1,:) = 0.0;
  ae(beled1,1,1) = 1.0;

% Boundary elements with boundary edge = 2
  ae(beled2,:,2) = 0.0;
  ae(beled2,2,:) = 0.0;
  ae(beled2,2,2) = 1.0;
  
% Boundary elements with boundary edge = 3
  ae(beled3,:,3) = 0.0;
  ae(beled3,3,:) = 0.0;
  ae(beled3,3,3) = 1.0;
     
% -----------------------------------------------------------------------------  
% Finally update the RHS in all boundary-midpoint positions
% -----------------------------------------------------------------------------
% In order to adjust dimensions we have to add also zeros columns since the 
% boundary conditions are determinstic   
  pos1 = 1:3:(3*P)-2;     fe(beled1,pos1) = [error1, zeros(nbel1,P-1)];
  pos2 = 2:3:(3*P)-1;     fe(beled2,pos2) = [error2, zeros(nbel2,P-1)];
  pos3 = 3:3:(3*P)-0;     fe(beled3,pos3) = [error3, zeros(nbel3,P-1)];
 
end  % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [error] = interperror_bc(xy,xyY,bnodesX,bnodeY,norv)
% Impose the error on boundary midpoints

% Coordinates of the boundary nodes and of boundary edge's midpoints
  allxbd_X = reshape( xy(bnodesX,1), size(bnodesX,1), 2);
  allybd_X = reshape( xy(bnodesX,2), size(bnodesX,1), 2);
  xybd_Y   = xyY(bnodeY, :);
  
% Compute boundary conditions for the given nodes 
  [bc_firstNodeX]  = stoch_specific_bc(allxbd_X(:,1), allybd_X(:,1), norv);
  [bc_secondNodeX] = stoch_specific_bc(allxbd_X(:,2), allybd_X(:,2), norv);
  [bc_nodeY]       = stoch_specific_bc(xybd_Y(:,1),   xybd_Y(:,2),   norv);

% Extract the first "non-parametric" column (in case the b.c. are
% non-parametric, i.e., columns from 2 to norv+1 are zeros)
  bc_firstNodeX  = bc_firstNodeX(:,1);  
  bc_secondNodeX = bc_secondNodeX(:,1); 
  bc_nodeY       = bc_nodeY(:,1);

% Interpolated error
  error = bc_nodeY - 0.5 * (bc_firstNodeX + bc_secondNodeX);
    
end % end child function