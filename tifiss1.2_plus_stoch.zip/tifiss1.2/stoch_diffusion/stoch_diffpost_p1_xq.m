function [Q_indset,GPQ,xq_elerr,xq_err_vec,xq_err_est] = stoch_diffpost_p1_xq(xy,evt,...
                       bound,p1sol,indset,polyd,norv,noarv,extra_rv,KL_DATA,pm_choice)
%STOCH_DIFFPOST_P1_XQ computes XQ error estimator for stochastic P1 solution
%
% [Q_indset,GPQ,xq_elerr,xq_err_vec,xq_err_est] = stoch_diffpost_p1_xq(xy,evt,...
%               bound,p1sol,indset,polyd,norv,noarv,extra_rv,KL_DATA,pm_choice)
%                                       
% input:
%                xy      vertex coordinate vector
%               evt      element mapping matrix
%             bound      boundary vertex vector
%             p1sol      stochastic P1 solution vector
%            indset      index set of polynomial degrees
%             polyd      maximum polynomial degree in the index set
%              norv      number of admissible random variables
%             noarv      number of active random variables (<=norv)
%          extra_rv      number of extra random variables activated in the detail index set
%           KL_DATA      data related to KL-expansion
%         pm_choice      method for enriching the polynomial space
%
% output:
%          Q_indset      new 'detail' index set
%               GPQ      new cell of GPQ-matrices
%          xq_elerr      vector of XQ (spatial) element indicators 
%        xq_err_vec      vector of XQ index indicators (for each \mu \in Q_indset)
%        xq_err_est      global XQ energy error estimate
%
% V_{XQ}-estimator: employs the same P1 basis functions as for the solution
% tensorised with the 'detailed set' of polynomials. 
%
% The function solves the discrete formulations for the eXQ error estimator
%
%   B0(eXQ,v) = F(v) - B(uXP,v),     for all v \in VXQ              (1)
%
% by exploiting the decomposition of eXQ into contributions individual 
% indices \mu in Q. See pag. A2127-A2128 of [BS16].
%
% Reference: 
% 
% [BS16] Bespalov, Silvester, Efficient adaptive stochastic Galerkin methods for
% parametric operator equations, SIAM J. Sci. Comput., 38(4)A2127-A2128, 2016;
%
% Function(s) called:    stoch_detail_indset
%                        stoch_adapt_new_indset
%                        triangular_gausspoints
%                        tderiv
%                        stoch_gauss_coeff
%                        stoch_gpqmatrices
%
% See also STOCH_ADAPT_DIFFPOST_P1_XQ
% 
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Check dimensions
  [P,norvx] = size(indset); 
  if ~isequal(norvx,norv)
      error('Something wrong with dimensions...!');
  end
  
  nvtx = size(xy,1);    % Number of vertices
  nel  = size(evt,1);   % Number of elements
  
% -------------------------------------------------------------------------   
% Compute the Q_indset and associated GPQ matrices
% -------------------------------------------------------------------------     
% Compute Q_indset
  fprintf('   computing new ''Q'' indset and GPQ matrices... ');    
  [Q_indset] = stoch_detail_indset(indset,polyd,norv,noarv,extra_rv,pm_choice);

% Compute G-matrices for P and Q index set (of size Q-by-P)
  [GPQ] = stoch_gpqmatrices(indset,Q_indset);
  fprintf('done\n');
  
% Length of Q_indset
  Q = size(Q_indset,1);   
     
% Setting the effective number of active random variables needed for computation
  new_noarv = size(GPQ,2) - 1;
     
% Initialise local deterministic matrices and local coordinates
  ade = zeros(nel,3,3,new_noarv+1);

% Recover local coordinates
  xl_v = zeros(nel,3);
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy(evt(:,ivtx),1);
      yl_v(:,ivtx) = xy(evt(:,ivtx),2); 
  end
  
% Construct the integration rule (3/7/19/73 Gaussian points)
  nngpt = 7;
  [s,t,wt] = triangular_gausspoints(nngpt);  

% ------------------------------------------------------------------------- 
% Computing deterministic element-wise contributions
% -------------------------------------------------------------------------
  for igpt = 1:nngpt
      sigpt = s(igpt);
      tigpt = t(igpt);
      wght  = wt(igpt);
      %
      % Evaluate derivatives and coefficients
      [~,invjac_v,~,dphidx_v,dphidy_v] = tderiv(sigpt,tigpt,xl_v,yl_v);
      [coeff_v] = stoch_gauss_coeff(sigpt,tigpt,xl_v,yl_v,norv,KL_DATA);
      %
      % Element-wise stiffness matrices
      for m = 0:new_noarv
          for j = 1:3
              for i = 1:3
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff_v(:,m+1) .* dphidx_v(:,i) .* dphidx_v(:,j) .* invjac_v(:);
                  ade(:,i,j,m+1) = ade(:,i,j,m+1) + wght * coeff_v(:,m+1) .* dphidy_v(:,i) .* dphidy_v(:,j) .* invjac_v(:);
              end
          end
      end
  end
  
% -------------------------------------------------------------------------
% Left-Hand side of (1): B(eXQ,v), with both eXQ and v \in VXQ
% -------------------------------------------------------------------------
% The resulting fully assembled matrix will be a block diagonal matrix 
% where each block is represented by [K_0]_ij, that is the stiffness matrix
% associated with a_0(x). It comes from the Kronecker product between Id 
% matrix of size Q and K_0. However, there is no need to assemble it
  
% Deterministic block K_0 of the full matrix on the lhs
  K_0 = sparse(nvtx,nvtx);
  for krow = 1:3
      nrow = evt(:,krow);	 
      for kcol = 1:3
          ncol = evt(:,kcol);	  
          K_0 = K_0 + sparse(nrow,ncol,ade(:,krow,kcol,1),nvtx,nvtx);
      end
  end
  
% -------------------------------------------------------------------------        
% Assembling the RHS of (1): F(v) - B(uXP,v), with uXP \in VXP, v \in VXQ 
% -------------------------------------------------------------------------
% NOTE that F(v) = 0 since f is deterministic and, as always assumed, the 
% index (0,0,...,0) is not in Q_indset
  ff = sparse(nvtx,Q);
  
% Reshape x_gal vector for efficient kronecker product  
  X = reshape(p1sol,nvtx,P);

% Perform assembly of global rhs 
  for m = 1:new_noarv
      %
      % Assembling K_m stiffness matrices for current value of m
      Km = sparse(nvtx,nvtx);
      for krow = 1:3
          nrow = evt(:,krow);	 
          for kcol = 1:3
              ncol = evt(:,kcol);	  
              Km = Km + sparse(nrow,ncol,ade(:,krow,kcol,m+1),nvtx,nvtx);
          end
      end 
      %  
      % Efficient kronecker product between GPQ{m+1} and K_m matrices 
      % avoiding storage of the full matrix \sum_m kron(G{m},rhsB{m}): see 
      % Nagy's lecture and stoch_matvec function.   
      Bx = Km * X * GPQ{m+1}';      
      ff = ff - Bx;   
      
  end
  
% -----------------------------------------------------------------------------
% Imposing Dirichlet boundary condition
% -----------------------------------------------------------------------------
% Note that these are zeros if bcs are non-parametric (deterministic)
% and, as always assumed, (0,0,0,...) is not in Q_indset; this means the bcs 
% matrix contains zero-columns from the 2nd to norv+1 column.
% In this case, it suffices to put zero on boundary rows/columns, put 1 in
% the corresponding diagonal entries, and set the RHS to zero in boundary 
% positions, no matter whether bcs were homogeneous or not (here, we are in VXQ).
% If the b.c. are parametric, then STOCH_RHS_MULTIPLIERS has to be called and 
% the same construction as in STOCH_IMPOSEBCX has to be done.
  K_0(bound,:) = 0.0;
  K_0(:,bound) = 0.0;
  K_0(bound,bound) = speye(length(bound),length(bound));
  ff(bound,:)  = 0.0;
 
% -------------------------------------------------------------------------  
% Solving the system
% -------------------------------------------------------------------------
% Getting the e_XQ solution for each vertex (and for each mode)
  G1 = eye(Q,Q);
  xq_err_gal = (K_0\ff)/G1;

% -----------------------------------------------------------------------------  
% B0-norm and elementwise estimates
% -----------------------------------------------------------------------------
% Computing the B0-norm of e_XQ^(\mu), for each index \mu \in Q, and the 
% elementwise XQ-estimates needed (only) to plot the last XQ-estimate at
% the end of the loop
  xq_err_vec   = zeros(Q,1);
  err_loc      = zeros(nel,3);
  xq_err_el_sq = zeros(nel,1);
% Loop over modes  
  for mu = 1:Q
      %
      % Local B0 norm for current index \mu
      xq_err_vec(mu) = sqrt(xq_err_gal(:,mu)' * K_0 * xq_err_gal(:,mu));
      %
      % Rearranging e_XQ nodal values element-wise
      for ivtx = 1:3
          err_loc(:,ivtx) = xq_err_gal(evt(:,ivtx),mu);
      end 
      %      
      % Computing XQ estimators element-wise
      for ivtx = 1:3          
          for jvtx = 1:3
              xq_err_el_sq(:) = xq_err_el_sq(:) + err_loc(:,ivtx) .* ade(:,ivtx,jvtx,1) .* err_loc(:,jvtx);
          end  
      end  
  end
  
% -----------------------------------------------------------------------------
% Global XQ-estimates (B0-norm of the estimated error)
% -----------------------------------------------------------------------------
  xq_elerr   = sqrt(xq_err_el_sq); %(needed only for the final error-plot)
  xq_err_est = norm(xq_elerr,2);
   
end % end function