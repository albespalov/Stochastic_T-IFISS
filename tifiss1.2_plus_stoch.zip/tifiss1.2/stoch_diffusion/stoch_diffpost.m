%STOCH_DIFFPOST a posteriori error estimation for single-runs
%
% The function implements P1-based error approximation scheme for the stochastic 
% Galerkin FE solution including three types of estimations for the spatial 
% component of the error:
%
% 1 - eYP hierarchical estimator (solving elementwise residual problems);
% 2 - eYP hierarchical estimator (solving fully assembled residual problem);
% 3 - 2-level error estimator.
%
% NOTE that it is possible to choose between red and bisec3 uniform  
% sub-divisions for the spatial estimation by changing the variable 
% 'subdivPar'; see STOCH_DIFF_MAIN.
%
% Function(s) called: stoch_diffpost_p1_yp
%                     stoch_diffpost_p1_yp_linsys
%                     stoch_diffpost_p1_yp_2level
%                     stoch_diffpost_p1_xq
%
% See also STOCH_ADAPT_DIFFPOST
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  fprintf('\n<strong>A posteriori error estimation</strong>\n');    

% -----------------------------------------------------------------------
% Parametric enrichment type
% -----------------------------------------------------------------------
% The parameter 'pm_choice' indicates the method for enriching the
% polynomial space (i.e., how to compute the detail Q index set)
  if noarv == 0
      fprintf('pM enrichment of the polynomial space...\n');
      pm_choice = 3;
  else% noarv > 0 
      pm_choice = default('p/M/pM enrichment of the polynomial space 1/2/3? (default 3)',3);
      if ~ismember(pm_choice,[1,2,3]), error('Oops... wrong enrichment parameter!'); end
      %
      % Checking that there is enough norv to build the Q index set (for pm_choice = 2 or 3)
      if ismember(pm_choice,[2,3])
          if (noarv + extra_rv) > norv
             error('Oops... the detail index set cannot be computed, increase the parameter norv!');
          end
      end
  end

  if pmethod == 1   
      % ----------------------------------------------------------------
      % YP error estimation 
      % ----------------------------------------------------------------
      % The estimation is based on the full detail space Y composed of basis
      % functions associated with all edge midpoints. 
      fprintf('<strong>YP-error estimation</strong>\n');
      yptime = tic;         
      if ypestim == 1         
          % Hierarchical eYP estimator: elementwise local residual problems. 
          % Only element indicators returned
          fprintf('   Spatial hierarchical estimator (element residual problems)\n');
          [yp_elerr,yp_err_est] = stoch_diffpost_p1_yp(xy,evt,eboundt,evtY,xyY,x_gal,...
                                  eex,tve,els,G,indset,P,norv,noarv,KL_DATA,subdivPar);

      elseif ypestim == 2
          % Hierarchical eYP estimator: fully assembled residual problems.
          % Both element and edge indicators returned
          fprintf('   Spatial hierarchical estimator (full system)\n');
          [yp_elerr,~,yp_err_est] = stoch_diffpost_p1_yp_linsys(xy,evt,eboundt,...
                          evtY,xyY,boundY,Ybasis,x_gal,G,P,norv,noarv,KL_DATA,subdivPar);
                        
      else
          % 2-Level error estimator; both element and edge indicators returned
          fprintf('   Spatial 2-level error estimator\n');
          [yp_elerr,~,yp_err_est] = stoch_diffpost_p1_yp_2level(xy,evt,eboundt,...
                         evtY,xyY,boundY,Ybasis,x_gal,G,P,norv,noarv,KL_DATA,subdivPar);                   
      end                        
      fprintf('   YP-error estimation took %.5f sec',toc(yptime)); 

      % ----------------------------------------------------------------
      % XQ error estimator
      % ----------------------------------------------------------------
      fprintf('\n<strong>XQ-error estimation</strong>\n');
      xqTime = tic;
      [~,~,xq_elerr,~,xq_err_est] = stoch_diffpost_p1_xq(xy,evt,bound,x_gal,indset,...
                                    polyd,norv,noarv,extra_rv,KL_DATA,pm_choice);
      fprintf('   XQ-error estimation took %.5f sec',toc(yptime));

  %elseif pmethod == 2
  % Not implemented yet...      
  end 

% -------------------------------------------------------------------
% Print YP/XQ estimates and total error estimate
% -------------------------------------------------------------------
  tot_err_est = sqrt(xq_err_est^2 + yp_err_est^2);
  fprintf('\n\nSimplistic YP-estimate of energy error: %2.5e',yp_err_est);
  fprintf('\nSimplistic XQ-estimate of energy error: %2.5e',xq_err_est);
  fprintf('\n<strong>Simplistic estimate of energy error:    %2.5e</strong>\n',tot_err_est);  
  
% end scriptfile