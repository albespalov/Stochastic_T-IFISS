function [var_x] = stoch_variancex(x_gal,P)
%STOCH_VARIANCEX computes the variance of the stochastic solution
%
% [var_x] = stoch_variancex(x_gal,P)
%
% input:
%        x_gal   coefficient vector for the stochastic solution
%            P   length of the index set
%
% output:
%        var_x   vector of values of the variance (at the mesh points)
%
% NOTE: this function is based on the original SIFISS function 
% STOCH_VARIANCE (DJS; 17 March 2013).
% The new function avoids the division by 2^noarv.
%
%   TIFISS function: LR; 05 January 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Number of vertices
  nvtx = length(x_gal)/P;

% Reshape Galerkin solution
  x_matr = reshape(x_gal,nvtx,P);

% Compute variance
  var_x = zeros(nvtx,1);
  for k = 2:P
      var_x(:) = var_x(:) + (x_matr(:,k)) .* (x_matr(:,k));
  end

end % end function