function stoch_trunc_gauss_coeff(N,L,sigma)
%STOCH_TRUNC_GAUSS_COEFF generates coefficients in recurrence relation for truncated gaussian pdf
%
% stoch_trunc_gauss_coeff(N,L,sigma)
%
% input:
%            N   maximum polynomial degree
%            L   integration interval parameter (I = (-L,L))
%        sigma   standard deviation
%
% output:
%         beta   approximations to coefficients in the recurrence relation
%                for orthogonal polynomials
%                (written and saved to the file "beta_truncated_gaussian.dat")
%
% NOTE: this version computes inner products recursively
%       (unstable for large polynomial degrees!).
%
% See also STOCH_TRUNC_GAUSS_COEFFX
%
%   TIFISS function: AB; 19 January 2018
% Copyright (c) 2018 A. Bespalov, F. Xu

erffactor = sqrt(pi)*erf(L/sqrt(2)/sigma);
LS = L^2/2/sigma^2;
% 2*N+1 moments
mu = zeros(2*N+1,1);
for k = 1:N+1
    mu(2*k-1)=2^(k-1)*sigma^(2*k-2)*gamma((2*k-1)/2)*gammainc(LS,(2*k-1)/2);
end
mu = mu/erffactor;
% N+1 inner products N+1 coefficients beta; coefficient matrix of
% polynomials A; coefficient matrix of orthonormal polynomials B
ip = zeros(N+1,1);
beta = zeros(N+1,1);
A = zeros(N+1,N+1);

A(1,1)=1; % P_0
ip(1) = 1;
beta(1)=1;
A(2,1)=1; % P_1
for n = 2:N
    ip(n)=0;
    for k=1:n
        for l=1:n
            ip(n)=ip(n)+A(n,n-k+1)*A(n,n-l+1)*mu(k+l-1);
        end
    end
    beta(n)=ip(n)/ip(n-1); % ip(n) is very small for large n, which will cause the loss of accuracy for beta(n)
    A(n+1,:)=A(n,:)-beta(n)*circshift(A(n-1,:),[2,0]);
end
ip(N+1)=0;
for k=1:N+1
    for l=1:N+1
        ip(N+1)=ip(N+1)+A(N+1,N+1-k+1)*A(N+1,N+1-l+1)*mu(k+l-1);
    end
end
beta(N+1)=ip(N+1)/ip(N);
csvwrite('beta_truncated_gaussian.dat',beta(2:end)); % discard beta_0
end
