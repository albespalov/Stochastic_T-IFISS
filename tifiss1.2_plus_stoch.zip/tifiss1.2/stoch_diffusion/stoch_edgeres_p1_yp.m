function [edgeres] = stoch_edgeres_p1_yp(xy,evt,eboundt,p1sol,eex,tve,els,P,G,norv,noarv,KL_DATA)
%STOCH_EDGERES_P1_YP computes YP edge residuals for P1 stochastic Galerkin solution
%
% [edgeres] = stoch_edgeres_p1_yp(xy,evt,eboundt,p1sol,eex,tve,els,P,G,norv,noarv,KL_DATA)
%
% input:
%               xy      vertex coordinate vector
%              evt      element mapping matrix
%          eboundt      element edge boundary matrix
%            p1sol      stochastic P1 solution vector
%              eex      element connectivity array
%              tve      edge location array
%              els      elementwise edge lengths
%                P      length of the index set
%                G      (1 x (noarv+1)) cell of G-matrices
%             norv      number of random variables
%            noarv      number of active random variables
%          KL_DATA      data related to KL-expansion
%
% output:
%          edgeres      edge residuals
%
% The function computes the 'edge' residuals of local residual problems:
%
% edgeres := (1/2)\int_Gamma\int_{\partial K}a(s,y)Jump(uXP(s,y))v(s,y) dsdpiy,
%
% Function(s) called:   gausspoints_oned
%                       stoch_gauss_coeff
%                       tderiv
%                       stoch_p1fluxjmps
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nvtx = size(xy,1);   % Number of vertices
  nel  = size(evt,1);  % Number of elements
    
% Construct the integration rule (1/2/3/4/7/10 Gaussian points)
  ngpt = 10;
  [oneg,onew] = gausspoints_oned(ngpt);

% Initialise matrices
  edgeres  = zeros(nel,3*P);
  temp_res = zeros(nel,3,P,noarv+1);

% Recover local coordinates  
  xl_v = zeros(nel,3); 
  yl_v = zeros(nel,3);
  for ivtx = 1:3
      xl_v(:,ivtx) = xy( evt(:,ivtx), 1);
      yl_v(:,ivtx) = xy( evt(:,ivtx), 2); 
  end
  
% Recover the 3 external normals of each element
  [nx,ny] = get_normals(xl_v,yl_v,els);  

% Loop over Gauss points
  for igpt = 1:ngpt     
      sigpt = oneg(igpt);
      sigpt_ref_edge = (1.0 + sigpt)/2.0; % [-1,1] -> [0,1]    reference-edge map
      sigpt_l = (1.0 + sigpt)/4.0;        % [-1,1] -> [0,1/2]  LEFT sub-edge map
      sigpt_r = (3.0 + sigpt)/4.0;        % [-1,1] -> [1/2,1]  RIGHT sub-edge map
      wigpt = onew(igpt);
      %
      % First edge
      coeff_l_1 = stoch_gauss_coeff(sigpt_l,1-sigpt_l,xl_v,yl_v,norv,KL_DATA);
      coeff_r_1 = stoch_gauss_coeff(sigpt_r,1-sigpt_r,xl_v,yl_v,norv,KL_DATA);
      [~,~,phi_v_1,~,~] = tderiv(sigpt_ref_edge,1-sigpt_ref_edge,xl_v,yl_v);
      %      
      % Second edge
      coeff_l_2 = stoch_gauss_coeff(0,sigpt_l,xl_v,yl_v,norv,KL_DATA);
      coeff_r_2 = stoch_gauss_coeff(0,sigpt_r,xl_v,yl_v,norv,KL_DATA);
      [~,~,phi_v_2,~,~] = tderiv(0,sigpt_ref_edge,xl_v,yl_v);
      %
      % Third edge
      coeff_l_3 = stoch_gauss_coeff(sigpt_l,0,xl_v,yl_v,norv,KL_DATA);
      coeff_r_3 = stoch_gauss_coeff(sigpt_r,0,xl_v,yl_v,norv,KL_DATA);
      [~,~,phi_v_3,~,~] = tderiv(sigpt_ref_edge,0,xl_v,yl_v);
      %
      % Loop over indices in the index set
      for k = 1:P   
          %
          % Galerkin solution's jumps over the LEFT sub-element edges
          [njmp_l] = stoch_p1fluxjmps(xl_v,yl_v,p1sol((k-1)*nvtx+1:k*nvtx,1),nx,ny,eboundt,evt,eex,tve,sigpt_l);   %         nx,ny,eex,xy,evt,eboundt,tve,sigpt_l);       
          %
          % Galerkin solution's jumps over the RIGHT sub-element edges
          [njmp_r] = stoch_p1fluxjmps(xl_v,yl_v,p1sol((k-1)*nvtx+1:k*nvtx,1),nx,ny,eboundt,evt,eex,tve,sigpt_r); %nx,ny,eex,xy,evt,eboundt,tve,sigpt_r); 
          %      
          % Loop over stochastic variables
          for m = 0:noarv                      
              % Contribution from the FIRST edge
              temp_res(:,1,k,m+1) = temp_res(:,1,k,m+1) + (1/2) * wigpt * coeff_l_1(:,m+1) .* njmp_l(:,1) .* phi_v_1(:,2) .* (els(:,1)/4);
              temp_res(:,1,k,m+1) = temp_res(:,1,k,m+1) + (1/2) * wigpt * coeff_r_1(:,m+1) .* njmp_r(:,1) .* phi_v_1(:,3) .* (els(:,1)/4);
              %
              % Contribution from the SECOND edge
              temp_res(:,2,k,m+1) = temp_res(:,2,k,m+1) + (1/2) * wigpt * coeff_l_2(:,m+1) .* njmp_l(:,2) .* phi_v_2(:,3) .* (els(:,2)/4);
              temp_res(:,2,k,m+1) = temp_res(:,2,k,m+1) + (1/2) * wigpt * coeff_r_2(:,m+1) .* njmp_r(:,2) .* phi_v_2(:,1) .* (els(:,2)/4);
              %
              % Contribution from the THIRD edge
              temp_res(:,3,k,m+1) = temp_res(:,3,k,m+1) + (1/2) * wigpt * coeff_l_3(:,m+1) .* njmp_l(:,3) .* phi_v_3(:,2) .* (els(:,3)/4);
              temp_res(:,3,k,m+1) = temp_res(:,3,k,m+1) + (1/2) * wigpt * coeff_r_3(:,m+1) .* njmp_r(:,3) .* phi_v_3(:,1) .* (els(:,3)/4);
          end
          % end of the loop over stochastic variables
      end
      % end of the loop over indices in the index set
  end
% end of Gauss points loop
  
% -----------------------------------------------------------------------------
% Building edge residual vector
% -----------------------------------------------------------------------------
  for m = 0:noarv     %norv
      [nzi,nzj,g] = find(G{m+1});
      for t = 1:length(nzi)
          i = nzi(t);
          j = nzj(t);
          edgeres(:,(3*(j-1)+1):(3*j)) = edgeres(:,(3*(j-1)+1):(3*j)) + g(t)*temp_res(:,1:3,i,m+1);
      end
  end
 
end % end function


% -----------------------------------------------------------------------------
% Child function
% -----------------------------------------------------------------------------
function [nx,ny] = get_normals(xv,yv,els)
%Recover the 3 external unit normals per each element in the mesh: nx and ny
%contain the x-component and the y-component of the normals respectively

  sxe1 = (xv(:,3) - xv(:,2))./els(:,1);  sye1 = (yv(:,3) - yv(:,2))./els(:,1);  % unit tangential components 1st edge
  sxe2 = (xv(:,1) - xv(:,3))./els(:,2);  sye2 = (yv(:,1) - yv(:,3))./els(:,2);  % unit tangential components 2nd edge 
  sxe3 = (xv(:,2) - xv(:,1))./els(:,3);  sye3 = (yv(:,2) - yv(:,1))./els(:,3);  % unit tangential components 3rd edge
	  
  nxe1 = sye1;    nye1 = -sxe1;                                                 % unit normal components 1st edge
  nxe2 = sye2;    nye2 = -sxe2;                                                 % unit normal components 2nd edge
  nxe3 = sye3;    nye3 = -sxe3;                                                 % unit normal components 3rd edge
	  
% Store the x-component and the y-component of the normals
  nx = [nxe1, nxe2, nxe3];   	  
  ny = [nye1, nye2, nye3];
  
end % end child function