%STOCH_GOAFEM_TESTPROBLEM sets up goal-oriented adaptive SGFEM examples (Unix version)
%   TIFISS scriptfile: MR; 04 July 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  gohome; cd stoch_diffusion;

  fprintf('\nSpecification of goal-oriented example for adaptive SGFEM.');
  fprintf('\nChoose specific example:');
  fprintf('\n   1.  Square domain (-1,1)^2, Karhunen-Loeve expansion, symmetric Mommer-Stevenson example;');
  fprintf('\n   2.  Square domain (0,1)^2,  Eigel random coefficient, symmetric Mommer-Stevenson example;');
  fprintf('\n   3.  L-shaped domain, Eigel random coefficient, symmetric Mommer-Stevenson example;');
  fprintf('\n   4.  L-shaped domain, Eigel random coefficient, nonsymmetric Mommer-Stevenson example;');
  fprintf('\n   5.  Crack domain,    Eigel-Merdon-Neumann random coefficient, pointwise estimation;\n');
    
% Running by default the Mommer-Stevenson-type example
  sn = default('',1);
  
% NOTE:
% sn: example problem
%
% rd_type: random-field (coefficient) type; see STOCH_GOAFEM_INIT_STOCH 
% - 1 Karhunen-Loeve expansion 
% - 2 Synthetic Eigel expansion
% - 3 Powell (KL-type) expansion 
% - 4 Synthetic Eigel-Merdon-Neumann expansion
%
% dom_type: domain type
% - 1 unit square domain  (0,1)^2
% - 2 large square domain (-1,1)^2
% - 3 L-shaped domain     (-1,1)^2 \ (-1,0]^2
% - 4 unit crack domain   (0,1)^2  \ (1/2,1)x{1/2} (crack on the right)
% - 5 large crack domain  (-1,1)^2 \ (-1,0)x{0}    (crack on the left)

% Set up data for specific problems
  if sn==1
      % Mommer-Stevenson-type example on square domain (KL expansion)
      !/bin/cp ./test_problems/stoch_KL_coeff.m                 ./stoch_goafem/stoch_goafem_specific_coeff.m
      !/bin/cp ./test_problems/stoch_KL_gradcoeff.m             ./stoch_goafem/stoch_goafem_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_zero_bc.m                  ./stoch_goafem/stoch_goafem_specific_bc.m
      !/bin/cp ./test_problems/stoch_goafem_zero_L2rhs.m        ./stoch_goafem/stoch_goafem_specific_L2rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_L2goal.m       ./stoch_goafem/stoch_goafem_specific_L2goal.m
      !/bin/cp ./test_problems/stoch_goafem_ms09_KL_H1rhs.m     ./stoch_goafem/stoch_goafem_specific_H1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_ms09_KL_H1goal.m    ./stoch_goafem/stoch_goafem_specific_H1goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1rhs.m     ./stoch_goafem/stoch_goafem_specific_divH1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1goal.m    ./stoch_goafem/stoch_goafem_specific_divH1goal.m      
      rd_type  = 1;
      dom_type = 2;
  
  elseif sn==2     
      % Mommer-Stevenson-type example on square domain (Eigel synthetic random coefficient)
      !/bin/cp ./test_problems/stoch_eigel_coeff.m              ./stoch_goafem/stoch_goafem_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m          ./stoch_goafem/stoch_goafem_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_zero_bc.m                  ./stoch_goafem/stoch_goafem_specific_bc.m
      !/bin/cp ./test_problems/stoch_goafem_zero_L2rhs.m        ./stoch_goafem/stoch_goafem_specific_L2rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_L2goal.m       ./stoch_goafem/stoch_goafem_specific_L2goal.m
      !/bin/cp ./test_problems/stoch_goafem_ms09_H1rhs.m        ./stoch_goafem/stoch_goafem_specific_H1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_ms09_H1goal.m       ./stoch_goafem/stoch_goafem_specific_H1goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1rhs.m     ./stoch_goafem/stoch_goafem_specific_divH1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1goal.m    ./stoch_goafem/stoch_goafem_specific_divH1goal.m
      rd_type  = 2;
      dom_type = 1;
 
  elseif sn==3
      % (Symmetric) Mommer-Stevenson-type example on L-shaped domain (Eigel synthetic random coefficient)
      !/bin/cp ./test_problems/stoch_eigel_coeff.m              ./stoch_goafem/stoch_goafem_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m          ./stoch_goafem/stoch_goafem_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_zero_bc.m                  ./stoch_goafem/stoch_goafem_specific_bc.m
      !/bin/cp ./test_problems/stoch_goafem_unit_L2rhs.m        ./stoch_goafem/stoch_goafem_specific_L2rhs.m
      !/bin/cp ./test_problems/stoch_goafem_unit_L2goal.m       ./stoch_goafem/stoch_goafem_specific_L2goal.m
      !/bin/cp ./test_problems/stoch_goafem_mod_ms09_H1rhs.m    ./stoch_goafem/stoch_goafem_specific_H1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_mod_ms09_H1goal.m   ./stoch_goafem/stoch_goafem_specific_H1goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1rhs.m     ./stoch_goafem/stoch_goafem_specific_divH1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1goal.m    ./stoch_goafem/stoch_goafem_specific_divH1goal.m
      rd_type  = 2;
      dom_type = 3;

  elseif sn==4 
      % (Nonsymmetric) Mommer-Stevenson-type example on L-shaped domain (Eigel synthetic random coefficient)
      !/bin/cp ./test_problems/stoch_eigel_coeff.m              ./stoch_goafem/stoch_goafem_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m          ./stoch_goafem/stoch_goafem_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_zero_bc.m                  ./stoch_goafem/stoch_goafem_specific_bc.m
      !/bin/cp ./test_problems/stoch_goafem_unit_L2rhs.m        ./stoch_goafem/stoch_goafem_specific_L2rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_L2goal.m       ./stoch_goafem/stoch_goafem_specific_L2goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_H1rhs.m        ./stoch_goafem/stoch_goafem_specific_H1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_mod_ms09_H1goal.m   ./stoch_goafem/stoch_goafem_specific_H1goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1rhs.m     ./stoch_goafem/stoch_goafem_specific_divH1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1goal.m    ./stoch_goafem/stoch_goafem_specific_divH1goal.m
      rd_type  = 2;
      dom_type = 3;

  elseif sn==5
      % Pointwise estimation on larger crack-domain (-1,1)^2 \ (-1,0)x{0} (Eigel-Merdon-Neumann random coefficient)
      !/bin/cp ./test_problems/stoch_goafem_emn_coeff.m         ./stoch_goafem/stoch_goafem_specific_coeff.m
      !/bin/cp ./test_problems/stoch_goafem_emn_gradcoeff.m     ./stoch_goafem/stoch_goafem_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_zero_bc.m                  ./stoch_goafem/stoch_goafem_specific_bc.m
      !/bin/cp ./test_problems/stoch_goafem_unit_L2rhs.m        ./stoch_goafem/stoch_goafem_specific_L2rhs.m
      !/bin/cp ./test_problems/stoch_goafem_po99_L2goal.m       ./stoch_goafem/stoch_goafem_specific_L2goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_H1rhs.m        ./stoch_goafem/stoch_goafem_specific_H1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_H1goal.m       ./stoch_goafem/stoch_goafem_specific_H1goal.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1rhs.m     ./stoch_goafem/stoch_goafem_specific_divH1rhs.m
      !/bin/cp ./test_problems/stoch_goafem_zero_divH1goal.m    ./stoch_goafem/stoch_goafem_specific_divH1goal.m
      rd_type  = 4;
      dom_type = 5;

  else
      error('Oops... reference problem datafile not found!');
  end % end if

% Calling the main driver
  stoch_goafem_diffusion_main;
  
% end scriptfile