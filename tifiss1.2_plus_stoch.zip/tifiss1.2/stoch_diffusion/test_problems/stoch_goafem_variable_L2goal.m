function [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
%STOCH_GOAFEM_VARIABLE_L2GOAL non-constant deterministic L2 part of RHS of the dual problem
%
% [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
%   
% input:
%          x    x coordinate vector
%          y    y coordinate vector
%        nel    number of elements
%       norv    number of random variables
%
% output: 
%          g    deterministic L2 part of rhs (dual)
%
% See also STOCH_GOAFEM_VARIABLE_L2RHS
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  g_det = exp(-((x - 0.625).^2 + (y - 0.625).^2));   
  g = [g_det,zeros(nel,norv)];
 
end % end function