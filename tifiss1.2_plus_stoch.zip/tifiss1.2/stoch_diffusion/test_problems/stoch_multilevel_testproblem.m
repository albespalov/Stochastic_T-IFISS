%STOCH_MULTILEVEL_TESTPROBLEM adaptive solution of stochastic diffusion reference problem using multilevel SGFEM (Unix version)
%
%   TIFISS scriptfile: AB; 29 December 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri
    
  gohome; cd stoch_diffusion;

  fprintf('\nAdaptive solution of reference stochastic diffusion problem.');
  fprintf('\nChoose specific example:');
  fprintf('\n   1. Square domain (-1,1)^2, analytic KL expansion, non-constant source');
  fprintf('\n   2. Square domain (0,1)^2,  Eigel synthetic random coefficient, constant source');
  fprintf('\n   3. Square domain (0,1)^2,  Powell synthetic random coefficient, constant source');
  fprintf('\n   4. L-shaped domain, synthetic random coefficient, constant source');
  fprintf('\n   5. L-shaped domain, Eigel synthetic random coefficient, constant source');
  fprintf('\n   6. L-shaped domain, Powell synthetic random coefficient, constant source');
  fprintf('\n   7. Crack domain, Eigel synthetic random coefficient, constant source');
  fprintf('\n   8. Crack domain, Powell synthetic random coefficient, non-constant source');
  fprintf('\n   9. Square domain (0,1)^2, cookie problem, constant source\n');
  
% Running by default example 5: L-shape domain with Eigel coefficient
  sn = default('',5);
  
% NOTE:
% sn: example problem
%
% rd_type: random-field (coefficient) type; see STOCH_MULTILEVEL_INIT_STOCH
% - 0 Synthetic coefficient; see STOCH_SYNTHETIC_COEFF
% - 1 Karhunen-Loeve expansion 
% - 2 Synthetic Eigel expansion
% - 3 Powell (KL-type) expansion
% - 4 Finite expansion for cookie problem
%
% dom_type: domain type
% - 1 unit square domain  (0,1)^2
% - 2 large square domain (-1,1)^2
% - 3 L-shaped domain     (-1,1)^2 \ (-1,0]^2
% - 4 large crack domain  (-1,1)^2 \ (-1,0)x{0} (crack on the left)
  
% Model Problems  
  if sn == 1
      % Large square domain; KL expansion
      !/bin/cp ./test_problems/stoch_KL_coeff.m             ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_KL_gradcoeff.m         ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_variable_rhs.m         ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 1;
      dom_type = 2;   
      
  elseif sn == 2
      % Unit square domain; Eigel coefficient
      !/bin/cp ./test_problems/stoch_eigel_coeff.m          ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m      ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 2; 
      dom_type = 1;
      
  elseif sn == 3
      % Unit square domain; Powell coefficient
      !/bin/cp ./test_problems/stoch_powell_coeff.m         ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_powell_gradcoeff.m     ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 3;
      dom_type = 1; 
      
  elseif sn == 4
      % L-shaped domain domain; synthetic coefficient
      !/bin/cp ./test_problems/stoch_synthetic_coeff.m      ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_synthetic_gradcoeff.m  ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 0;
      dom_type = 3;  
      
  elseif sn == 5
      % L-shaped domain domain; Eigel coefficient
      !/bin/cp ./test_problems/stoch_eigel_coeff.m          ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m      ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 2; 
      dom_type = 3; 
      
  elseif sn == 6
      % L-shaped domain domain; Powell coefficient
      !/bin/cp ./test_problems/stoch_powell_coeff.m         ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_powell_gradcoeff.m     ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 3;
      dom_type = 3; 
      
  elseif sn == 7
      % Large crack domain; Eigel coefficient
      !/bin/cp ./test_problems/stoch_eigel_coeff.m          ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_eigel_gradcoeff.m      ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 2; 
      dom_type = 4;  

  elseif sn == 8 
      % Large crack domain; Powell coefficient
      !/bin/cp ./test_problems/stoch_powell_coeff.m         ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_powell_gradcoeff.m     ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_variable_rhs.m         ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 3;  
      dom_type = 4;

  elseif sn == 9
      % Unit square domain; Finite expansion; Cookie problem
      !/bin/cp ./test_problems/stoch_cookie_coeff.m         ./stoch_specific_coeff.m
      !/bin/cp ./test_problems/stoch_cookie_gradcoeff.m     ./stoch_specific_gradcoeff.m
      !/bin/cp ./test_problems/stoch_unit_rhs.m             ./stoch_specific_rhs.m
      !/bin/cp ./test_problems/stoch_zero_bc.m              ./stoch_specific_bc.m
      rd_type  = 4;  
      dom_type = 1;
  
  else
      error('...Reference problem datafile not found!');
  end
% end model problems
  
% Calling the main driver
  stoch_multilevel_diff_main;

% end scriptfile