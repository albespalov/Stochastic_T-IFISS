function [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
%STOCH_GOAFEM_ZERO_L2GOAL zero deterministic L2 part of RHS of the dual problem
%   
% [g] = stoch_goafem_specific_L2goal(x,y,nel,norv)
% 
% input:
%        x    x coordinate vector
%        y    y coordinate vector
%      nel    number of elements
%     norv    number of random variables
%
% output: 
%        g    deterministic L2 part of rhs (dual)
%
% See also STOCH_GOAFEM_ZERO_L2RHS
%
%   TIFISS function: MR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, D. Praetorius, L. Rocchi, M. Ruggeri

  g = [zeros(nel,1),zeros(nel,norv)];

end % end function