function [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%STOCH_POWELL_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%
% [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%  
% input:
%            x     x coordinate vector
%            y     y coordinate vector 
%          nel     number of elements  
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion (6-fields structure or zero)
%
% output:
%  [dadx,dady]     derivatives (gradient) of the stochastic coefficient
%
% This expansion is discussed on p.393 of:
% G. Lord, C.E. Powell, T. Shardlow, An Introduction to Computational 
% Stochastic PDEs, Cambridge University Press, 2014.
%
% NOTE that this function is a copy of original SIFISS function;
%
% See also STOCH_POWELL_COEFF
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% initialisation
dadx = zeros(nel,norv+1);
dady = zeros(nel,norv+1);

% et da_0/dx and da_0/dy
dadx(:,1)=zeros(nel,1);
dady(:,1)=zeros(nel,1);

% set length scale parameter
ell = KL_DATA.ell;

% one dimensional functions
ind=[0:norv-1];
nu1=[0.5.*exp(-pi*ind.^2.*ell^2)]'; nu2=nu1;
% compute all possible product pairs of 1D eigs
nu_prod=nu1*nu2';

% find 1D indices and compute the largest 2D eigs
for m=1:norv
[maxcol,indrow]=max(nu_prod);
[eigmax,jj]=max(maxcol);
ii=indrow(jj);
nu2D(m)=eigmax;
nu2Dpos(m,:)=[ii,jj];
nu_prod(ii,jj)=0;
end

% set da_m/dx and da_m/dy
for m=1:norv
k1=nu2Dpos(m,1); k2=nu2Dpos(m,2); sqeig=sqrt(nu2D(m));
% 1d eig indices run from 0 to norv-1
   if (k1==1)&(k2==1)
   dadx(:,m+1)= zeros; dady(:,m+1)= zeros;
   elseif (k1==1)&(k2~=1)
   dadx(:,m+1)= zeros;
   dady(:,m+1)= -(k2-1)*pi *sqrt(2)*sqeig*sin((k2-1).*pi.*y);
   elseif (k1~=1)&(k2==1)
   dadx(:,m+1)= -(k1-1)*pi *sqrt(2)*sqeig*sin((k1-1).*pi.*x);
   dady(:,m+1)= zeros;
   else
   dadx(:,m+1)= -(k1-1)*pi *2*sqeig *sin((k1-1).*pi.*x).*cos((k2-1).*pi.*y);
   dady(:,m+1)= -(k2-1)*pi *2*sqeig *cos((k1-1).*pi.*x).*sin((k2-1).*pi.*y);
   end
   %
   %
   dadx(:,m+1) = dadx(:,m+1)./sqrt(3.0);
   dady(:,m+1) = dadx(:,m+1)./sqrt(3.0);
end

end % end function