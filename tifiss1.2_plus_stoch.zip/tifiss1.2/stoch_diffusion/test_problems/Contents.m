% TEST_PROBLEMS
%
% Files
%   stoch_adapt_testproblem           - adaptive solution of stochastic diffusion reference problem (Unix version)
%   stoch_adapt_testproblem_pc        - STOCH_ADAPT_TESTPROBLEM adaptive solution of stochastic diffusion reference problem (Windows version)
%   stoch_adapt_testproblem_unix      - STOCH_ADAPT_TESTPROBLEM adaptive solution of stochastic diffusion reference problem (Unix version)
%   stoch_cookie_coeff                - stochastic diffusion coefficient for cookie problem
%   stoch_cookie_gradcoeff            - gradient of stochastic diffusion coefficient for cookie problem
%   stoch_diff_testproblem            - sets up stochastic diffusion reference problem (Unix version)
%   stoch_diff_testproblem_pc         - STOCH_DIFF_TESTPROBLEM sets up stochastic diffusion reference problem (Windows version)
%   stoch_diff_testproblem_unix       - STOCH_DIFF_TESTPROBLEM sets up stochastic diffusion reference problem (Unix version)
%   stoch_eigel_coeff                 - synthetic stochastic diffusion coefficient
%   stoch_eigel_coeff_symm1           - synthetic stochastic diffusion coefficient
%   stoch_eigel_coeff_symm2           - synthetic stochastic diffusion coefficient
%   stoch_eigel_gradcoeff             - gradient of synthetic stochastic diffusion coefficient 
%   stoch_eigel_gradcoeff_symm1       - gradient of synthetic stochastic diffusion coefficient 
%   stoch_eigel_gradcoeff_symm2       - gradient of synthetic stochastic diffusion coefficient 
%   stoch_goafem_analytic_coeff       - synthetic stochastic diffusion coefficient
%   stoch_goafem_emn_coeff            - synthetic stochastic diffusion coefficient
%   stoch_goafem_emn_gradcoeff        - gradient of synthetic stochastic diffusion coefficient 
%   stoch_goafem_mod_ms09_H1goal      - Mommer-Stevenson(2009)-type deterministic H1 part of the RHS of the dual problem 
%   stoch_goafem_mod_ms09_H1rhs       - Mommer-Stevenson(2009)-type deterministic H1 part of the RHS of the primal problem 
%   stoch_goafem_ms09_H1goal          - Mommer-Stevenson(2009) deterministic H1 part of the RHS of the dual problem 
%   stoch_goafem_ms09_H1rhs           - Mommer-Stevenson(2009) deterministic H1 part of the RHS of the primal problem 
%   stoch_goafem_ms09_KL_H1goal       - Mommer-Stevenson(2009)-type deterministic H1 part of the RHS of the dual problem 
%   stoch_goafem_ms09_KL_H1rhs        - Mommer-Stevenson(2009)-type deterministic H1 part of the RHS of the primal problem 
%   stoch_goafem_po99_L2goal          - Prudhomme-Oden mollifier L2 part of RHS of the dual problem
%   stoch_goafem_testproblem          - sets up goal-oriented adaptive SGFEM examples (Unix version)
%   stoch_goafem_testproblem_pc       - STOCH_GOAFEM_TESTPROBLEM sets up goal-oriented adaptive SGFEM examples (Windows version)
%   stoch_goafem_testproblem_unix     - STOCH_GOAFEM_TESTPROBLEM sets up goal-oriented adaptive SGFEM examples (Unix version)
%   stoch_goafem_unit_L2goal          - unit deterministic L2 part of RHS of the dual problem
%   stoch_goafem_unit_L2rhs           - unit deterministic L2 part of RHS of the primal problem
%   stoch_goafem_variable_L2goal      - non-constant deterministic L2 part of RHS of the dual problem
%   stoch_goafem_variable_L2rhs       - non-constant deterministic L2 part of RHS of the primal problem
%   stoch_goafem_zero_divH1goal       - zero deterministic divergence of H1 part of RHS of the dual problem
%   stoch_goafem_zero_divH1rhs        - zero deterministic divergence of H1 part of RHS of the primal problem
%   stoch_goafem_zero_H1goal          - zero deterministic H1 part of the RHS of the dual problem 
%   stoch_goafem_zero_H1rhs           - zero deterministic H1 part of the RHS of the primal problem 
%   stoch_goafem_zero_L2goal          - zero deterministic L2 part of RHS of the dual problem
%   stoch_goafem_zero_L2rhs           - zero deterministic L2 part of RHS of the primal problem
%   stoch_KL_coeff                    - analytic Karhunen-Loeve (KL) stochastic diffusion coefficient
%   stoch_KL_gradcoeff                - gradient of analytic Karhunen-Loeve (KL) stochastic diffusion coefficient 
%   stoch_multilevel_testproblem      - adaptive solution of stochastic diffusion reference problem using multilevel SGFEM (Unix version)
%   stoch_multilevel_testproblem_pc   - STOCH_MULTILEVEL_TESTPROBLEM adaptive solution of stochastic diffusion reference problem using multilevel SGFEM (Windows version)
%   stoch_multilevel_testproblem_unix - STOCH_MULTILEVEL_TESTPROBLEM adaptive solution of stochastic diffusion reference problem using multilevel SGFEM (Unix version)
%   stoch_powell_coeff                - synthetic stochastic diffusion coefficient
%   stoch_powell_gradcoeff            - gradient of synthetic stochastic diffusion coefficient 
%   stoch_synthetic_coeff             - synthetic stochastic diffusion coefficient
%   stoch_synthetic_gradcoeff         - gradient of synthetic stochastic diffusion coefficient 
%   stoch_unit_rhs                    - unit deterministic RHS forcing function
%   stoch_variable_rhs                - non-constant deterministic RHS forcing function
%   stoch_zero_bc                     - zero boundary condition 
%   stoch_zero_rhs                    - zero deterministic RHS forcing function
