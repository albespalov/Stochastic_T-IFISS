function a = stoch_specific_coeff(x,y,nel,norv,KL_DATA)
%STOCH_COOKIE_COEFF stochastic diffusion coefficient for cookie problem
%
% [a] = stoch_specific_coeff(x,y,nel,norv,KL_DATA)
%
% input:
%           x     x coordinate vector
%           y     y coordinate vector
%         nel     number of elements
%        norv     number of random variables
%     KL_DATA     data related to KL-expansion
%
% output:
%           a     synthetic stochastic diffusion coefficient
%
% This coefficient expansion has been used to perform numerical experiments
% discussed in the papers:
% 1) A. Bespalov, D. Praetorius, M. Ruggeri, Two-level a posteriori error
%    estimation for adaptive multilevel stochastic Galerkin FEM,
%    SIAM/ASA Journal on Uncertainty Quantification, 9(3), 1184-1216, 2021
%    (see Section 7.2).
% 2) A. Bespalov, D. Praetorius, M. Ruggeri, Convergence and rate
%    optimality of adaptive multilevel stochastic Galerkin FEM,
%    IMA Journal of Numerical Analysis, 2021 (see Section 7.2).
%
% See also STOCH_COOKIE_GRADCOEFF
%
%   TIFISS function: AB; 29 December 2021
% Copyright (c) 2021 A. Bespalov, D. Praetorius, M. Ruggeri

% Initialisation
  a = zeros(nel,norv+1);

% Set a_0
  a(:,1) = ones(nel,1);

% Prepare cookies
  i = [1 3 5 1 3 5 1 3 5];
  j = [1 1 1 3 3 3 5 5 5];
  
% Set a_m
  for m = 1:9
      if m == 5
          a(:,m+1) = 0.9*((x - i(m)/6).^2 + (y - j(m)/6).^2 <= 1/(8*8));
      elseif ismember(m,[2,4,6,8]) 
          a(:,m+1) = 0.7*((x - i(m)/6).^2 + (y - j(m)/6).^2 <= 1/(8*8));
      elseif ismember(m,[1,3,7,9])
          a(:,m+1) = 0.5*((x - i(m)/6).^2 + (y - j(m)/6).^2 <= 1/(8*8));
      end
  end

end % end function