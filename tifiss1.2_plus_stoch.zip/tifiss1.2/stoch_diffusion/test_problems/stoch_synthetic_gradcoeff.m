function [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%STOCH_SYNTHETIC_GRADCOEFF gradient of synthetic stochastic diffusion coefficient 
%   
% [dadx,dady] = stoch_specific_gradcoeff(x,y,nel,norv,KL_DATA)
%
% input:
%            x     x coordinate vector
%            y     y coordinate vector 
%          nel     number of elements  
%         norv     number of random variables
%      KL_DATA     data related to KL-expansion (6-fields structure or zero)
%
% output:
%  [dadx,dady]     derivatives (gradient) of the stochastic coefficient
%
% NOTE that this is a copy of original SIFISS function (DJS; 2 May 2013)
%
% See also STOCH_SYNTHETIC_COEFF
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Initialisation
  dadx = zeros(nel,norv+1);
  dady = zeros(nel,norv+1);

% set da_0/dx and da_0/dy
  dadx(:,1) = zeros(nel,1);
  dady(:,1) = zeros(nel,1);

% Set da_m/dx and da_m/dy
  for m=1:norv
      dadx(:,m+1) = 3.0e0*cos(pi*m*(x-y))/(pi*m);
      dady(:,m+1) = -3.0e0*cos(pi*m*(x-y))/(pi*m);

      % This is ONLY to test the case of ONE random variable !
%       dadx(:,m+1) =  pi*m*cos(pi*m*(x-y))/2.0e0;
%       dady(:,m+1) = -pi*m*cos(pi*m*(x-y))/2.0e0;
  end

end % end function