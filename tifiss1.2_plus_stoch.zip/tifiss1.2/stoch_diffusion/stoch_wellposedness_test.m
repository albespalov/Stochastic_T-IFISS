function [amin] = stoch_wellposedness_test(dom_type,noarv,KL_DATA)
%STOCH_WELLPOSEDNESS_TEST estimates the lower bound of stochastic diffusion coefficient
%
% [amin] = stoch_wellposedness_test(dom_type,noarv,KL_DATA)
% 
% input:
%      dom_type    domain type
%         noarv    number of active random variables
%       KL_DATA    data related to KL-expansion
%
% output:
%          amin    estimated lower bound of the random field for current active parameters
%
% The bound is estimated by sampling the random coefficient at uniformly
% spaced points in the physical domain and setting stochastic variables to
% (plus/minus) one.
% This function gives a tighter bounds than two other functions below.
%
% See also STOCH_TEST_WELLPOSEDNESS_KL, STOCH_TEST_WELLPOSEDNESS_POWELL
%
%   TIFISS function: AB; 31 December 2021
% Copyright (c) 2021 A. Bespalov, L. Rocchi

% enhanced wellposdness test for KL expansion

  % setting 1D sampling points
  deltat=0.01;
  if dom_type == 1
      xt=deltat:deltat:1-deltat;
      yt=xt;
  else% dom_type = 2,3,4
      xt=-1+deltat:deltat:1-deltat;
      yt=xt;
  end
  
  % Tensorizing sampling points
  xx=[];yy=[];
  for i=1:length(xt)
      for j=1:length(yt)
          xx=[xx, xt(i)];
          yy=[yy, yt(j)];
      end
  end
  
  Coords = [xx' yy'];
  
  if dom_type == 3
      ind = find(Coords(:,1) <= 0 & Coords(:,2) <= 0);
      Coords = Coords(setdiff([1:length(xx)], ind'),:);
  elseif dom_type == 4
      ind = find(Coords(:,1) <= 0 & Coords(:,2) == 0);
      Coords = Coords(setdiff([1:length(xx)], ind'),:);
  end
  
%   % scatter plot of sampling points
%   figure(99)
%   scatter(Coords(:,1),Coords(:,2))
  
  % sampling the parametric coefficient (random field)
  aa = stoch_specific_coeff(Coords(:,1),Coords(:,2),size(Coords,1),noarv,KL_DATA);
  
  sm=sum(abs(aa(:,2:end)),2);
  amin = min(aa(:,1)) - max(sm);
  
end