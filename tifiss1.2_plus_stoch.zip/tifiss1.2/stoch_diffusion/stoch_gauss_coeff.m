function [a] = stoch_gauss_coeff(s,t,xl,yl,norv,KL_DATA)
%STOCH_GAUSS_COEFF evaluates stochastic coefficient at Gauss point
%
% [a] = stoch_gauss_coeff(s,t,xl,yl,norv,KL_DATA)
% 
% input
%            s    reference element x coordinate   
%            t    reference element y coordinate
%           xl    physical element x vertex coordinates 
%           yl    physical element y vertex coordinates  
%         norv    number of random variables
%      KL_DATA    data related to KL-expansion
%
% output: 
%            a    stochastic coefficient evaluated at Gauss point
%
% This is a copy of original SIFISS function (DJS; 19 January 2013)
%
% Function(s) called: stoch_specific_coeff
%
% See also STOCH_GAUSS_GRADCOEFF 
%
%   TIFISS function: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nel         = length(xl(:,1));
  xx          = zeros(nel,1);
  yy          = xx; 
  [phi_e,~,~] = tshape(s,t);
  
  for ivtx = 1:3 
      xx = xx + phi_e(ivtx) * xl(:,ivtx);
      yy = yy + phi_e(ivtx) * yl(:,ivtx);
  end
  
  a = stoch_specific_coeff(xx,yy,nel,norv,KL_DATA);
        
end % end function