%STOCH_DIFF_MAIN solves stochastic diffusion problems on square, L-shaped, or crack domain
%
% Main driver for non-adaptive stochastic Galerkin FEM
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% -------------------------------------------------------------------------  
% Initial parameters
% -------------------------------------------------------------------------

% Plotting switch for stoch_minres convergence (0/1)
  iPlotConv = 1; 
       
% Set the spatial approximation 
  pmethod = default('\nP1/P2 approximation 1/2? (default P1)',1);
  
% Red/Bisec3 for spatial error estimation 1/2? See:
% Ainsworth, Oden, A posteriori error estimation in finite element analysis, 
% Wiley, 2000 - Figure 5.2 (p. 87) for the basis functions in both cases.
  subdivPar = 2; 
  
% If P1 approximations are chosen, decide the (spatial) error estimation type:
% 1 - eYP hierarchical estimator (elementwise residual problem);
% 2 - eYP hierarchical estimator (assembled system for the residual problem);
% 3 - 2-level error estimator.
% See STOCH_DIFFPOST.
  if pmethod == 1
      fprintf('\nSpatial error estimation type:\n');
      fprintf('   1. hierarchical estimator (elementwise residual problem)\n');
      fprintf('   2. hierarchical estimator (fully assembled sysyem for residual problem)\n');
      fprintf('   3. 2-level estimator\n');
      ypestim = default('(default 1)',1);
      if ~ismember(ypestim,[1,2,3]), error('Spatial estimation type not allowed!'); end
  end
   
% -------------------------------------------------------------------------  
% Spatial and parametric setup
% -------------------------------------------------------------------------

% Spatial initialisation of the mesh
  stoch_init_spatial;

% Random variables and stochastic coefficients initialisation
  stoch_init_stoch;

% -------------------------------------------------------------------------  
% Setup and solve the discrete system (P1 and P2 approximations allowed)
% -------------------------------------------------------------------------
  nvtx = size(xy,1);  % Number of vertices
  nel  = size(evt,1); % Number of elements

  fprintf('\nMesh info:');
  fprintf('\n   Number of vertices: %d',nvtx);  
  fprintf('\n   Number of elements: %d\n',nel);        

% Generate the G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);

  setupmat = tic;
  if pmethod == 1
      fprintf('\nSetting up stochastic P1 diffusion matrices...');
      [Knbc,fnbc] = stoch_femp1_setup(xy,evt,indset,P,norv,noarv,KL_DATA);    
      % Boundary conditions
      [K,fnew,x_gal,dupl_intern] = stoch_imposebcx(Knbc,fnbc,G,xy,bound,indset,P,norv,noarv);
      
  elseif pmethod == 2  
      % Generating the P2 grid
      fprintf('\nSetting up stochastic P2 diffusion matrices...');
      [p2xy,p2evt,p2bound] = p2_grid_generator(xy,evt,bound);
      [Knbc,fnbc] = stoch_femp2_setup(p2xy,p2evt,indset,P,norv,noarv,KL_DATA);
      % Boundary conditions
      [K,fnew,x_gal,dupl_intern] = stoch_imposebcx(Knbc,fnbc,G,p2xy,p2bound,indset,P,norv,noarv);
  end
  fprintf('done (%.5f sec)\n',toc(setupmat));

% Number of internal node
  nint = length(dupl_intern)/P;
       
% -------------------------------------------------------------------------  
% Solve the system
% -------------------------------------------------------------------------
  fprintf('<strong>MINRES solution of the linear systems:</strong>\n');  
% Extract the mean stiffness matrix
  Amean = K{1};
% Fast (LU factorisation) solver using LUPQ -------------------------------
  fprintf('LU(PQ) factorisation of K_0...'); 
  LUtime = tic; 
  [L,U,PP,QQ] = lu(Amean);
  fprintf('done (%.5f sec)\n',toc(LUtime));
  tol = 1e-10;    maxit = 99;
  apost = 0;      stopit = 0;    prob_type = 'sdiff';
  MA = 'm_sdiff'; aparams = struct('nint',nint,'L',PP\L,'U',U/QQ);
% -------------------------------------------------------------------------
  
% Minres solver (internal nodes only)
  [xminres,resvec,emin,~,info] = stoch_est_minresy(G,K,fnew,apost,stopit,maxit,tol,prob_type,MA,aparams);
                                                             
% Update the computed Galerkin solution                   
  x_gal(dupl_intern) = xminres;
   
% NOTE: 
% - length(x_gal): overall number of dofs INCLUDING boundary nodes (per each mode)
% - length(xminres): number of the "internal" dofs, i.e., EXCLUDING boundary 
%   nodes(per each mode). This is the right number of dofs if homogeneous 
%   Dirichlet bcs are used
  
  if iPlotConv
      if noarv > 0
          figure(13)
          inx = 0:info(4)-1;rx=9:9:info(4);
          if info(4) > 4
              semilogy(inx,sqrt(2)*resvec./emin,'-r');
              hold on;  semilogy(inx,resvec,'-b');  hold off;
              axis('square');
              xlabel('iteration number {\it k}');
              title('MINRES convergence history');
              h = legend('${\sqrt{2}/ \lambda_k^2}\> ||r_k||_{M_*}$','$||r_k||_{M_*}$');
              set(h,'Interpreter','latex');
          end
      end
  end

% -------------------------------------------------------------------------  
% Computes energy norm and variance
% -------------------------------------------------------------------------  
% Energy norm ||x_gal||_B
  [b_ref] = stoch_matvecx(x_gal,G,Knbc);
  energy  = sqrt(x_gal' * b_ref);
% Variance Var(x_gal)
  [var_sol] = stoch_variancex(x_gal,P);      
 
% -------------------------------------------------------------------------  
% Print data
% -------------------------------------------------------------------------
  fprintf('<strong>Linear solver statistics:</strong>\n');
  fprintf('   Total ndof:         %g\n',length(xminres));%length(u_gal));
  fprintf('   Minimum eigenvalue: %5.3f\n',emin(end));
  fprintf('<strong>Stochastic parameters:</strong>\n');
  fprintf('   Active parameters:  %g\n',noarv);
  fprintf('   Polynomial degree: %2i\n',polyd);
  fprintf('<strong>Computed solution:</strong>\n');
  fprintf('   Maximum mean value: %8.4e\n',max(x_gal(1:nvtx)));      
  fprintf('   Maximum variance:   %8.4e\n',max(var_sol));
  fprintf('   Energy norm:        %8.4e\n',energy);
  
% Save data
  gohome; cd datafiles;
  save stoch_singlerun_sol.mat xy evt eboundt bound  ...
                               x_gal energy var_sol  ...
                               norv noarv P polyd indset;    
  
% -------------------------------------------------------------------------  
% A posteriori error estimation (available for P1 approximations only)
% -------------------------------------------------------------------------  
  if pmethod == 1    
      stoch_diffpost;
  else
      fprintf('\n<strong>P2-error estimation not implemented yet...</strong>\n');
  end
    
% -------------------------------------------------------------------------  
% Plot expectation, variance, and YP/XQ-error estimators (only P1 approximations)
% -------------------------------------------------------------------------
  fprintf('\n<strong>Plotting expectation, variance and estimated errors...</strong>');
  if pmethod == 1         
      % P1 Galerkin approximations
      stoch_plotdata_p1(dom_type,x_gal,var_sol,yp_elerr,xq_elerr,evt,xy);
      fprintf('done\n');
      fprintf('\nTo test other detail space options run <strong>stoch_diffpost</strong>\n');
  else%if pmethod == 2    
      % P2 Galerkin approximations (only for single-run code)
      stoch_plotdata_p2(dom_type,x_gal,var_sol,evt,xy,bound,eboundt);
      fprintf('done\n');
  end
 
% end scriptfile