%STOCH_TRUNC_GAUSS_RV computes normalization constant for variance of truncated Gaussian random variables
%
% Karhunen-Loeve (KL) expansion of the random field:
%   a(x,y) = mean(a) + c \sigma \sum_m y_m \sqrt(lambda_m)\phi_m              (1)
% where
% - mean(a) is a constant, 
% - {(lambda_m,\phi_m)} are the eigenpairs of the Covariance operator (see STOCH_KL_EIGENS), 
% - y_m are the images of pairwise uncorrelated mean-zero random variables, 
% - c>0 is chosen such that Var(cy_m) = 1;                                    (2)
%
% NOTE that the expansion (1) conntains the constant c since by default
% the code currently implements two distributions (uniform and truncated
% Gaussian) for which the variance of y_m is not 1.
%
% Given a Gaussian distribution N(0,sigma^2), the "truncated" Gaussian 
% distribution on [-1,1] is associated with the following density:
%   rho(y) = (2Phi(1/sigma)-1)^(-1) (sigma*sqrt(2pi))^(-1) exp(-y^2/2sigma^2) (3)
% where Phi is the cumulative distributive function (see NORMCDF).
% 
% The function finds the constant c in (1) such that (2) is satisfied 
% if y_m have the truncated density (3) with sigma=1. 
% This value if approximately c = 1.85336168.
%
% NOTE that in case of uniform distribution c = sqrt(3);
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  clear; close all;

% -----------------------------------------------------------------------------
% Variances of y_m with densities (3)
% -----------------------------------------------------------------------------
% The following plot shows the variances Var(y_m), where y_m have the
% truncated Gaussian densities (3) for different values of sigma \in (0,10]
sigma = 0.01:0.1:10;
Lc    = length(sigma);
vars  = zeros(1,Lc);
for k = 1:Lc
    sigmak = sigma(k);
    %
    % E[y^2]
    one = @(y) (y.^2) .* exp(-y.^2 ./ (2*sigmak^2)) / sigmak / sqrt(2*pi) / ( 2*normcdf(1/sigmak) - 1 );
    %
    % E[y] (we know that this is 0)
    two = @(y)     y  .* exp(-y.^2 ./ (2*sigmak^2)) / sigmak / sqrt(2*pi) / ( 2*normcdf(1/sigmak) - 1 );
    %
    % Variance: E[y^2] - E[y]^2
    vars(k) = integral(one,-1,1) - (integral(two,-1,1).^2);
end
figure;
plot(sigma,vars);
grid on;
xlabel('std $\sigma$ of (parent) Gaussian distribution $N(0,\sigma^2)$','interpreter','latex','FontSize',17);
ylabel('Var($y_m$)','interpreter','latex','FontSize',17);
title('Variance of $y_m$ with truncated Gaussian density on $[-1,1]$','interpreter','latex','FontSize',19)
set(gca,'XTickMode','manual',...
        'XMinorTick','on', 'YMinorTick','on',...
        'XMinorGrid','off','YMinorGrid','off',...
        'GridLineStyle','--','FontSize',14);
set(gcf,'units','normalized','Position',[0.25 0.05 0.55 0.8]);

% --------------------------------------------------------------------------
% Now, we assume sigma=1 in (3) (this is the default value used/asked by the 
% code) and we define the "rescaled" parameters:
%   xi := cy_m,      c>1,                                               (4)
% where c is the constant in the KL expansion (1). 
% These rescaled parameters belong to [-c,c] and have density:
%   tau(xi) = (2Phi(1)-1)^(-1) (c*sqrt(2pi))^(-1) exp(-y^2/2c^2)        (5)
% Therefore, we now find the (approximate) value of c such that (2) is
% satisfied, i.e., Var(xi) = 1.
% --------------------------------------------------------------------------
% In order to find a good approximation of c, manually allocate discrete 
% values of possible c>1 until the desired accuracy is obtained.
% For example, this is accurate
c    = 1.8533:0.00000002:1.8534;
% while this is less accurate
c    = 1:0.1:2.5;
% --------------------------------------------------------------------------
Lc   = length(c);
vars = zeros(1,Lc);
for k = 1:Lc
    ck = c(k);
    % Var(xi) = E[xi^2] - E[xi]^2 = E[xi^2]
    integrand = @(z) (z.^2) .* exp(-z.^2 ./ (2*ck^2)) / ck / sqrt(2*pi) / (2*normcdf(1) - 1);
    vars(k) = integral(integrand,-ck,ck);
end
figure;
plot(c,vars);
grid on;
xlabel('constant $c$ of parameters $\xi_m=cy_m \in [-c,c]$','interpreter','latex','FontSize',17);
ylabel('Var[$\xi_m$]','interpreter','latex','FontSize',17);
set(gca,'XTickMode','manual',...
        'XMinorTick','on', 'YMinorTick','on',...
        'XMinorGrid','off','YMinorGrid','off',...
        'GridLineStyle','--','FontSize',14);
set(gcf,'units','normalized','Position',[0.25 0.05 0.55 0.8]);

fprintf('\nFor c = %.7f --> Var[xi_m]=%.7f\n',c(find(vars>1,1)),vars(find(vars>1,1)));

% -----------------------------------------------------------------------------
% Sampling example 
% -----------------------------------------------------------------------------
% (Parent) Gaussian distribution N(0,1)
ng = makedist('Normal')
% 
% Truncated Gaussian density on [-1,1]
tng = truncate(ng,-1,1)
x   = -2:.07:2;
%
% % Plot densities
% figure;
% plot(x,pdf(ng,x),'Color','red','LineWidth',2)
% hold on;
% plot(x,pdf(tng,x),'Color','blue','LineWidth',2,'LineStyle',':')
% legend({'Normal','Truncated'},'Location','NE')
% hold off;
%
% Sampling 
nrv = 10000000;
fprintf('\nSampling %d r.v. with truncated Gaussian density on [-1,1]\n',nrv);
r = random(tng,nrv,1);
fprintf('   mean = %.7f\n   var  = %.7f\n',mean(r),sum((r - mean(r)).^2)/length(r));
%
% Rescaled r.v. on [-cc,cc]
cc = c(find(vars>1,1)); %1.85336168;
fprintf('\n"Rescaled" the r.v. with truncated Gaussian density on [-%.8f,%.8f]\n',cc,cc);
r = cc * r;
fprintf('   mean = %.7f\n   var  = %.7f\n',mean(r),sum((r - mean(r)).^2)/length(r));

% end scriptfile 