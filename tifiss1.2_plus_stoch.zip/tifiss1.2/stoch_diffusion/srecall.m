%SRECALL query the current stochastic problem in the workspace
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Check if all variables needed exist
  var = [ exist('spde','var'),    ...
          exist('dom_type','var'),  ...
          exist('pmethod','var'), ...
          exist('noarv','var'),   ...
          exist('polyd','var'),   ...
          exist('P','var') ];
      
  check = find( var==0 );
  
  show = @(message) warning(message);
  
  for k = 1:length(check)
      if     check(k)==1, show('<strong>No discrete stochastic problem found in the workspace!</strong>');
      elseif check(k)==2, show('<strong>No domain found in the workspace!</strong>');
      elseif check(k)==3, show('<strong>No discrete approximation found in the workspace!</strong>');
      elseif check(k)==4, show('<strong>No active random variables found in the workspace!</strong>');
      elseif check(k)==5, show('<strong>No total polynomial degree found in the workspace!</strong>');
      elseif check(k)==6, show('<strong>No length of index set found in the workspace!</strong>');
      end
  end

  fprintf('\n');
  
% Create the table  
  T = table(spde,dom_type,pmethod,noarv,polyd,P);
 
% Populate the table
% Model problem  
  if T.spde == 1
      T.spde = 'Diffusion';
  else
      T.spde = 'Other';
  end
  
% Domain type  
  if T.dom_type == 1
      T.dom_type = 'Square';
  elseif T.dom_type == 2
      T.dom_type = 'L-shaped';
  elseif T.dom_type == 3
      T.dom_type = 'Crack';
  else
      T.dom_type = 'Undefined';
  end
  
% Discrete approximation  
  if T.pmethod == 1
      T.pmethod = 'Linear';
  elseif T.pmethod == 2
      T.pmethod = 'Quadratic';
  end
  
% Update names  
  T.Properties.VariableNames(1:6) = {'Problem','Domain','Approximation','Active_rv','Poly_degree','Indices'};
 
% Show the table
  disp(T);
  
% end scriptfile