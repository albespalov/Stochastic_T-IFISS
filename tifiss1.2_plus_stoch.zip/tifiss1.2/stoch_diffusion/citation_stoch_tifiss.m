%CITATION_STOCH_TIFISS citation information
%    TIFISS scriptfile: AB; 2 January 2022
% Copyright (c) 2018 A. Bespalov, L. Rocchi

fprintf(' \n');
fprintf(' To cite Stochastic T-IFISS in papers, please use:\n');
fprintf(' Alex Bespalov and Leonardo Rocchi,\n');
fprintf(' Stochastic T-IFISS, January 2022,\n');
fprintf(' Available online at http://web.mat.bham.ac.uk/A.Bespalov/software/index.html#stoch_tifiss\n\n')
fprintf(' A BibTex entry for LaTeX users is\n');
fprintf(' @misc{stoch_tifiss,\n');
fprintf('    author = "Alex Bespalov and Leonardo Rocchi",\n')
fprintf('    title = "Stochastic {T-IFISS}",\n')
fprintf('    month = "January",\n')
fprintf('    year = "2022",\n')
fprintf('    note = "Available online at http://web.mat.bham.ac.uk/A.Bespalov/software/index.html#stoch_tifiss "}\n\n')
