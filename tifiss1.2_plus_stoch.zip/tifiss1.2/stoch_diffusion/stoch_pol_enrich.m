%STOCH_POL_ENRICH adds marked indices to the current index set (polynomial enrichment)
%
% Output:
%
%      index_iter    set of indices that will be added         
%  index_saveiter    iteration whne polynomila enrichment occurs
%          indset    enriched indset
%               P    new length of indset
%           noarv    new number of active random variables
%           polyd    new total polynomial degree
% 
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

% Print new indices to be added 
  fprintf('\nAugmenting index set by\n');
  [~,col] = find(Q_indset);
  for i = 1:length(M_ind)
      fprintf(' %i  ',Q_indset(M_ind(i),1:max(col)) ); fprintf(' 0   0  ...\n'); 
  end
  
% Saving the new indices and iteration
  if index_counter <= adaptmax
      index_iter{index_counter} = Q_indset(M_ind,:);
      index_saveiter(index_counter) = iter;
  end
  
% Update the index counter
  index_counter = index_counter + 1;
 
% Sort the new indset
  indset = sortrows([indset;Q_indset(M_ind,:)]);             
  
% Length of the index set
  P = size(indset,1);

% Number of active random variables
  noarv = norv - nnz(all(indset == 0,1));
  
% Maximum (total) polynomial degree
  polyd = max(sum(indset,2));
          
% end scriptfile