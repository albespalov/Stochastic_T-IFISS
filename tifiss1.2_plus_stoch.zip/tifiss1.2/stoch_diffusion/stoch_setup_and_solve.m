%STOCH_SETUP_AND_SOLVE sets up and solves the sGFEM linear system
%
% Variables computed and returned are:
%               G     stochastic G-matrices
%           x_gal     stochastic Galerkin solution
%         var_sol     variance of the stochastic Galerkin solution
%          energy     energy norm of the stochastic Galerkin solution
%
% Function(s) called: stoch_gmatricesx
%                     stoch_femp1_setup
%                     stoch_femp2_setup
%                     stoch_imposebcx
%                     stoch_est_minresx
%                     stoch_variancex
%                     stoch_matvecx
% 
% NOTE that although the adaptive code runs only with P1 approximations, 
% this function also implements P2 approximations. 
%
%   TIFISS scriptfile: LR; 22 June 2018
% Copyright (c) 2018 A. Bespalov, L. Rocchi

  nvtx = size(xy,1);  % Number of vertices
  nel  = size(evt,1); % Number of elements

  fprintf('\nMesh info:');
  fprintf('\n   Number of vertices: %d',nvtx);  
  fprintf('\n   Number of elements: %d\n',nel);        
    
% Generate the G-matrices
  [G] = stoch_gmatricesx(indset,P,noarv,norv);

% -------------------------------------------------------------------------  
% Setup matrices for P1 and P2 discretisations
% -------------------------------------------------------------------------
  setupmat = tic;
  if pmethod == 1
      fprintf('\nSetting up stochastic P1 diffusion matrices...');
      [Knbc,fnbc] = stoch_femp1_setup(xy,evt,indset,P,norv,noarv,KL_DATA);    
      % Boundary conditions
      [K,fnew,x_gal,dupl_intern] = stoch_imposebcx(Knbc,fnbc,G,xy,bound,indset,P,norv,noarv);
      
  elseif pmethod == 2  
      % Generating the P2 grid
      fprintf('\nSetting up stochastic P2 diffusion matrices...');
      [p2xy,p2evt,p2bound] = p2_grid_generator(xy,evt,bound);
      [Knbc,fnbc] = stoch_femp2_setup(p2xy,p2evt,indset,P,norv,noarv,KL_DATA);
      % Boundary conditions
      [K,fnew,x_gal,dupl_intern] = stoch_imposebcx(Knbc,fnbc,G,p2xy,p2bound,indset,P,norv,noarv);
  end
  fprintf('done (%.5f sec)\n',toc(setupmat));
      
% Number of internal node
  nint = length(dupl_intern)/P;
       
% -------------------------------------------------------------------------  
% Solve the system
% -------------------------------------------------------------------------
  fprintf('<strong>MINRES solution of the linear systems:</strong>\n');  
% Extract the mean stiffness matrix
  Amean = K{1};
% Fast (LU factorisation) solver using LUPQ -------------------------------
  fprintf('LU(PQ) factorisation of K_0...'); 
  LUtime = tic; 
  [L,U,PP,QQ] = lu(Amean);
  fprintf('done (%.5f sec)\n',toc(LUtime));
  tol = 1e-10;    maxit = 99;
  apost = 0;      stopit = 0;    prob_type = 'sdiff';
  MA = 'm_sdiff'; aparams = struct('nint',nint,'L',PP\L,'U',U/QQ);
% -------------------------------------------------------------------------
  
% Minres solver (internal nodes only)
  [xminres,resvec,emin,~,info] = stoch_est_minresx(G,K,fnew,apost,stopit,maxit,tol,prob_type,MA,aparams);
                                                             
% Update the computed Galerkin solution                   
  x_gal(dupl_intern) = xminres;
   
% NOTE: 
% - length(x_gal): overall number of dofs INCLUDING boundary nodes (per each mode)
% - length(xminres): number of the "internal" dofs, i.e., EXCLUDING boundary 
%   nodes(per each mode). This is the right number of dofs if homogeneous 
%   Dirichlet bcs are used
  
% -------------------------------------------------------------------------  
% Plot (or not) the minres convergence  
% -------------------------------------------------------------------------
  if iPlotConv
      if noarv > 0
          figure(13)
          inx = 0:info(4)-1;rx=9:9:info(4);
          if info(4) > 4
              semilogy(inx,sqrt(2)*resvec./emin,'-r');
              hold on;  semilogy(inx,resvec,'-b');  hold off;
              axis('square');
              xlabel('iteration number {\it k}');
              title('MINRES convergence history');
              h = legend('${\sqrt{2}/ \lambda_k^2}\> ||r_k||_{M_*}$','$||r_k||_{M_*}$');
              set(h,'Interpreter','latex');
          end
      end
  end

% -------------------------------------------------------------------------  
% Computes energy norm and variance
% -------------------------------------------------------------------------  
% Energy norm ||x_gal||_B
  [b_ref] = stoch_matvecx(x_gal,G,Knbc);
  energy  = sqrt(x_gal' * b_ref);
% Variance Var(x_gal)
  [var_sol] = stoch_variancex(x_gal,P);      
 
% -------------------------------------------------------------------------  
% Print data
% -------------------------------------------------------------------------
  fprintf('<strong>Linear solver statistics:</strong>\n');
  fprintf('   Total ndof:         %g\n',length(xminres));%length(u_gal));
  fprintf('   Minimum eigenvalue: %5.3f\n',emin(end));
  fprintf('<strong>Stochastic parameters:</strong>\n');
  fprintf('   Active parameters:  %g\n',noarv);
  fprintf('   Polynomial degree: %2i\n',polyd);
  fprintf('<strong>Computed solution:</strong>\n');
  fprintf('   Maximum mean value: %8.4e\n',max(x_gal(1:nvtx)));      
  fprintf('   Maximum variance:   %8.4e\n',max(var_sol));
  fprintf('   Energy norm:        %8.4e\n',energy);

% end scriptfile     